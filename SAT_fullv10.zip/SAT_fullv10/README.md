# Service Analyzer Tool (SAT) System

The **Service Analyzer Tool (SAT)** is an enterprise-grade web application designed to automatically scan, analyze, and map service contracts (WSDL and XSD schemas) and consolidate them with metadata from Excel databases. It provides visual interactive dependency graphs, detailed schema explorers, persistent AI assistant diagnostics, and cross-assessment structural difference reports.

---

## 🛠️ Project Architecture

The application is structured into two main components: a decoupled FastAPI backend service and a modern React frontend client.

```
┌────────────────────────────────────────────────────────┐
│                   React Client                         │
│   (TypeScript, Ant Design, Zustand, React Flow)       │
└───────────────────────────┬────────────────────────────┘
                            │ (JSON/HTTP APIs)
                            ▼
┌────────────────────────────────────────────────────────┐
│                   FastAPI Backend                      │
│ (Python, SQLite, SQLAlchemy, VectorDB, Gemini RAG)     │
└────────────────────────────────────────────────────────┘
```

### 1. Backend Service
* **API Framework:** FastAPI provides high-performance, asynchronous endpoints.
* **Storage Layer:** SQLite database managed via SQLAlchemy ORM for relational tables (`assessments`, `services`, `dependencies`, `chat logs`).
* **Semantic Search Repository:** Vector index (ChromaDB) for similarity checks on WSDL definitions.
* **AI Engine:** LangChain integrated with Gemini (using Google GenAI Embeddings/LLMs) with robust Mock provider fallbacks for offline execution.
* **PDF Compiler:** ReportLab library builds dynamic, highly compact, styled tabular comparison reports.

### 2. Frontend Client
* **Core Framework:** React 18, TypeScript, and Vite compiler.
* **State Management:** Zustand stores handle global active assessments, sidebar panels, and session history state.
* **Query Caching:** TanStack React Query schedules background logs polling and caches schema collections.
* **Visual Components:** Ant Design (V5) for clean layouts, collapses, statistics, and modal flows.
* **Interactive Graphs:** Custom D3 hierarchical rendering for service-to-service and data source connections.

---

## ⚙️ Prerequisites & System Requirements

Ensure the target system has the following runtimes installed:
* **Python:** Version `3.10` or `3.11`
* **Node.js:** Version `18.x` or `20.x` (includes `npm`)
* **OS:** Windows, macOS, or Linux

---

## 🚀 Step-by-Step Installation Guide

### Part A: Backend Setup

1. **Navigate to the Backend Directory:**
   ```bash
   cd backend
   ```

2. **Create a Virtual Environment:**
   * **Windows (PowerShell):**
     ```powershell
     python -m venv .venv
     .venv\Scripts\Activate.ps1
     ```
   * **macOS/Linux:**
     ```bash
     python3 -m venv .venv
     source .venv/bin/activate
     ```

3. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Environment Variables Configuration:**
   * Copy the `.env.example` file to `.env`:
     ```bash
     cp .env.example .env
     ```
   * Open `.env` and configure your API keys:
     ```env
     # SQLite database filepath
     DATABASE_URL=sqlite:///./service_analyzer.db
     # Google Gemini LLM API Key (Optional: fallbacks to Mock offline if empty)
     GOOGLE_API_KEY=your_gemini_api_key_here
     ```

5. **Start the FastAPI Server:**
   ```bash
   uvicorn app:app --reload --port 8000
   ```
   The backend API docs will be available at [http://localhost:8000/docs](http://localhost:8000/docs).

---

### Part B: Frontend Setup

1. **Navigate to the Frontend Directory:**
   ```bash
   cd ../frontend
   ```

2. **Install Node Modules:**
   ```bash
   npm install
   ```

3. **Configure Environment Variables:**
   * Copy the `.env.example` file to `.env` (if present) or verify configuration:
     ```env
     VITE_API_URL=http://localhost:8000/api/v1
     ```

4. **Run the Development Server:**
   ```bash
   npm run dev
   ```
   Open your browser and navigate to the application at [http://localhost:5173](http://localhost:5173).

5. **Production Compilation (Optional):**
   To compile and package the app for production:
   ```bash
   npm run build
   ```
   This generates an optimized static bundle in the `dist/` directory.

---

## 🔍 Core Features & User Manual

### 1. Home / Upload Section
* **Path Mode:** Enter a local absolute path to a folder repository containing WSDLs, or a single WSDL file.
* **Upload Mode:** Select local WSDL/XSD files (which will list in a collapsible summary panel) and choose your Excel database spreadsheet.
* **Process Flow:** Click **Analyze Services**. The screen automatically scrolls down to show real-time parsing, syntax verification, and relational schema database logs.
* **Auto-Redirect:** Upon successful scan completion, the application automatically redirects you to the **WSDL Extracts** tab.

### 2. Dependency Graph Explorer
* **Multiple Layouts:** Switch between **Combined View**, **Service-to-Service Only**, or **Data Source Only** configurations.
* **Flow Graph:** Interactive canvas mapping calling services, endpoints, and target data warehouses. Double-click on any service node to launch a detailed sub-graph focus canvas.
* **Unified Dependency Table:** Displays components as a unique catalog list with stats (operations count and dependency references) that expand to show individual schema attributes.

### 3. AI Assistant & Comparative Analytics
* **Interactive Q&A:** Ask questions about duplicates, similar payload schemas, and pattern reuses. Results are populated in structural feedback tabs.
* **Saved Chat Sessions:** Chat records are synced dynamically. When switching through different assessments in the history, the appropriate conversation history loads instantly.
* **Cross-Assessment Compare:** Select two completed assessments to compute a deterministic difference report (service counts, added/removed endpoints, operations, and schema field count changes) with a single-click styled PDF export.

---

## 💡 Troubleshooting & FAQs

* **Port Already in Use (8000):**
  If uvicorn fails to start, change the backend port:
  ```bash
  uvicorn app:app --reload --port 8080
  ```
  Ensure to update the frontend API base URL connection in `frontend/src/api/client.ts` to match.
* **VectorDB / Chromadb Installation Errors:**
  If Python fails compiling ChromaDB, make sure you have C++ Build Tools installed, or verify `requirements.txt` has the pre-built binaries selected.
* **SQLite Database Lock:**
  If you notice sqlite write locks, ensure you aren't running multiple server instances accessing the same database file simultaneously.
