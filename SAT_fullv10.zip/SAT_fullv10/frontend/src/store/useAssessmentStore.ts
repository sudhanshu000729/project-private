import { create } from "zustand";
import type { RunState } from "@/types";

type ThemeMode = 'light' | 'dark';

export type ChatMessage = {
  question: string;
  answer: string;
  duplicates: any[];
  similar_schemas: any[];
  pattern_reuse: any[];
  recommendations: any[];
  excel_download_url?: string;
  pdf_download_url?: string;
  grounded?: string[];
  stats?: {
    process_memory_mb: number;
    system_memory_percent: number;
    ai_tokens_used: number;
  };
};

type State = {
  assessmentId: number | null;
  assessmentCode: string | null;
  status: RunState;
  themeMode: ThemeMode;
  activeSection: string;
  dashboardOpen: boolean;
  chatHistories: Record<number, ChatMessage[]>;
  setAssessment: (id: number, code: string, status: RunState) => void;
  setStatus: (status: RunState) => void;
  setThemeMode: (mode: ThemeMode) => void;
  setActiveSection: (section: string) => void;
  setDashboardOpen: (open: boolean) => void;
  addChatMessage: (assessmentId: number, message: ChatMessage) => void;
  clearChatHistory: (assessmentId: number) => void;
  clear: () => void;
};

const getPersistedChatHistories = (): Record<number, ChatMessage[]> => {
  try {
    const data = sessionStorage.getItem("sat_chat_histories");
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
};

const savePersistedChatHistories = (histories: Record<number, ChatMessage[]>) => {
  try {
    sessionStorage.setItem("sat_chat_histories", JSON.stringify(histories));
  } catch (e) {
    console.error("Error saving chat history", e);
  }
};

export const useAssessmentStore = create<State>((set) => ({
  assessmentId: null,
  assessmentCode: null,
  status: null,
  themeMode: 'dark',
  activeSection: 'home',
  dashboardOpen: false,
  chatHistories: getPersistedChatHistories(),
  setAssessment: (assessmentId, assessmentCode, status) => set({ assessmentId, assessmentCode, status }),
  setStatus: (status) => set({ status }),
  setThemeMode: (themeMode) => set({ themeMode }),
  setActiveSection: (activeSection) => set({ activeSection }),
  setDashboardOpen: (dashboardOpen) => set({ dashboardOpen }),
  addChatMessage: (assessmentId, message) => set((state) => {
    const updated = {
      ...state.chatHistories,
      [assessmentId]: [...(state.chatHistories[assessmentId] || []), message]
    };
    savePersistedChatHistories(updated);
    return { chatHistories: updated };
  }),
  clearChatHistory: (assessmentId) => set((state) => {
    const updated = { ...state.chatHistories };
    delete updated[assessmentId];
    savePersistedChatHistories(updated);
    return { chatHistories: updated };
  }),
  clear: () => set({ assessmentId: null, assessmentCode: null, status: null })
}));

