import { Button, Layout, Space, Typography } from "antd";
import SATLogo from "./SATLogo";
import ThemeToggle from "./ThemeToggle";
import TcsLogo from "@/assets/tcs_logo.png";
import { appContent } from "@/config/content";
import { useAssessmentStore } from "@/store/useAssessmentStore";

const { Header } = Layout;

export default function HeaderBar(){
  const setDashboardOpen = useAssessmentStore((s) => s.setDashboardOpen);

  return (
    <Header className="dashboard-header" style={{padding:'0 20px',display:'flex',alignItems:'center',justifyContent:'space-between',gap:16}}>
      <Space size={12} wrap>
        <SATLogo />
        <div>
          <Typography.Title level={4} style={{margin:0, color:'#f6f8ff'}}>{appContent.title}</Typography.Title>
          <Typography.Text style={{color:'#aeb7ca'}}>Append-only WSDL and Excel assessment workspace</Typography.Text>
        </div>
      </Space>
      <Space size={10} wrap style={{ alignItems: 'center' }}>
        <img src={TcsLogo} alt="TCS Logo" style={{ height: 48, marginRight: 16, objectFit: 'contain' }} />
        <Button onClick={() => setDashboardOpen(true)}>Dashboard</Button>
        <ThemeToggle />
      </Space>
    </Header>
  );
}
