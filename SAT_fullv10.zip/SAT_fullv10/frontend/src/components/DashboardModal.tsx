import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Modal,
  Row,
  Col,
  Card,
  Statistic,
  Progress,
  Space,
  Typography,
  Tag,
  Timeline,
  Spin,
  Empty,
  Divider,
} from 'antd'
import {
  DatabaseOutlined,
  FileExcelOutlined,
  CodeOutlined,
  MergeCellsOutlined,
  CheckCircleOutlined,
  InfoCircleOutlined,
  ExclamationCircleOutlined,
  BranchesOutlined,
  WarningOutlined,
} from '@ant-design/icons'
import { fetchRawExtracts, fetchStructureSummary } from '@/features/reports/api'
import { fetchAssessmentLogs } from '@/features/analysis/api'
import { useAssessmentStore } from '@/store/useAssessmentStore'

type DashboardModalProps = {
  open: boolean
  onClose: () => void
}

export default function DashboardModal({ open, onClose }: DashboardModalProps) {
  const assessmentId = useAssessmentStore((s) => s.assessmentId)
  const assessmentCode = useAssessmentStore((s) => s.assessmentCode)
  const status = useAssessmentStore((s) => s.status)

  const enabled = !!assessmentId && open

  const rawQ = useQuery({
    queryKey: ['raw-extracts-dash', assessmentId],
    queryFn: () => fetchRawExtracts(assessmentId as number),
    enabled,
  })

  const structQ = useQuery({
    queryKey: ['structure-summary-dash', assessmentId],
    queryFn: () => fetchStructureSummary(assessmentId as number),
    enabled,
  })

  const logsQ = useQuery({
    queryKey: ['assessment-logs-dash', assessmentId],
    queryFn: () => fetchAssessmentLogs(assessmentId as number),
    enabled,
  })

  const loading = rawQ.isLoading || structQ.isLoading || logsQ.isLoading

  // Compute analytics
  const analytics = useMemo(() => {
    if (!rawQ.data?.merged_items) return null

    const items = rawQ.data.merged_items as any[]
    const total = items.length

    let exact = 0
    let partial = 0
    let unmatched = 0

    const dataSources = new Set<string>()
    const upstreamApps = new Set<string>()
    const downstreamApps = new Set<string>()
    
    const serviceOperationsMap: Record<string, Set<string>> = {}
    const serviceHasDepsMap: Record<string, boolean> = {}

    const dataSourcesCounts: Record<string, number> = {}
    const upstreamCounts: Record<string, number> = {}
    const downstreamCounts: Record<string, number> = {}

    items.forEach((item) => {
      const conf = item.matching_confidence
      if (conf === 1.0) exact++
      else if (conf === 0.5) partial++
      else unmatched++

      const sname = item.service_name
      const opname = item.operation_name

      if (sname) {
        if (!serviceOperationsMap[sname]) {
          serviceOperationsMap[sname] = new Set<string>()
        }
        if (opname) {
          serviceOperationsMap[sname].add(opname)
        }
      }

      // Count data sources
      const ds = item.data_sources_json || []
      ds.forEach((d: string) => {
        if (d.trim()) {
          dataSources.add(d.trim())
          dataSourcesCounts[d.trim()] = (dataSourcesCounts[d.trim()] || 0) + 1
          if (sname) serviceHasDepsMap[sname] = true
        }
      })

      // Count upstream apps
      const ups = item.upstream_apps_json || []
      ups.forEach((u: string) => {
        if (u.trim()) {
          upstreamApps.add(u.trim())
          upstreamCounts[u.trim()] = (upstreamCounts[u.trim()] || 0) + 1
          if (sname) serviceHasDepsMap[sname] = true
        }
      })

      // Count downstream apps
      const dns = item.downstream_apps_json || []
      dns.forEach((d: string) => {
        if (d.trim()) {
          downstreamApps.add(d.trim())
          downstreamCounts[d.trim()] = (downstreamCounts[d.trim()] || 0) + 1
          if (sname) serviceHasDepsMap[sname] = true
        }
      })
    })

    const totalServices = Object.keys(serviceOperationsMap).length
    let totalOperations = 0
    Object.values(serviceOperationsMap).forEach(ops => {
      totalOperations += ops.size
    })
    if (totalOperations === 0 && total > 0) {
      totalOperations = total
    }

    const avgOperationsPerService = totalServices > 0 
      ? (totalOperations / totalServices).toFixed(1) 
      : "0.0"

    const servicesWithDeps = Object.keys(serviceOperationsMap).filter(s => serviceHasDepsMap[s]).length
    const servicesWithoutDeps = totalServices - servicesWithDeps

    const topDataSources = Object.entries(dataSourcesCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)

    const topUpstream = Object.entries(upstreamCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)

    const topDownstream = Object.entries(downstreamCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)

    const matchRate = total > 0 ? Math.round(((exact + partial) / total) * 100) : 0

    return {
      total,
      exact,
      partial,
      unmatched,
      topDataSources,
      topUpstream,
      topDownstream,
      matchRate,
      totalServices,
      totalOperations,
      uniqueUpstreamCount: upstreamApps.size,
      uniqueDownstreamCount: downstreamApps.size,
      avgOperationsPerService,
      servicesWithDeps,
      servicesWithoutDeps
    }
  }, [rawQ.data])

  const wsdlCount = structQ.data?.counts?.wsdl_extracts ?? 0
  const excelCount = structQ.data?.counts?.excel_extracts ?? 0
  const mergedCount = structQ.data?.counts?.merged_reports ?? 0

  const logs = useMemo(() => {
    return Array.isArray(logsQ.data?.items) ? logsQ.data.items : []
  }, [logsQ.data])

  return (
    <Modal
      open={open}
      title={
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <MergeCellsOutlined style={{ color: '#4b5dff', fontSize: 20 }} />
          <span>
            Assessment Analysis Dashboard —{' '}
            <Tag color="blue" style={{ fontSize: 13, padding: '2px 8px' }}>
              Run {assessmentCode || 'n/a'}
            </Tag>
          </span>
        </div>
      }
      onCancel={onClose}
      footer={null}
      width={1350}
      destroyOnClose
      className="dashboard-modal-glass"
      style={{ top: 40 }}
    >
      {!assessmentId ? (
        <div style={{ padding: '40px 0' }}>
          <Empty description="No assessment has been opened or completed yet. Run or open an assessment first." />
        </div>
      ) : loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 400, gap: 16 }}>
          <Spin size="large" />
          <Typography.Text type="secondary">Compiling analysis metrics...</Typography.Text>
        </div>
      ) : (
        <Space direction="vertical" size="large" style={{ width: '100%', marginTop: 16 }}>
          {/* Top Metrics Cards Row */}
          <Row gutter={[16, 16]}>
            <Col xs={12} sm={8} md={6} lg={6}>
              <Card size="small" className="glass-card" style={{ textAlign: 'center', borderRadius: 12 }}>
                <Statistic
                  title={<span style={{ color: 'var(--text-soft)', fontSize: 12 }}>Total Services</span>}
                  value={analytics?.totalServices ?? 0}
                  prefix={<DatabaseOutlined style={{ color: '#4b5dff' }} />}
                />
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={6}>
              <Card size="small" className="glass-card" style={{ textAlign: 'center', borderRadius: 12 }}>
                <Statistic
                  title={<span style={{ color: 'var(--text-soft)', fontSize: 12 }}>Total Operations</span>}
                  value={analytics?.totalOperations ?? 0}
                  prefix={<CodeOutlined style={{ color: '#8b5cf6' }} />}
                />
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={6}>
              <Card size="small" className="glass-card" style={{ textAlign: 'center', borderRadius: 12 }}>
                <Statistic
                  title={<span style={{ color: 'var(--text-soft)', fontSize: 12 }}>Unique Upstream</span>}
                  value={analytics?.uniqueUpstreamCount ?? 0}
                  prefix={<BranchesOutlined style={{ color: '#10b981' }} />}
                />
              </Card>
            </Col>
            <Col xs={12} sm={8} md={6} lg={6}>
              <Card size="small" className="glass-card" style={{ textAlign: 'center', borderRadius: 12 }}>
                <Statistic
                  title={<span style={{ color: 'var(--text-soft)', fontSize: 12 }}>Unique Downstream</span>}
                  value={analytics?.uniqueDownstreamCount ?? 0}
                  prefix={<BranchesOutlined style={{ color: '#f59e0b' }} />}
                />
              </Card>
            </Col>
            <Col xs={12} sm={8} md={8} lg={8}>
              <Card size="small" className="glass-card" style={{ textAlign: 'center', borderRadius: 12 }}>
                <Statistic
                  title={<span style={{ color: 'var(--text-soft)', fontSize: 12 }}>Avg Operations / Service</span>}
                  value={analytics?.avgOperationsPerService ?? "0.0"}
                  prefix={<InfoCircleOutlined style={{ color: '#35c8ff' }} />}
                />
              </Card>
            </Col>
            <Col xs={12} sm={8} md={8} lg={8}>
              <Card size="small" className="glass-card" style={{ textAlign: 'center', borderRadius: 12 }}>
                <Statistic
                  title={<span style={{ color: 'var(--text-soft)', fontSize: 12 }}>Services With Deps</span>}
                  value={analytics?.servicesWithDeps ?? 0}
                  prefix={<CheckCircleOutlined style={{ color: '#10b981' }} />}
                />
              </Card>
            </Col>
            <Col xs={12} sm={8} md={8} lg={8}>
              <Card size="small" className="glass-card" style={{ textAlign: 'center', borderRadius: 12 }}>
                <Statistic
                  title={<span style={{ color: 'var(--text-soft)', fontSize: 12 }}>Services Without Deps</span>}
                  value={analytics?.servicesWithoutDeps ?? 0}
                  prefix={<ExclamationCircleOutlined style={{ color: '#f43f5e' }} />}
                />
              </Card>
            </Col>
          </Row>

          <Row gutter={[16, 16]}>
            {/* Left side: charts */}
            <Col xs={24} md={14}>
              <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                {/* Confidence breakdown */}
                <Card size="small" title="Matching Confidence Distribution" className="glass-card" style={{ borderRadius: 12 }}>
                  <Space direction="vertical" size="middle" style={{ width: '100%', padding: '8px 0' }}>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <Typography.Text><Tag color="green">100% Exact Match</Tag></Typography.Text>
                        <Typography.Text strong>{analytics?.exact} operations</Typography.Text>
                      </div>
                      <Progress 
                        percent={analytics?.total ? Math.round((analytics.exact / analytics.total) * 100) : 0} 
                        strokeColor="#10b981" 
                        trailColor="rgba(255,255,255,0.05)"
                      />
                    </div>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <Typography.Text><Tag color="orange">50% Service-Only Match</Tag></Typography.Text>
                        <Typography.Text strong>{analytics?.partial} operations</Typography.Text>
                      </div>
                      <Progress 
                        percent={analytics?.total ? Math.round((analytics.partial / analytics.total) * 100) : 0} 
                        strokeColor="#f59e0b" 
                        trailColor="rgba(255,255,255,0.05)"
                      />
                    </div>
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <Typography.Text><Tag color="red">0% Unmatched / Orphan WSDL</Tag></Typography.Text>
                        <Typography.Text strong>{analytics?.unmatched} operations</Typography.Text>
                      </div>
                      <Progress 
                        percent={analytics?.total ? Math.round((analytics.unmatched / analytics.total) * 100) : 0} 
                        strokeColor="#f43f5e" 
                        trailColor="rgba(255,255,255,0.05)"
                      />
                    </div>
                  </Space>
                </Card>

                {/* Top Data sources & Apps */}
                <Card size="small" title="Top Shared Data Sources" className="glass-card" style={{ borderRadius: 12 }}>
                  {analytics?.topDataSources.length === 0 ? (
                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No data source mappings" />
                  ) : (
                    <Space direction="vertical" size="small" style={{ width: '100%', padding: '4px 0' }}>
                      {analytics?.topDataSources.map(([ds, count]) => (
                        <div key={ds} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                          <Space size={8}>
                            <DatabaseOutlined style={{ color: '#35c8ff' }} />
                            <Typography.Text strong>{ds}</Typography.Text>
                          </Space>
                          <span style={{ display: 'flex', alignItems: 'center', gap: 12, width: '60%' }}>
                            <Progress 
                              percent={analytics?.total ? Math.round((count / analytics.total) * 100) : 0} 
                              showInfo={false} 
                              strokeColor="#35c8ff"
                              trailColor="rgba(255,255,255,0.05)"
                              style={{ margin: 0 }}
                            />
                            <Typography.Text type="secondary" style={{ fontSize: 12, minWidth: 50 }}>
                              {count} refs
                            </Typography.Text>
                          </span>
                        </div>
                      ))}
                    </Space>
                  )}
                </Card>
              </Space>
            </Col>

            {/* Right side: system timeline / logs */}
            <Col xs={24} md={10}>
              <Card 
                size="small" 
                title="E2E Assessment Process Timeline" 
                className="glass-card" 
                style={{ height: '100%', borderRadius: 12, overflow: 'auto', maxHeight: 420 }}
              >
                {logs.length === 0 ? (
                  <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No logs found" />
                ) : (
                  <Timeline
                    mode="left"
                    style={{ marginTop: 12 }}
                    items={logs.map((log: any) => {
                      const isError = log.level === 'ERROR'
                      const isWarning = log.level === 'WARNING'
                      
                      let dot = <CheckCircleOutlined style={{ color: '#10b981', fontSize: 16 }} />
                      if (isError) {
                        dot = <ExclamationCircleOutlined style={{ color: '#f43f5e', fontSize: 16 }} />
                      } else if (isWarning) {
                        dot = <WarningOutlined style={{ color: '#f59e0b', fontSize: 16 }} />
                      } else if (log.step === 'start') {
                        dot = <InfoCircleOutlined style={{ color: '#4b5dff', fontSize: 16 }} />
                      }

                      return {
                        dot,
                        children: (
                          <div style={{ marginBottom: 4 }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                              <Typography.Text strong style={{ fontSize: 12, color: 'var(--page-text)' }}>
                                {log.step.toUpperCase().replace('_', ' ')}
                              </Typography.Text>
                              <Typography.Text type="secondary" style={{ fontSize: 10 }}>
                                {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                              </Typography.Text>
                            </div>
                            <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block', lineHeight: '14px', marginTop: 2 }}>
                              {log.message}
                            </Typography.Text>
                          </div>
                        )
                      }
                    })}
                  />
                )}
              </Card>
            </Col>
          </Row>

          {/* Placeholder Spaces for Future Charts & Trends */}
          <Row gutter={[16, 16]}>
            <Col xs={24} md={12}>
              <Card size="small" title="Future Analytics: Charts & Pie Charts" className="glass-card" style={{ borderRadius: 12, height: '100%', minHeight: 200 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 140, border: '2px dashed var(--stroke)', borderRadius: 8 }}>
                  <BranchesOutlined style={{ fontSize: 24, color: 'var(--text-soft)', marginBottom: 8 }} />
                  <Typography.Text type="secondary" strong style={{ fontSize: 12 }}>Distribution Pie Chart Placeholder</Typography.Text>
                  <Typography.Text type="secondary" style={{ fontSize: 10 }}>Future release will render interactive contract overlap analytics.</Typography.Text>
                </div>
              </Card>
            </Col>
            <Col xs={24} md={12}>
              <Card size="small" title="Future Release: Trend Graphs" className="glass-card" style={{ borderRadius: 12, height: '100%', minHeight: 200 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 140, border: '2px dashed var(--stroke)', borderRadius: 8 }}>
                  <DatabaseOutlined style={{ fontSize: 24, color: 'var(--text-soft)', marginBottom: 8 }} />
                  <Typography.Text type="secondary" strong style={{ fontSize: 12 }}>Cross-Assessment Trend Graph Placeholder</Typography.Text>
                  <Typography.Text type="secondary" style={{ fontSize: 10 }}>Future release will display system migration path metrics.</Typography.Text>
                </div>
              </Card>
            </Col>
          </Row>

          <Divider style={{ margin: '8px 0', borderColor: 'rgba(255,255,255,0.06)' }} />
          
          {/* Metadata details */}
          <div style={{ background: 'rgba(255,255,255,0.01)', padding: 12, borderRadius: 8, border: '1px solid rgba(255,255,255,0.04)' }}>
            <Row gutter={[16, 8]}>
              <Col span={12}>
                <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block' }}>WSDL Source Directory / File Path:</Typography.Text>
                <Typography.Text style={{ fontSize: 12, fontFamily: 'monospace', wordBreak: 'break-all' }}>{structQ.data?.assessment?.wsdl_path || 'n/a'}</Typography.Text>
              </Col>
              <Col span={12}>
                <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block' }}>Excel Metadata File Path:</Typography.Text>
                <Typography.Text style={{ fontSize: 12, fontFamily: 'monospace', wordBreak: 'break-all' }}>{structQ.data?.assessment?.excel_path || 'n/a'}</Typography.Text>
              </Col>
            </Row>
          </div>
        </Space>
      )}
    </Modal>
  )
}
