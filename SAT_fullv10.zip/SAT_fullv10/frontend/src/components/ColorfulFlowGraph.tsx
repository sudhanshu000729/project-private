import { useMemo, useState } from "react";
import { useAssessmentStore } from "@/store/useAssessmentStore";
import { Background, Controls, MiniMap, ReactFlow, MarkerType } from "@xyflow/react";
import { Card, Row, Col, Space, Typography, Tag, Segmented, Input, Select, Button, Tree, Alert, Modal, Slider, Flex, Empty, Tooltip } from "antd";
import { 
  BranchesOutlined, 
  InfoCircleOutlined, 
  CloseOutlined, 
  DatabaseOutlined, 
  FilterOutlined,
  CheckCircleOutlined,
  ExclamationCircleOutlined,
  WarningOutlined,
  FullscreenOutlined,
  FullscreenExitOutlined,
  DownloadOutlined,
  SearchOutlined
} from "@ant-design/icons";

type EdgeRow = {
  source: string;
  target: string;
  type?: string;
};

type ColorfulFlowGraphProps = {
  rows: EdgeRow[];
  serviceSummary: any[];
  wsdlExtracts: any[];
  selectedNode?: string | null;
  setSelectedNode?: (n: string | null) => void;
};

type FocusMode = 'Full' | '1-hop' | '2-hop' | 'Inbound' | 'Outbound';
type GraphView = 'Flowchart' | 'Tree' | 'ServiceList';

export default function ColorfulFlowGraph({ 
  rows, 
  serviceSummary = [], 
  wsdlExtracts = [],
  selectedNode: externalSelectedNode,
  setSelectedNode: externalSetSelectedNode
}: ColorfulFlowGraphProps) {
  const themeMode = useAssessmentStore((s) => s.themeMode);
  const isDark = false;
  const [viewMode, setViewMode] = useState<GraphView>('Flowchart');
  
  const [internalSelectedNode, internalSetSelectedNode] = useState<string | null>(null);
  const selectedNode = externalSelectedNode !== undefined ? externalSelectedNode : internalSelectedNode;
  const setSelectedNode = externalSetSelectedNode !== undefined ? externalSetSelectedNode : internalSetSelectedNode;

  const [focusMode, setFocusMode] = useState<FocusMode>('Full');

  const [serviceListStates, setServiceListStates] = useState<Record<string, { showDs: boolean; showUp: boolean; showDn: boolean }>>({});
  const toggleServiceListState = (sname: string, key: 'showDs' | 'showUp' | 'showDn') => {
    setServiceListStates(prev => {
      const current = prev[sname] || { showDs: false, showUp: false, showDn: false };
      return {
        ...prev,
        [sname]: {
          ...current,
          [key]: !current[key]
        }
      };
    });
  };

  // Neighborhood focused modal states
  const [modalOpen, setModalOpen] = useState(false);
  const [doubleClickedNode, setDoubleClickedNode] = useState<string | null>(null);
  const [modalDirection, setModalDirection] = useState<'upstream' | 'downstream' | 'both' | 'full'>('both');
  const [modalNodeType, setModalNodeType] = useState<'services' | 'datasources' | 'all'>('all');
  const [modalDepth, setModalDepth] = useState<number>(1);
  const [modalSearch, setModalSearch] = useState('');
  const [modalFullscreen, setModalFullscreen] = useState(false);
  
  // Advanced filters state
  const [serviceSearch, setServiceSearch] = useState('');
  const [errorStateFilter, setErrorStateFilter] = useState<string>('all');

  // Service lookup maps to compute health and details
  const serviceDetailMap = useMemo(() => {
    const map: Record<string, any> = {};
    serviceSummary.forEach(s => {
      map[s.service_name] = s;
    });
    return map;
  }, [serviceSummary]);

  const serviceDiagnosticsMap = useMemo(() => {
    const map: Record<string, { isError: boolean; isWarning: boolean; messages: string[] }> = {};
    wsdlExtracts.forEach(w => {
      const sname = w.service_name;
      if (!map[sname]) {
        map[sname] = { isError: false, isWarning: false, messages: [] };
      }
      // Check request, response, error diagnostics
      const req = w.diagnostics?.request || {};
      const resp = w.diagnostics?.response || {};
      const err = w.diagnostics?.error || {};

      if (req.malformed || resp.malformed || err.malformed) {
        map[sname].isError = true;
        map[sname].messages.push(`Operation '${w.operation_name}' is malformed.`);
      }
      if (req.missing || resp.missing) {
        map[sname].isError = true;
        map[sname].messages.push(`Operation '${w.operation_name}' has missing payload schemas.`);
      }
      if (req.child_elements_missing || resp.child_elements_missing) {
        map[sname].isWarning = true;
        map[sname].messages.push(`Operation '${w.operation_name}' has empty element structures.`);
      }
    });
    return map;
  }, [wsdlExtracts]);

  const handleNodeDoubleClick = (nodeId: string) => {
    setModalDepth(1);
    setDoubleClickedNode(nodeId);
    setModalOpen(true);
  };

  const allDataSourceNames = useMemo(() => {
    const dsSet = new Set<string>();
    rows.forEach(r => {
      if (r.type === 'data_source') {
        dsSet.add(r.source);
      }
    });
    return dsSet;
  }, [rows]);

  const getNeighborhoodGraph = (center: string, maxDepth: number, dir: string, nType: string) => {
    const visitedNodes = new Set<string>();
    const edges: EdgeRow[] = [];

    const traverse = (currentNode: string, currentDepth: number) => {
      if (currentDepth > maxDepth) return;
      visitedNodes.add(currentNode);

      rows.forEach(edge => {
        const isUpstream = edge.target === currentNode;
        const isDownstream = edge.source === currentNode;

        if (isUpstream && (dir === 'upstream' || dir === 'both' || dir === 'full')) {
          if (!visitedNodes.has(edge.source)) {
            edges.push(edge);
            traverse(edge.source, currentDepth + 1);
          } else if (!edges.some(e => e.source === edge.source && e.target === edge.target)) {
            edges.push(edge);
          }
        }

        if (isDownstream && (dir === 'downstream' || dir === 'both' || dir === 'full')) {
          if (!visitedNodes.has(edge.target)) {
            edges.push(edge);
            traverse(edge.target, currentDepth + 1);
          } else if (!edges.some(e => e.source === edge.source && e.target === edge.target)) {
            edges.push(edge);
          }
        }
      });
    };

    traverse(center, 0);

    const finalNodes = Array.from(visitedNodes).filter(nodeId => {
      const isDs = allDataSourceNames.has(nodeId);
      if (nType === 'services' && isDs) return false;
      if (nType === 'datasources' && !isDs) return false;
      return true;
    });

    let finalEdges = edges.filter(e => finalNodes.includes(e.source) && finalNodes.includes(e.target));
    if (maxDepth === 1) {
      finalEdges = finalEdges.filter(e => e.source === center || e.target === center);
    }

    return { nodes: finalNodes, edges: finalEdges };
  };

  const modalGraphData = useMemo(() => {
    if (!doubleClickedNode) return { nodes: [], edges: [] };
    
    const { nodes: neighborhoodNodes, edges: neighborhoodEdges } = getNeighborhoodGraph(
      doubleClickedNode,
      modalDepth,
      modalDirection,
      modalNodeType
    );

    const flowNodes = neighborhoodNodes.map((nodeId, idx) => {
      const isCenter = nodeId === doubleClickedNode;
      const isDs = allDataSourceNames.has(nodeId);
      const isMatchSearch = modalSearch.trim() && nodeId.toLowerCase().includes(modalSearch.toLowerCase());
      
      let borderStyle = isCenter ? '2px solid #4b5dff' : '1px solid rgba(88, 104, 184, 0.20)';
      let bgColor = isCenter ? '#eef2ff' : '#ffffff';
      let textColor = '#121826';
      
      if (isDs) {
        borderStyle = '2px solid #8B5CF6';
        bgColor = '#F5F3FF';
        textColor = '#5B21B6';
      }

      const shadow = isMatchSearch 
        ? '0 0 25px rgba(239, 68, 68, 0.8), 0 6px 18px rgba(0,0,0,0.1)'
        : isCenter 
          ? '0 0 20px rgba(75, 93, 255, 0.4), 0 6px 18px rgba(0,0,0,0.06)' 
          : '0 6px 18px rgba(0,0,0,0.06)';

      if (isMatchSearch) {
        borderStyle = '2px solid #ef4444';
      }

      return {
        id: nodeId,
        data: {
          label: (
            <div style={{ textAlign: 'left', padding: '2px 4px' }}>
              <span style={{ fontWeight: 'bold', display: 'block', color: textColor, fontSize: '12px' }}>
                {nodeId}
              </span>
              <Tag style={{ marginTop: 6 }}>
                {isCenter ? 'Center Focus' : isDs ? 'Data Source' : 'Service'}
              </Tag>
            </div>
          )
        },
        position: { x: (idx % 3) * 300, y: Math.floor(idx / 3) * 160 },
        width: 220,
        height: 80,
        style: {
          background: bgColor,
          color: textColor,
          border: borderStyle,
          borderRadius: 14,
          padding: 10,
          boxShadow: shadow,
          cursor: 'pointer'
        }
      };
    });

    const flowEdges = neighborhoodEdges.map((e, idx) => {
      let strokeColor = '#4B5DFF';
      let animated = true;
      let styleDash = undefined;

      if (e.type === 'data_source') {
        strokeColor = '#F59E0B';
        styleDash = '5,5';
        animated = false;
      }

      return {
        id: `modal-edge-${e.source}-${e.target}-${idx}`,
        source: e.source,
        target: e.target,
        animated,
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: strokeColor,
          width: 16,
          height: 16
        },
        style: {
          stroke: strokeColor,
          strokeWidth: 2,
          strokeDasharray: styleDash
        }
      };
    });

    return { nodes: flowNodes, edges: flowEdges };
  }, [doubleClickedNode, modalDepth, modalDirection, modalNodeType, modalSearch]);

  const exportAsSvg = () => {
    if (!doubleClickedNode) return;
    let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600" style="background:#0b0d19;font-family:sans-serif;">`;
    
    // defs for markers
    svgContent += `
      <defs>
        <marker id="arrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#4b5dff"/>
        </marker>
      </defs>
    `;

    modalGraphData.edges.forEach(e => {
      const sourceNode = modalGraphData.nodes.find(n => n.id === e.source);
      const targetNode = modalGraphData.nodes.find(n => n.id === e.target);
      if (sourceNode && targetNode) {
        svgContent += `<line x1="${sourceNode.position.x + 110}" y1="${sourceNode.position.y + 40}" x2="${targetNode.position.x + 110}" y2="${targetNode.position.y + 40}" stroke="#4b5dff" stroke-width="2" marker-end="url(#arrow)"/>`;
      }
    });

    modalGraphData.nodes.forEach(n => {
      svgContent += `
        <rect x="${n.position.x}" y="${n.position.y}" width="220" height="80" rx="14" fill="#161b33" stroke="#4b5dff" stroke-width="2"/>
        <text x="${n.position.x + 20}" y="${n.position.y + 45}" fill="#ffffff" font-size="12" font-weight="bold">${n.id}</text>
      `;
    });

    svgContent += `</svg>`;
    
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `focused_neighborhood_${doubleClickedNode}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Compute filtered dataset based on advanced filters
  const filteredRows = useMemo(() => {
    return rows.filter(row => {
      // 1. Service Search filter
      if (serviceSearch.trim()) {
        const query = serviceSearch.toLowerCase();
        const matchesSource = row.source?.toLowerCase().includes(query);
        const matchesTarget = row.target?.toLowerCase().includes(query);
        if (!matchesSource && !matchesTarget) return false;
      }
      // 2. Error state filter
      if (errorStateFilter !== 'all') {
        const srcHealth = serviceDiagnosticsMap[row.source];
        const tgtHealth = serviceDiagnosticsMap[row.target];
        const srcIsError = srcHealth?.isError;
        const tgtIsError = tgtHealth?.isError;
        if (errorStateFilter === 'error' && !srcIsError && !tgtIsError) return false;
        if (errorStateFilter === 'healthy' && (srcIsError || tgtIsError)) return false;
      }
      return true;
    });
  }, [rows, serviceSearch, errorStateFilter, serviceDiagnosticsMap]);

  // Focus-mode graph computation
  const { nodes, edges } = useMemo(() => {
    let activeEdges = [...filteredRows];
    
    // Nodes that exist in our dataset
    const uniqueLabels = Array.from(new Set(activeEdges.flatMap((r) => [r.source, r.target]).filter(Boolean)));
    
    // Apply Focus Mode logic if a node is selected
    if (selectedNode && uniqueLabels.includes(selectedNode)) {
      if (focusMode === '1-hop') {
        activeEdges = activeEdges.filter(r => r.source === selectedNode || r.target === selectedNode);
      } else if (focusMode === '2-hop') {
        const directNeighbors = new Set(
          activeEdges
            .filter(r => r.source === selectedNode || r.target === selectedNode)
            .flatMap(r => [r.source, r.target])
        );
        activeEdges = activeEdges.filter(r => directNeighbors.has(r.source) && directNeighbors.has(r.target));
      } else if (focusMode === 'Inbound') {
        // Trace inbound recursively or just direct inbound
        activeEdges = activeEdges.filter(r => r.target === selectedNode);
      } else if (focusMode === 'Outbound') {
        activeEdges = activeEdges.filter(r => r.source === selectedNode);
      }
    }

    const activeLabels = Array.from(new Set(activeEdges.flatMap((r) => [r.source, r.target]).filter(Boolean)));

    // Categorize nodes and edges for selectedNode path highlighting
    const upstreamNodes = new Set<string>();
    const downstreamNodes = new Set<string>();
    const datasourceNodes = new Set<string>();
    const upstreamEdges = new Set<string>();
    const downstreamEdges = new Set<string>();
    const datasourceEdges = new Set<string>();

    if (selectedNode && uniqueLabels.includes(selectedNode)) {
      // Build adjacency list for forward/backward traversal
      const forward: Record<string, { target: string; edgeId: string; type?: string }[]> = {};
      const backward: Record<string, { source: string; edgeId: string; type?: string }[]> = {};
      
      activeEdges.forEach((row, idx) => {
        const edgeId = `${row.source}-${row.target}-${idx}`;
        if (!forward[row.source]) forward[row.source] = [];
        forward[row.source].push({ target: row.target, edgeId, type: row.type });
        
        if (!backward[row.target]) backward[row.target] = [];
        backward[row.target].push({ source: row.source, edgeId, type: row.type });
      });

      // BFS Downstream & Datasource
      const queueDown = [{ node: selectedNode, isDs: false }];
      const visitedDown = new Set<string>([selectedNode]);
      while (queueDown.length > 0) {
        const { node, isDs } = queueDown.shift()!;
        const neighbors = forward[node] || [];
        neighbors.forEach(({ target, edgeId, type }) => {
          const nextIsDs = isDs || type === 'data_source';
          if (nextIsDs) {
            datasourceNodes.add(target);
            datasourceEdges.add(edgeId);
          } else {
            downstreamNodes.add(target);
            downstreamEdges.add(edgeId);
          }
          if (!visitedDown.has(target)) {
            visitedDown.add(target);
            queueDown.push({ node: target, isDs: nextIsDs });
          }
        });
      }

      // BFS Upstream
      const queueUp = [selectedNode];
      const visitedUp = new Set<string>([selectedNode]);
      while (queueUp.length > 0) {
        const curr = queueUp.shift()!;
        const parents = backward[curr] || [];
        parents.forEach(({ source, edgeId }) => {
          upstreamNodes.add(source);
          upstreamEdges.add(edgeId);
          if (!visitedUp.has(source)) {
            visitedUp.add(source);
            queueUp.push(source);
          }
        });
      }
    }

    // Styles & Node positions (wider spacing to prevent edge label overlap)
    const nodesList = activeLabels.map((label, idx) => {
      const diag = serviceDiagnosticsMap[label];
      const isSelected = label === selectedNode;
      
      let borderStyle = '1px solid rgba(88, 104, 184, 0.20)';
      let bgColor = '#ffffff';
      let textColor = '#121826';
      let opacity = 1.0;
      let nodeBadge = null;

      if (!selectedNode) {
        // Color scheme based on error state
        if (diag?.isError) {
          bgColor = '#FEF2F2'; // Light Red
          borderStyle = '1px solid #FCA5A5';
          textColor = '#991B1B';
          nodeBadge = <Tag style={{ margin: 0, backgroundColor: '#fee2e2', color: '#b91c1c', borderColor: '#fecaca' }}>Error Node</Tag>;
        } else if (diag?.isWarning) {
          bgColor = '#FFFBEB'; // Light Yellow
          borderStyle = '1px solid #FCD34D';
          textColor = '#92400E';
          nodeBadge = <Tag style={{ margin: 0, backgroundColor: '#fef3c7', color: '#b45309', borderColor: '#fde68a' }}>Warning</Tag>;
        } else {
          bgColor = '#F0FDF4'; // Light Green / Success
          borderStyle = '1px solid #A7F3D0';
          textColor = '#065F46';
          nodeBadge = <Tag style={{ margin: 0, backgroundColor: '#dcfce7', color: '#15803d', borderColor: '#bbf7d0' }}>Active</Tag>;
        }
      } else {
        // A node is selected
        if (isSelected) {
          borderStyle = '3px solid #4B5DFF';
          bgColor = '#ffffff';
          textColor = '#121826';
          nodeBadge = <Tag style={{ margin: 0, backgroundColor: '#e0e7ff', color: '#4338ca', borderColor: '#c7d2fe' }}>Selected</Tag>;
        } else if (upstreamNodes.has(label)) {
          borderStyle = '2px solid #10B981'; // Green
          bgColor = '#ECFDF5';
          textColor = '#065F46';
          nodeBadge = <Tag style={{ margin: 0, backgroundColor: '#dcfce7', color: '#15803d', borderColor: '#bbf7d0' }}>Upstream Caller</Tag>;
        } else if (downstreamNodes.has(label)) {
          borderStyle = '2px solid #3B82F6'; // Blue
          bgColor = '#EFF6FF';
          textColor = '#1E3A8A';
          nodeBadge = <Tag style={{ margin: 0, backgroundColor: '#dbeafe', color: '#1d4ed8', borderColor: '#bfdbfe' }}>Downstream Callee</Tag>;
        } else if (datasourceNodes.has(label)) {
          borderStyle = '2px solid #8B5CF6'; // Purple
          bgColor = '#F5F3FF';
          textColor = '#5B21B6';
          nodeBadge = <Tag style={{ margin: 0, backgroundColor: '#f3e8ff', color: '#6b21a8', borderColor: '#e9d5ff' }}>Data Source</Tag>;
        } else {
          // Unrelated
          opacity = 0.40;
          if (diag?.isError) {
            bgColor = '#FEF2F2';
            borderStyle = '1px solid #FCA5A5';
            textColor = '#991B1B';
          } else if (diag?.isWarning) {
            bgColor = '#FFFBEB';
            borderStyle = '1px solid #FCD34D';
            textColor = '#92400E';
          } else {
            bgColor = '#F0FDF4';
            borderStyle = '1px solid #A7F3D0';
            textColor = '#065F46';
          }
        }
      }

      return {
        id: label,
        data: { 
          label: (
            <div style={{ textAlign: 'left', padding: '2px 4px' }}>
              <span style={{ fontWeight: 'bold', display: 'block', color: textColor, fontSize: '12px' }}>
                {label}
              </span>
              <Space style={{ marginTop: 6 }} size={4}>
                {nodeBadge}
                {diag?.isError && <ExclamationCircleOutlined style={{ color: '#EF4444' }} />}
              </Space>
            </div>
          )
        },
        position: { x: (idx % 3) * 380, y: Math.floor(idx / 3) * 240 },
        width: 220,
        height: 80,
        style: {
          background: bgColor,
          color: textColor,
          border: borderStyle,
          borderRadius: 14,
          padding: 10,
          boxShadow: isSelected ? '0 0 20px rgba(75, 93, 255, 0.4), 0 6px 18px rgba(0,0,0,0.06)' : '0 6px 18px rgba(0,0,0,0.06)',
          width: 220,
          cursor: 'pointer',
          opacity: opacity
        }
      };
    });

    const edgesList = activeEdges.map((row, idx) => {
      const edgeId = `${row.source}-${row.target}-${idx}`;
      let strokeColor = '#4B5DFF'; // default Request/blue
      let animated = idx % 2 === 0;
      let styleDash = undefined;
      let opacity = 1.0;

      if (row.type === 'data_source') {
        strokeColor = '#F59E0B'; // Yellow for data source
        styleDash = '5,5'; // Dotted Line
        animated = false;
      } else if (row.type === 'consumer') {
        strokeColor = '#7A41FF'; // Purple for response/consumer flow
        styleDash = '4,4';
      }

      if (selectedNode) {
        if (upstreamEdges.has(edgeId)) {
          strokeColor = '#10B981'; // Green
          opacity = 1.0;
          animated = true;
        } else if (downstreamEdges.has(edgeId)) {
          strokeColor = '#3B82F6'; // Blue
          opacity = 1.0;
          animated = true;
        } else if (datasourceEdges.has(edgeId)) {
          strokeColor = '#8B5CF6'; // Purple
          opacity = 1.0;
          animated = true;
        } else {
          opacity = 0.15;
          animated = false;
        }
      }

      return {
        id: edgeId,
        source: row.source,
        target: row.target,
        label: row.type || "",
        animated: animated,
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: strokeColor,
          width: 20,
          height: 20
        },
        style: { 
          stroke: strokeColor, 
          strokeWidth: selectedNode && (upstreamEdges.has(edgeId) || downstreamEdges.has(edgeId) || datasourceEdges.has(edgeId)) ? 3.0 : 2.2,
          strokeDasharray: styleDash,
          opacity: opacity
        },
        labelStyle: { fill: strokeColor, fontSize: 9, fontWeight: 600, opacity: opacity }
      };
    });

    return { nodes: nodesList, edges: edgesList };
  }, [filteredRows, selectedNode, focusMode, serviceDiagnosticsMap, isDark]);

  // Compute Tree View Hierarchical Data
  const treeData = useMemo(() => {
    const nodesSet = new Set(filteredRows.flatMap(r => [r.source, r.target]).filter(Boolean));
    const adjacency: Record<string, string[]> = {};
    const targets = new Set<string>();

    filteredRows.forEach(row => {
      if (!adjacency[row.source]) adjacency[row.source] = [];
      adjacency[row.source].push(row.target);
      targets.add(row.target);
    });

    // Root nodes are nodes that never appear as targets in any connection
    const roots = Array.from(nodesSet).filter(n => !targets.has(n));
    const displayRoots = roots.length > 0 ? roots : Array.from(nodesSet).slice(0, 3);

    const buildSubtree = (nodeId: string, visited: Set<string>, parentPath: string = ""): any => {
      const isCircular = visited.has(nodeId);
      const childList = isCircular ? [] : (adjacency[nodeId] || []);
      const nextVisited = new Set(visited).add(nodeId);
      
      const currentPath = parentPath ? `${parentPath}-${nodeId}` : nodeId;
      const diag = serviceDiagnosticsMap[nodeId];
      let titleElement = (
        <span style={{ fontSize: 13, cursor: 'pointer' }} onDoubleClick={() => handleNodeDoubleClick(nodeId)}>
          {nodeId}{" "}
          {diag?.isError ? (
            <Tag color="red">Error State</Tag>
          ) : diag?.isWarning ? (
            <Tag color="warning">Warning</Tag>
          ) : null}
          {isCircular && <Tag color="default">circular</Tag>}
        </span>
      );

      return {
        title: titleElement,
        key: currentPath + (isCircular ? "-circular" : ""),
        icon: diag?.isError ? <ExclamationCircleOutlined style={{ color: '#EF4444' }} /> : <DatabaseOutlined />,
        children: childList.map(child => buildSubtree(child, nextVisited, currentPath))
      };
    };

    return displayRoots.map(root => buildSubtree(root, new Set(), ""));
  }, [filteredRows, serviceDiagnosticsMap]);

  const selectedServiceDetails = useMemo(() => {
    if (!selectedNode) return null;
    return serviceDetailMap[selectedNode] || null;
  }, [selectedNode, serviceDetailMap]);

  return (
    <Space direction="vertical" size="middle" style={{ width: '100%' }}>
      {/* 1. Control Bar Panel */}
      <Card className="glass-card" size="small">
        <Row gutter={[16, 16]} align="middle" justify="space-between">
          <Col>
            <Space>
              <BranchesOutlined style={{ color: '#4b5dff', fontSize: 18 }} />
              <Typography.Title level={5} style={{ margin: 0 }}>View Options:</Typography.Title>
              <Segmented
                options={[
                  { label: 'Flowchart View', value: 'Flowchart' },
                  { label: 'Hierarchical View', value: 'Tree' },
                  { label: 'Service Dependency List', value: 'ServiceList' }
                ]}
                value={viewMode}
                onChange={(v) => setViewMode(v as GraphView)}
              />
            </Space>
          </Col>
          
          <Col flex="auto" style={{ maxWidth: 640 }}>
            <Space style={{ width: '100%', justifyContent: 'flex-end' }} wrap>
              <Input
                placeholder="Search service..."
                prefix={<FilterOutlined style={{ color: 'var(--text-soft)' }} />}
                value={serviceSearch}
                onChange={(e) => setServiceSearch(e.target.value)}
                style={{ width: 170 }}
                allowClear
              />

              <Select
                value={errorStateFilter}
                onChange={setErrorStateFilter}
                style={{ width: 140 }}
                options={[
                  { label: 'All Node States', value: 'all' },
                  { label: 'Error Nodes Only', value: 'error' },
                  { label: 'Healthy Nodes Only', value: 'healthy' }
                ]}
              />
            </Space>
          </Col>
        </Row>

        {selectedNode && viewMode === 'Flowchart' && (
          <div style={{ marginTop: 12, borderTop: '1px solid var(--stroke)', paddingTop: 12 }}>
            <Space wrap>
              <Typography.Text type="secondary">Focus Mode for <strong style={{ color: 'var(--page-text)' }}>{selectedNode}</strong>:</Typography.Text>
              <Segmented
                options={['Full', '1-hop', '2-hop', 'Inbound', 'Outbound']}
                value={focusMode}
                onChange={(v) => setFocusMode(v as FocusMode)}
              />
              <Button 
                type="text" 
                icon={<CloseOutlined />} 
                onClick={() => {
                  setSelectedNode(null);
                  setFocusMode('Full');
                }}
              >
                Clear Focus
              </Button>
            </Space>
          </div>
        )}
      </Card>

      {/* 2. Main Graph Area / Tree view */}
      <Row gutter={[16, 16]} style={{ minHeight: 480 }}>
        <Col span={selectedNode && viewMode !== 'ServiceList' ? 16 : 24}>
          <Card className="glass-card" style={{ height: '100%', overflow: 'hidden' }} bodyStyle={{ padding: 0, height: 500 }}>
            {viewMode === 'Flowchart' ? (
              <div className='flow-panel' style={{ height: '100%', width: '100%' }}>
                <ReactFlow 
                  nodes={nodes} 
                  edges={edges}
                  onNodeClick={(_, node) => {
                    setSelectedNode(node.id);
                  }}
                  onNodeDoubleClick={(_, node) => {
                    handleNodeDoubleClick(node.id);
                  }}
                  fitView
                >
                  <MiniMap
                    nodeColor={(node) => {
                      if (node.id === selectedNode) return '#4b5dff';
                      const diag = serviceDiagnosticsMap[node.id];
                      if (diag?.isError) return '#ef4444';
                      if (diag?.isWarning) return '#f59e0b';
                      return '#10b981';
                    }}
                    nodeStrokeColor="#cbd5e1"
                    nodeBorderRadius={3}
                  />
                  <Controls />
                  <Background />
                </ReactFlow>
              </div>
            ) : viewMode === 'Tree' ? (
              <div style={{ padding: 24, height: '100%', overflow: 'auto' }}>
                <Typography.Title level={5}>Complete Dependency Hierarchy Tree</Typography.Title>
                <Typography.Paragraph type="secondary">
                  Explore complete nested upstream & downstream relationship chains. Expand nodes to drill down.
                </Typography.Paragraph>
                {treeData.length === 0 ? (
                  <Alert message="No tree nodes matching the current filter settings" type="info" showIcon />
                ) : (
                  <Tree
                    showIcon
                    showLine
                    defaultExpandAll
                    treeData={treeData}
                    onSelect={(selectedKeys) => {
                      if (selectedKeys.length > 0) {
                        // strip circular suffix if clicked
                        const key = String(selectedKeys[0]).replace("-circular", "");
                        setSelectedNode(key);
                      }
                    }}
                  />
                )}
              </div>
            ) : (
              <div style={{ padding: 24, height: '100%', overflow: 'auto' }}>
                <Typography.Title level={5}>Ordered Service Hierarchy & Dependencies</Typography.Title>
                <Typography.Paragraph type="secondary">
                  Numbered unique services with direct action buttons to toggle data source, upstream, or downstream dependencies.
                </Typography.Paragraph>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {serviceSummary.map((svc, idx) => {
                    const sname = svc.service_name;
                    const state = serviceListStates[sname] || { showDs: false, showUp: false, showDn: false };
                    
                    const dsources = rows.filter(r => r.type === 'data_source' && r.target === sname).map(r => r.source);
                    const upstreams = rows.filter(r => r.type !== 'data_source' && r.target === sname).map(r => r.source);
                    const downstreams = rows.filter(r => r.type !== 'data_source' && r.source === sname).map(r => r.target);
                    
                    return (
                      <div key={sname} style={{ display: 'flex', flexDirection: 'column', padding: '12px 16px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid rgba(88, 104, 184, 0.12)', borderRadius: 8 }}>
                        <Flex align="center" justify="space-between" wrap gap={12}>
                          <Space size={8}>
                            <Typography.Text strong style={{ color: 'var(--text-soft)' }}>{idx + 1}.</Typography.Text>
                            <Typography.Text 
                              strong 
                              style={{ fontSize: 13, color: '#4b5dff', cursor: 'pointer', borderBottom: '1px dashed #4b5dff' }}
                              onClick={() => handleNodeDoubleClick(sname)}
                              title="Click to view flowchart"
                            >
                              {sname}
                            </Typography.Text>
                            <Button 
                              type="text" 
                              size="small" 
                              icon={<BranchesOutlined style={{ color: '#4b5dff', fontSize: 13 }} />} 
                              onClick={() => handleNodeDoubleClick(sname)}
                              title="Open Flowchart Modal"
                              style={{ borderRadius: 6, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: 0, width: 22, height: 22 }}
                            />
                          </Space>
                          
                          <Space size={8} wrap>
                            <Button 
                              size="small" 
                              type={state.showDs ? "primary" : "default"}
                              onClick={() => toggleServiceListState(sname, 'showDs')}
                              style={{ borderRadius: 6 }}
                            >
                              Data Source
                            </Button>
                            
                            <Tooltip title="Upstream Systems (Incoming)">
                              <Button 
                                size="small" 
                                icon={<span>⬆️</span>}
                                type={state.showUp ? "primary" : "default"}
                                onClick={() => toggleServiceListState(sname, 'showUp')}
                                style={{ borderRadius: 6 }}
                              />
                            </Tooltip>
                            
                            <Tooltip title="Downstream Systems (Outgoing)">
                              <Button 
                                size="small" 
                                icon={<span>⬇️</span>}
                                type={state.showDn ? "primary" : "default"}
                                onClick={() => toggleServiceListState(sname, 'showDn')}
                                style={{ borderRadius: 6 }}
                              />
                            </Tooltip>
                            
                            <Flex gap={8} style={{ marginLeft: 8 }} wrap>
                              {state.showDs && (
                                <Tag color="purple" style={{ padding: '2px 8px', fontSize: 11 }}>
                                  <strong>Data Sources:</strong> {dsources.length > 0 ? dsources.join(', ') : 'none'}
                                </Tag>
                              )}
                              {state.showUp && (
                                <Tag color="green" style={{ padding: '2px 8px', fontSize: 11 }}>
                                  <strong>Upstream:</strong> {upstreams.length > 0 ? upstreams.join(', ') : 'none'}
                                </Tag>
                              )}
                              {state.showDn && (
                                <Tag color="blue" style={{ padding: '2px 8px', fontSize: 11 }}>
                                  <strong>Downstream:</strong> {downstreams.length > 0 ? downstreams.join(', ') : 'none'}
                                </Tag>
                              )}
                            </Flex>
                          </Space>
                        </Flex>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </Card>
        </Col>

        {/* 3. Selected Service Sidebar Drawer / Drill-down details */}
        {selectedNode && (
          <Col span={8}>
            <Card 
              className="glass-card" 
              title={
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                  <Space>
                    <InfoCircleOutlined style={{ color: '#4b5dff' }} />
                    <span style={{ fontSize: 14 }}>Service Drill-down</span>
                  </Space>
                  <Button type="text" shape="circle" size="small" icon={<CloseOutlined />} onClick={() => setSelectedNode(null)} />
                </div>
              }
              style={{ height: '100%', overflowY: 'auto' }}
            >
              <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                <div>
                  <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block' }}>SERVICE NAME</Typography.Text>
                  <Typography.Title level={4} style={{ margin: 0, wordBreak: 'break-all' }}>{selectedNode}</Typography.Title>
                </div>

                {serviceDiagnosticsMap[selectedNode] && (
                  <div>
                    <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block', marginBottom: 4 }}>HEALTH STATE</Typography.Text>
                    {serviceDiagnosticsMap[selectedNode].isError ? (
                      <Alert 
                        type="error" 
                        showIcon 
                        message="Error state detected" 
                        description={
                          <ul style={{ paddingLeft: 14, margin: 0, fontSize: 11 }}>
                            {serviceDiagnosticsMap[selectedNode].messages.map((m, i) => <li key={i}>{m}</li>)}
                          </ul>
                        }
                      />
                    ) : serviceDiagnosticsMap[selectedNode].isWarning ? (
                      <Alert 
                        type="warning" 
                        showIcon 
                        message="Warnings detected" 
                        description={
                          <ul style={{ paddingLeft: 14, margin: 0, fontSize: 11 }}>
                            {serviceDiagnosticsMap[selectedNode].messages.map((m, i) => <li key={i}>{m}</li>)}
                          </ul>
                        }
                      />
                    ) : (
                      <Tag color="success"><CheckCircleOutlined /> Healthy Contract</Tag>
                    )}
                  </div>
                )}

                {selectedServiceDetails ? (
                  <Space direction="vertical" size="small" style={{ width: '100%' }}>
                    <div>
                      <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block' }}>TARGET NAMESPACE</Typography.Text>
                      <Typography.Text copyable style={{ fontSize: 12, fontFamily: 'monospace', wordBreak: 'break-all' }}>
                        {selectedServiceDetails.namespace}
                      </Typography.Text>
                    </div>

                    <div>
                      <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block' }}>ENDPOINT URL</Typography.Text>
                      <Typography.Text copyable style={{ fontSize: 12, fontFamily: 'monospace', wordBreak: 'break-all' }}>
                        <code>{selectedServiceDetails.endpoint_url || 'n/a'}</code>
                      </Typography.Text>
                    </div>

                    <div>
                      <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block' }}>SERVICE DOCUMENTATION</Typography.Text>
                      <Typography.Paragraph style={{ fontSize: 12, marginBottom: 0 }}>
                        {selectedServiceDetails.documentation || 'No documentation found.'}
                      </Typography.Paragraph>
                    </div>

                    <div>
                      <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block' }}>PORT TYPES & BINDINGS</Typography.Text>
                      <Space wrap style={{ marginTop: 4 }}>
                        {selectedServiceDetails.ports?.map((p: any) => (
                          <Tag key={p.port_name} color="cyan">{p.port_name}</Tag>
                        ))}
                        {selectedServiceDetails.bindings?.map((b: any) => (
                          <Tag key={b.binding_name} color="purple">{b.binding_name}</Tag>
                        ))}
                      </Space>
                    </div>

                    <div>
                      <Typography.Text type="secondary" style={{ fontSize: 11, display: 'block' }}>OPERATIONS DEFINED ({selectedServiceDetails.operations?.length || 0})</Typography.Text>
                      <div style={{ maxHeight: 150, overflowY: 'auto', border: '1px solid var(--stroke)', borderRadius: 8, padding: '4px 8px', marginTop: 4 }}>
                        {selectedServiceDetails.operations?.map((op: any) => (
                          <div key={op.operation_name} style={{ padding: '4px 0', borderBottom: '1px solid rgba(0,0,0,0.03)', fontSize: 12 }}>
                            <strong>{op.operation_name}</strong>
                          </div>
                        ))}
                        {(!selectedServiceDetails.operations || selectedServiceDetails.operations.length === 0) && (
                          <Typography.Text type="secondary" italic>No operations listed</Typography.Text>
                        )}
                      </div>
                    </div>
                  </Space>
                ) : (
                  <Alert message="Excel-only metadata record. No WSDL schema details available for this service." type="info" showIcon />
                )}
              </Space>
            </Card>
          </Col>
        )}
      </Row>

      {/* 4. Sleek Legend Panel */}
      <Card className="glass-card" size="small" title={<Typography.Text strong style={{ fontSize: 12 }}>Graph Legend Explanations</Typography.Text>}>
        <Row gutter={[16, 8]}>
          <Col span={8}>
            <Space direction="vertical" size={4}>
              <Typography.Text style={{ fontSize: 11 }}><strong style={{ display: 'inline-block', width: 60 }}>Nodes:</strong></Typography.Text>
              <Space><Tag color="success">✓ Green Node</Tag> <span style={{ fontSize: 11, color: 'var(--text-soft)' }}>Healthy Service / Valid Contract</span></Space>
              <Space><Tag color="warning">⚠ Yellow Node</Tag> <span style={{ fontSize: 11, color: 'var(--text-soft)' }}>Warnings / Empty element schemas</span></Space>
              <Space><Tag color="red">✗ Red Node</Tag> <span style={{ fontSize: 11, color: 'var(--text-soft)' }}>Errors / Malformed / Missing payloads</span></Space>
            </Space>
          </Col>
          <Col span={8}>
            <Space direction="vertical" size={4}>
              <Typography.Text style={{ fontSize: 11 }}><strong style={{ display: 'inline-block', width: 60 }}>Lines:</strong></Typography.Text>
              <Space><div style={{ width: 30, height: 2, background: '#4B5DFF' }}></div> <span style={{ fontSize: 11, color: 'var(--text-soft)' }}>Solid Line: Service call dependency</span></Space>
              <Space><div style={{ width: 30, height: 2, borderBottom: '2px dashed #7A41FF' }}></div> <span style={{ fontSize: 11, color: 'var(--text-soft)' }}>Dotted Line (Purple): Consumer callback flow</span></Space>
              <Space><div style={{ width: 30, height: 2, borderBottom: '2px dashed #F59E0B' }}></div> <span style={{ fontSize: 11, color: 'var(--text-soft)' }}>Dotted Line (Orange): Database/Data Source link</span></Space>
            </Space>
          </Col>
          <Col span={8}>
            <Space direction="vertical" size={4}>
              <Typography.Text style={{ fontSize: 11 }}><strong>Flow Direction:</strong></Typography.Text>
              <Typography.Text type="secondary" style={{ fontSize: 11 }}>
                Arrow heads indicate direction of the dependency request flow: Caller (Consumer) pointing to Callee (Provider).
              </Typography.Text>
            </Space>
          </Col>
        </Row>
      </Card>
      {/* 5. Focused Neighborhood Modal */}
      <Modal
        title={
          <Flex justify="space-between" align="center" style={{ width: '95%' }}>
            <Space>
              <BranchesOutlined style={{ color: '#4b5dff' }} />
              <span>Focused Neighborhood Sub-graph: <strong>{doubleClickedNode}</strong></span>
            </Space>
            <Space>
              <Button 
                size="small"
                icon={modalFullscreen ? <FullscreenExitOutlined /> : <FullscreenOutlined />}
                onClick={() => setModalFullscreen(!modalFullscreen)}
              >
                {modalFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
              </Button>
              <Button 
                size="small"
                icon={<DownloadOutlined />}
                onClick={exportAsSvg}
              >
                Export Image
              </Button>
            </Space>
          </Flex>
        }
        open={modalOpen}
        onCancel={() => {
          setModalOpen(false);
          setDoubleClickedNode(null);
        }}
        footer={null}
        width={modalFullscreen ? '98vw' : 1000}
        style={modalFullscreen ? { top: 10, maxWidth: '100%' } : { top: 40 }}
        bodyStyle={{ padding: 16 }}
      >
        <Space direction="vertical" size="middle" style={{ width: '100%' }}>
          {/* Controls Bar inside Modal */}
          <Card size="small" style={{ borderRadius: 12 }}>
            <Row gutter={[16, 16]} align="middle">
              <Col xs={24} sm={12} md={6}>
                <Space direction="vertical" size={2} style={{ width: '100%' }}>
                  <Typography.Text type="secondary" style={{ fontSize: 11 }}>DIRECTION FILTER</Typography.Text>
                  <Select
                    value={modalDirection}
                    onChange={setModalDirection}
                    style={{ width: '100%' }}
                    options={[
                      { label: 'Upstream connections', value: 'upstream' },
                      { label: 'Downstream connections', value: 'downstream' },
                      { label: 'Both directions', value: 'both' },
                      { label: 'Full neighborhood', value: 'full' }
                    ]}
                  />
                </Space>
              </Col>
              
              <Col xs={24} sm={12} md={6}>
                <Space direction="vertical" size={2} style={{ width: '100%' }}>
                  <Typography.Text type="secondary" style={{ fontSize: 11 }}>NODE TYPE FILTER</Typography.Text>
                  <Select
                    value={modalNodeType}
                    onChange={setModalNodeType}
                    style={{ width: '100%' }}
                    options={[
                      { label: 'All Node Types', value: 'all' },
                      { label: 'Services Only', value: 'services' },
                      { label: 'Data Sources Only', value: 'datasources' }
                    ]}
                  />
                </Space>
              </Col>

              <Col xs={24} sm={12} md={6}>
                <Space direction="vertical" size={2} style={{ width: '100%' }}>
                  <Typography.Text type="secondary" style={{ fontSize: 11 }}>BFS DEPTH SELECTOR (1 - 5)</Typography.Text>
                  <Slider
                    min={1}
                    max={5}
                    value={modalDepth}
                    onChange={(v) => setModalDepth(v)}
                    tooltip={{ formatter: (v) => `${v} hop(s)` }}
                  />
                </Space>
              </Col>

              <Col xs={24} sm={12} md={6}>
                <Space direction="vertical" size={2} style={{ width: '100%' }}>
                  <Typography.Text type="secondary" style={{ fontSize: 11 }}>SEARCH WITHIN SUB-GRAPH</Typography.Text>
                  <Input
                    placeholder="Search node ID..."
                    prefix={<SearchOutlined style={{ color: 'var(--text-soft)' }} />}
                    value={modalSearch}
                    onChange={(e) => setModalSearch(e.target.value)}
                    allowClear
                  />
                </Space>
              </Col>
            </Row>
          </Card>

          {/* Graph view for modal */}
          <div style={{ height: modalFullscreen ? 'calc(100vh - 220px)' : 500, border: '1px solid var(--stroke)', borderRadius: 12, overflow: 'hidden' }}>
            {modalGraphData.nodes.length === 0 ? (
              <Empty description="No neighborhood nodes matching active filters" style={{ marginTop: 100 }} />
            ) : (
              <ReactFlow
                nodes={modalGraphData.nodes}
                edges={modalGraphData.edges}
                fitView
              >
                <Background />
                <Controls />
              </ReactFlow>
            )}
          </div>
        </Space>
      </Modal>
    </Space>
  );
}
