import { Layout, Typography, Space } from "antd";
import { appContent } from "@/config/content";
import TcsLogo from "@/assets/tcs_logo.png";

const { Footer } = Layout;

export default function FooterBar(){
  return (
    <Footer style={{ textAlign: 'center', background: 'transparent', padding: '24px 0' }}>
      <Space direction="vertical" size={16} style={{ width: '100%' }}>
        <Typography.Text type="secondary">{appContent.footerSummary}</Typography.Text>
        <div>
          <img src={TcsLogo} alt="TCS Logo" style={{ height: 64, objectFit: 'contain' }} />
        </div>
      </Space>
    </Footer>
  );
}
