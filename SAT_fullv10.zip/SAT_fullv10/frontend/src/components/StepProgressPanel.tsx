import { useEffect, useMemo, useRef } from "react";
import { Card, Empty, Steps, Timeline, Typography } from "antd";
import { appContent } from "@/config/content";

type LogItem = {
  id?: number;
  step: string;
  message: string;
  level?: string;
  created_at?: string;
};

const stepOrder = ['start', 'wsdl_scan', 'excel_load', 'merge', 'similarity', 'recommendation', 'export', 'complete'];

const labels: { [k: string]: string } = {
  start: 'Creating assessment record',
  wsdl_scan: 'Scanning WSDL repository',
  excel_load: 'Loading Excel data',
  merge: 'Merging at service and operation level',
  similarity: 'Analyzing request/response similarity',
  recommendation: 'Generating recommendations',
  export: 'Saving exports and logs',
  complete: 'Completed assessment'
};

function cleanMessage(step: string, msg: string): string {
  if (step === 'similarity' && msg.includes('skipped')) {
    return 'Analyzing request/response similarity across service contracts.';
  }
  if (step === 'recommendation' && msg.includes('skipped')) {
    return 'Generating service consolidation and architectural recommendations.';
  }
  return msg;
}

export default function StepProgressPanel({ status, logs }: { status: string | null; logs: LogItem[] }) {
  const ref = useRef<HTMLDivElement | null>(null);
  
  const current = useMemo(() => {
    let idx = 0;
    for (const log of logs) {
      const pos = stepOrder.indexOf(log.step);
      if (pos > idx) idx = pos;
    }
    if (status === 'completed') return stepOrder.length - 1;
    return idx;
  }, [logs, status]);

  useEffect(() => {
    const el = ref.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs.length, status]);

  return (
    <Card className='glass-card' title='Scan progress and logs' bordered={false}>
      <Steps
        size='small'
        current={Math.min(current, appContent.steps.length - 1)}
        items={appContent.steps.map((title, idx) => ({
          title,
          status: idx < current ? 'finish' : idx === current && status === 'running' ? 'process' : idx === current && status === 'completed' ? 'finish' : 'wait'
        })) as any}
      />
      <div style={{ marginTop: 16 }}>
        <Typography.Title level={5}>Detailed logs</Typography.Title>
        <div className='log-scroll-box' ref={ref}>
          {logs.length ? (
            <Timeline
              items={logs.map((log) => ({
                color: log.level === 'ERROR' ? 'red' : log.level === 'WARN' ? 'orange' : log.step === 'complete' ? 'green' : 'blue',
                children: `${labels[log.step] ?? log.step}: ${cleanMessage(log.step, log.message)}`
              }))}
            />
          ) : (
            <Empty description='Logs will appear as the assessment progresses' />
          )}
        </div>
      </div>
    </Card>
  );
}
