import { Card, Tag } from "antd";

type EdgeRow = {
  source: string;
  target: string;
  type?: string;
};

export default function MatrixView({ title, rows }: { title: string; rows: EdgeRow[] }) {
  const labels = Array.from(new Set(rows.flatMap((r) => [r.source, r.target]).filter(Boolean))).sort();
  const matrix = labels.map((r) => labels.map((c) => rows.some((x) => x.source === r && x.target === c) ? 1 : 0));

  return (
    <Card className='glass-card matrix-table' title={title} bordered={false}>
      <div style={{ overflowX: 'auto' }}>
        <table>
          <thead>
            <tr>
              <th style={{ background: 'rgba(0,0,0,0.02)', fontWeight: 'bold' }}></th>
              {labels.map((l) => (
                <th key={l} style={{ background: 'rgba(0,0,0,0.02)', fontWeight: 'bold', fontSize: 11 }}>{l}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {labels.map((label, i) => (
              <tr key={label}>
                <th style={{ textAlign: 'left', background: 'rgba(0,0,0,0.01)', fontSize: 11 }}>{label}</th>
                {matrix[i].map((v, j) => (
                  <td key={`${i}-${j}`} style={{ background: v ? 'rgba(75,93,255,.05)' : 'transparent', padding: '6px 12px' }}>
                    {v === 1 ? <Tag color="blue" style={{ margin: 0, fontWeight: 'bold' }}>1</Tag> : ""}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

