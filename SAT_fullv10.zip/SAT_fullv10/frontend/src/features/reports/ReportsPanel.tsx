import { useEffect, useMemo, useState } from 'react'
import { keepPreviousData, useMutation, useQuery } from '@tanstack/react-query'
import {
  Alert,
  Button,
  Card,
  Collapse,
  Empty,
  Flex,
  Input,
  Modal,
  Segmented,
  Space,
  Statistic,
  Table,
  Tag,
  Typography,
  message,
  Row,
  Col,
  Progress,
  Timeline,
  Pagination,
} from 'antd'
import {
  DatabaseOutlined,
  CodeOutlined,
  BranchesOutlined,
  InfoCircleOutlined,
  CheckCircleOutlined,
  ExclamationCircleOutlined,
  WarningOutlined,
  MergeCellsOutlined
} from '@ant-design/icons'
import type { ColumnsType } from 'antd/es/table'
import MatrixView from '@/components/MatrixView'
import ColorfulFlowGraph from '@/components/ColorfulFlowGraph'
import AssessmentChangeCard from '@/components/AssessmentChangeCard'
import JsonViewer from '@/components/JsonViewer'
import {
  fetchDataSourceDependency,
  fetchDbTableData,
  fetchDbTables,
  fetchExports,
  fetchGroupedWSDLExtracts,
  fetchRawExtracts,
  fetchServiceDependency,
  fetchServiceSummary,
  fetchStructureDetail,
  fetchStructureSummary,
  runDbTableQuery,
  fetchDbSchema,
  runDbQuery,
} from './api'
import { fetchAssessmentLogs } from '@/features/analysis/api'
import { fetchAssessments } from '@/features/history/api'
import { useAssessmentStore } from '@/store/useAssessmentStore'

type DbTableRow = Record<string, unknown>

type SqlQueryResponse = {
  rows: DbTableRow[]
  columns: string[]
  total: number
}

type SchemaMode = 'Overview' | 'Schema Explorer' | 'SQL Runner' | 'Table Viewer'

type JsonModalState = {
  open: boolean
  title: string
  data: unknown
}

function safeArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : []
}

function stringifyCell(value: unknown): string {
  if (value === null || value === undefined) return 'n/a'
  if (typeof value === 'object') {
    try {
      return JSON.stringify(value)
    } catch {
      return '[object]'
    }
  }
  return String(value)
}

function looksLikeJsonString(value: unknown) {
  if (typeof value !== 'string') return false
  const trimmed = value.trim()
  return (
    (trimmed.startsWith('{') && trimmed.endsWith('}')) ||
    (trimmed.startsWith('[') && trimmed.endsWith(']'))
  )
}

function parseMaybeJson(value: unknown): unknown {
  if (value === null || value === undefined) return null
  if (typeof value === 'object') return value
  if (typeof value === 'string' && looksLikeJsonString(value)) {
    try {
      return JSON.parse(value)
    } catch {
      return value
    }
  }
  return value
}

function isJsonRenderable(value: unknown) {
  const parsed = parseMaybeJson(value)
  return typeof parsed === 'object' && parsed !== null
}

function collectObjectKeys(rows: Record<string, unknown>[]) {
  const set = new Set<string>()
  rows.forEach((row) => {
    Object.keys(row || {}).forEach((k) => set.add(k))
  })
  return Array.from(set)
}

function buildJsonTableModel(
  value: unknown,
  openJsonModal: (title: string, data: unknown) => void,
) {
  const parsed = parseMaybeJson(value)

  if (Array.isArray(parsed)) {
    if (parsed.length === 0) {
      return {
        columns: [
          {
            title: 'value',
            dataIndex: 'value',
            key: 'value',
          },
        ] as ColumnsType<any>,
        rows: [] as any[],
      }
    }

    const everyObject = parsed.every(
      (item) => item && typeof item === 'object' && !Array.isArray(item),
    )

    if (everyObject) {
      const objectRows = parsed as Record<string, unknown>[]
      const keys = collectObjectKeys(objectRows)

      const columns: ColumnsType<any> = keys.map((key) => ({
        title: key,
        dataIndex: key,
        key,
        render: (cellValue: unknown, record: any, index?: number) =>
          renderJsonAwareValue(
            cellValue,
            `${key}${index !== undefined ? ` [${index}]` : ''}`,
            openJsonModal,
          ),
      }))

      const rows = objectRows.map((item, index) => ({
        __rowKey: index,
        ...item,
      }))

      return { columns, rows }
    }

    const rows = parsed.map((item, index) => ({
      __rowKey: index,
      index,
      value: item,
    }))

    const columns: ColumnsType<any> = [
      { title: 'index', dataIndex: 'index', key: 'index', width: 90 },
      {
        title: 'value',
        dataIndex: 'value',
        key: 'value',
        render: (cellValue: unknown, record: any, index?: number) =>
          renderJsonAwareValue(
            cellValue,
            `value${index !== undefined ? ` [${index}]` : ''}`,
            openJsonModal,
          ),
      },
    ]

    return { columns, rows }
  }

  if (parsed && typeof parsed === 'object') {
    const entries = Object.entries(parsed as Record<string, unknown>).map(
      ([field, fieldValue], index) => ({
        __rowKey: index,
        field,
        value: fieldValue,
      }),
    )

    const columns: ColumnsType<any> = [
      {
        title: 'field',
        dataIndex: 'field',
        key: 'field',
        width: 220,
      },
      {
        title: 'value',
        dataIndex: 'value',
        key: 'value',
        render: (cellValue: unknown, record: any) =>
          renderJsonAwareValue(cellValue, record?.field || 'value', openJsonModal),
      },
    ]

    return { columns, rows: entries }
  }

  return {
    columns: [
      {
        title: 'value',
        dataIndex: 'value',
        key: 'value',
      },
    ] as ColumnsType<any>,
    rows: [{ __rowKey: 'primitive', value: parsed }],
  }
}

function renderJsonAwareValue(
  value: unknown,
  title: string,
  openJsonModal: (title: string, data: unknown) => void,
) {
  const parsed = parseMaybeJson(value)

  if (parsed === null || parsed === undefined) {
    return <Typography.Text type="secondary">n/a</Typography.Text>
  }

  if (typeof parsed === 'object') {
    const label = Array.isArray(parsed)
      ? `View JSON Array (${parsed.length})`
      : 'View JSON Object'

    return (
      <Space direction="vertical" size={4}>
        <Button type="link" size="small" onClick={() => openJsonModal(title, parsed)}>
          {label}
        </Button>
        <Typography.Text
          type="secondary"
          style={{
            display: 'inline-block',
            maxWidth: 280,
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
            fontFamily: 'monospace',
            fontSize: 12,
          }}
        >
          {JSON.stringify(parsed).slice(0, 120)}
          {JSON.stringify(parsed).length > 120 ? '...' : ''}
        </Typography.Text>
      </Space>
    )
  }

  const text = String(parsed)
  return (
    <Typography.Text
      style={{
        display: 'inline-block',
        maxWidth: 280,
        whiteSpace: 'pre-wrap',
        wordBreak: 'break-word',
      }}
    >
      {text}
    </Typography.Text>
  )
}

function buildDynamicColumns(
  columns: string[],
  openJsonModal: (title: string, data: unknown) => void,
): ColumnsType<any> {
  return columns.map((col) => ({
    title: col,
    dataIndex: col,
    key: col,
    render: (value: unknown, record: any, index?: number) =>
      renderJsonAwareValue(
        value,
        `${col}${record?.id ? ` - ${record.id}` : index !== undefined ? ` - ${index}` : ''}`,
        openJsonModal,
      ),
  }))
}

// Collapsible Payload Tree Component
interface TreeNodeProps {
  field: any;
  depth?: number;
}

function FieldTreeNode({ field, depth = 0 }: TreeNodeProps) {
  const [collapsed, setCollapsed] = useState(true);
  const hasChildren = Array.isArray(field.children) && field.children.length > 0;
  
  return (
    <div style={{ marginLeft: depth * 14, marginTop: 4, fontFamily: 'monospace' }}>
      <Space size={4} align="baseline" wrap>
        {hasChildren ? (
          <Button 
            type="link" 
            size="small" 
            style={{ padding: 0, height: 'auto', lineHeight: 1, fontSize: '11px' }}
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? '[+]' : '[-]'}
          </Button>
        ) : (
          <span style={{ display: 'inline-block', width: 14, textAlign: 'center', fontSize: '11px', color: 'var(--text-soft)' }}>•</span>
        )}
        <span style={{ color: 'var(--page-text)', fontWeight: 600 }}>{field.name}</span>
        <span style={{ color: 'var(--text-soft)', fontSize: '12px' }}>: {field.type || 'any'}</span>
        {field.min_occurs !== undefined && (
          <Tag style={{ fontSize: '10px', height: '18px', lineHeight: '16px' }}>
            [{field.min_occurs}..{field.max_occurs ?? '*'}]
          </Tag>
        )}
        {field.documentation && (
          <span style={{ color: '#d97706', fontSize: '11px', fontStyle: 'italic' }}>
            — {field.documentation}
          </span>
        )}
      </Space>
      {hasChildren && !collapsed && (
        <div style={{ borderLeft: '1px dashed rgba(88, 104, 184, 0.2)', marginLeft: 6, paddingLeft: 8 }}>
          {field.children.map((child: any, idx: number) => (
            <FieldTreeNode key={idx} field={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export function CollapsibleFieldTree({ fields }: { fields: any[] }) {
  if (!Array.isArray(fields) || fields.length === 0) {
    return <Typography.Text type="secondary" italic>No payload structure defined</Typography.Text>;
  }
  return (
    <div style={{ 
      padding: '12px', 
      background: 'rgba(0,0,0,0.02)', 
      border: '1px solid rgba(88, 104, 184, 0.1)', 
      borderRadius: '12px', 
      overflowX: 'auto',
      maxHeight: '400px',
      overflowY: 'auto'
    }}>
      <div style={{ marginBottom: 8, paddingBottom: 8, borderBottom: '1px dashed rgba(88, 104, 184, 0.15)', fontSize: '11px', color: 'var(--text-soft)' }}>
        <strong>Legend:</strong> <code>[min..max]</code> indicates occurrence constraints where <code>*</code> represents unbounded (unlimited) occurrences.
      </div>
      {fields.map((f: any, idx: number) => (
        <FieldTreeNode key={idx} field={f} />
      ))}
    </div>
  );
}

export default function ReportsPanel() {
  const activeSection = useAssessmentStore((s) => s.activeSection)
  const [depView, setDepView] = useState<'Table' | 'Matrix' | 'Flow'>('Table')
  const [depCategory, setDepCategory] = useState<'service' | 'datasource' | 'combined'>('combined')
  
  useEffect(() => {
    if (activeSection === 'dependencies') {
      setDepCategory('combined')
    }
  }, [activeSection])
  const [globalSearch, setGlobalSearch] = useState('')
  const [dbTableSearch, setDbTableSearch] = useState('')
  const [selectedGroup, setSelectedGroup] = useState<{
    service_name?: string | null
    operation_name?: string | null
  }>({})

  const [schemaMode, setSchemaMode] = useState<SchemaMode>('Overview')
  const [selectedTable, setSelectedTable] = useState<string>('')

  const [tablePage, setTablePage] = useState(1)
  const [tablePageSize, setTablePageSize] = useState(50)
  const [wsdlPage, setWsdlPage] = useState(1)
  const [selectedDepNode, setSelectedDepNode] = useState<string | null>(null)
  const [unifiedDepFilter, setUnifiedDepFilter] = useState<'all' | 'service' | 'datasource'>('all')

  // SQL Runner state
  const [queryText, setQueryText] = useState('')
  const [queryParamsText, setQueryParamsText] = useState('{}')
  const [queryPage, setQueryPage] = useState(1)
  const [queryPageSize, setQueryPageSize] = useState(50)
  const [queryResult, setQueryResult] = useState<SqlQueryResponse | null>(null)
  const [lastSubmittedQuery, setLastSubmittedQuery] = useState<{
    query: string
    params: Record<string, any>
  } | null>(null)

  const [jsonModal, setJsonModal] = useState<JsonModalState>({
    open: false,
    title: '',
    data: null,
  })

  const assessmentId = useAssessmentStore((s) => s.assessmentId)
  const assessmentCode = useAssessmentStore((s) => s.assessmentCode)
  const status = useAssessmentStore((s) => s.status)
  const enabled = !!assessmentId && status === 'completed'

  const openJsonModal = (title: string, data: unknown) => {
    setJsonModal({
      open: true,
      title,
      data: parseMaybeJson(data),
    })
  }

  const closeJsonModal = () => {
    setJsonModal({
      open: false,
      title: '',
      data: null,
    })
  }

  // standard report queries
  const summaryQ = useQuery({
    queryKey: ['service-summary', assessmentId],
    queryFn: () => fetchServiceSummary(assessmentId),
    enabled,
  })

  const depQ = useQuery({
    queryKey: ['service-dep', assessmentId],
    queryFn: () => fetchServiceDependency(assessmentId),
    enabled,
  })

  const dsQ = useQuery({
    queryKey: ['ds-dep', assessmentId],
    queryFn: () => fetchDataSourceDependency(assessmentId),
    enabled,
  })

  const expQ = useQuery({
    queryKey: ['exports', assessmentId],
    queryFn: () => fetchExports(assessmentId as number),
    enabled,
  })

  const rawQ = useQuery({
    queryKey: ['raw-extracts', assessmentId],
    queryFn: () => fetchRawExtracts(assessmentId as number),
    enabled,
  })

  const groupedQ = useQuery({
    queryKey: ['grouped-wsdl', assessmentId],
    queryFn: () => fetchGroupedWSDLExtracts(assessmentId as number),
    enabled,
  })

  const structSumQ = useQuery({
    queryKey: ['structure-summary', assessmentId],
    queryFn: () => fetchStructureSummary(assessmentId as number),
    enabled,
  })

  const structDetailQ = useQuery({
    queryKey: ['structure-detail', assessmentId, selectedGroup.service_name, selectedGroup.operation_name],
    queryFn: () =>
      fetchStructureDetail(
        assessmentId as number,
        selectedGroup.service_name ?? null,
        selectedGroup.operation_name ?? null,
      ),
    enabled,
  })

  const historyQ = useQuery({
    queryKey: ['assessment-history-inline'],
    queryFn: fetchAssessments,
    enabled,
  })

  const dbTablesQ = useQuery({
    queryKey: ['db-tables'],
    queryFn: fetchDbTables,
    enabled: activeSection === 'storage' && enabled,
    staleTime: 60_000,
  })

  const dbSchemaQ = useQuery({
    queryKey: ['db-schema'],
    queryFn: fetchDbSchema,
    enabled: activeSection === 'storage' && enabled,
    staleTime: 60_000,
  })

  const tableDataQ = useQuery<any>({
    queryKey: ['db-table-data', selectedTable, tablePage, tablePageSize],
    queryFn: () =>
      fetchDbTableData(selectedTable, {
        page: tablePage,
        page_size: tablePageSize,
      }),
    enabled:
      activeSection === 'storage' &&
      enabled &&
      schemaMode === 'Table Viewer' &&
      !!selectedTable,
    placeholderData: keepPreviousData,
  })

  // SQL Runner Mutation using generic /db/query runner
  const rawQueryMutation = useMutation({
    mutationFn: (body: {
      query: string
      params?: Record<string, any>
      page: number
      page_size: number
    }) => runDbQuery(body),
    onSuccess: (data) => {
      setQueryResult(data)
    },
    onError: (error: any) => {
      const detail = error?.response?.data?.detail || error?.message || 'Failed to run query'
      message.error(detail)
    },
  })

  // Logs query
  const logsQ = useQuery({
    queryKey: ['assessment-logs-view', assessmentId],
    queryFn: () => fetchAssessmentLogs(assessmentId as number),
    enabled: (activeSection === 'logs' || activeSection === 'summary') && !!assessmentId,
  })

  const summaryItems = safeArray<any>(summaryQ.data?.items)
  const depItems = safeArray<any>(depQ.data?.items)
  const dsItems = safeArray<any>(dsQ.data?.items)
  const combinedDeps = useMemo(() => [...depItems, ...dsItems], [depItems, dsItems])
  const activeDeps = useMemo(() => {
    if (depCategory === 'service') return depItems
    if (depCategory === 'datasource') return dsItems
    return combinedDeps
  }, [depCategory, depItems, dsItems, combinedDeps])
  const exportItems = safeArray<any>(expQ.data?.items)
  const sortedExportItems = useMemo(() => {
    const filtered = exportItems.filter((item: any) => {
      const kind = (item.artifact_kind || '').toLowerCase();
      return !kind.includes('merged_output');
    });
    const getOrderScore = (item: any) => {
      const kind = (item.artifact_kind || '').toLowerCase().replace(/_/g, ' ');
      const type = (item.file_type || '').toLowerCase();
      if (kind.includes('sat assessment report')) {
        if (type === 'xlsx') return 1;
        if (type === 'pdf') return 2;
        if (type === 'csv') return 3;
        return 4;
      }
      if (kind.includes('extracted wsdl data') || kind.includes('wsdl')) {
        if (type === 'xlsx') return 5.1;
        if (type === 'pdf') return 5.2;
        if (type === 'csv') return 5.3;
        return 5;
      }
      if (kind.includes('excel data') || kind.includes('excel')) {
        if (type === 'xlsx') return 6.1;
        if (type === 'pdf') return 6.2;
        if (type === 'csv') return 6.3;
        return 6;
      }
      return 10;
    };
    return [...filtered].sort((a, b) => getOrderScore(a) - getOrderScore(b));
  }, [exportItems]);
  const groupedItems = safeArray<any>(groupedQ.data?.items)
  const excelItems = safeArray<any>(rawQ.data?.excel_items)
  const mergedItems = safeArray<any>(rawQ.data?.merged_items)
  const assessments = safeArray<any>(historyQ.data?.items)
  const logItems = safeArray<any>(logsQ.data?.items)

  const analytics = useMemo(() => {
    if (!mergedItems || mergedItems.length === 0) return null;

    let exact = 0;
    let partial = 0;
    let unmatched = 0;

    const dataSources = new Set<string>();
    const upstreamApps = new Set<string>();
    const downstreamApps = new Set<string>();
    
    const serviceOperationsMap: Record<string, Set<string>> = {};
    const serviceHasDepsMap: Record<string, boolean> = {};

    const dataSourcesCounts: Record<string, number> = {};
    const upstreamCounts: Record<string, number> = {};
    const downstreamCounts: Record<string, number> = {};

    mergedItems.forEach((item) => {
      const conf = item.matching_confidence;
      if (conf === 1.0) exact++;
      else if (conf === 0.5) partial++;
      else unmatched++;

      const sname = item.service_name;
      const opname = item.operation_name;

      if (sname) {
        if (!serviceOperationsMap[sname]) {
          serviceOperationsMap[sname] = new Set<string>();
        }
        if (opname) {
          serviceOperationsMap[sname].add(opname);
        }
      }

      // Count data sources
      const ds = item.data_sources_json || [];
      ds.forEach((d: string) => {
        if (d.trim()) {
          dataSources.add(d.trim());
          dataSourcesCounts[d.trim()] = (dataSourcesCounts[d.trim()] || 0) + 1;
          if (sname) serviceHasDepsMap[sname] = true;
        }
      });

      // Count upstream apps
      const ups = item.upstream_apps_json || [];
      ups.forEach((u: string) => {
        if (u.trim()) {
          upstreamApps.add(u.trim());
          upstreamCounts[u.trim()] = (upstreamCounts[u.trim()] || 0) + 1;
          if (sname) serviceHasDepsMap[sname] = true;
        }
      });

      // Count downstream apps
      const dns = item.downstream_apps_json || [];
      dns.forEach((d: string) => {
        if (d.trim()) {
          downstreamApps.add(d.trim());
          downstreamCounts[d.trim()] = (downstreamCounts[d.trim()] || 0) + 1;
          if (sname) serviceHasDepsMap[sname] = true;
        }
      });
    });

    const totalServices = Object.keys(serviceOperationsMap).length;
    let totalOperations = 0;
    Object.values(serviceOperationsMap).forEach(ops => {
      totalOperations += ops.size;
    });
    if (totalOperations === 0 && mergedItems.length > 0) {
      totalOperations = mergedItems.length;
    }

    const avgOperationsPerService = totalServices > 0 
      ? (totalOperations / totalServices).toFixed(1) 
      : "0.0";

    const servicesWithDeps = Object.keys(serviceOperationsMap).filter(s => serviceHasDepsMap[s]).length;
    const servicesWithoutDeps = totalServices - servicesWithDeps;

    const topDataSources = Object.entries(dataSourcesCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    const matchRate = mergedItems.length > 0 ? Math.round(((exact + partial) / mergedItems.length) * 100) : 0;

    return {
      total: mergedItems.length,
      exact,
      partial,
      unmatched,
      topDataSources,
      matchRate,
      totalServices,
      totalOperations,
      uniqueUpstreamCount: upstreamApps.size,
      uniqueDownstreamCount: downstreamApps.size,
      avgOperationsPerService,
      servicesWithDeps,
      servicesWithoutDeps
    };
  }, [mergedItems]);

  const dbTables = safeArray<string>(dbTablesQ.data?.tables)
  const schemaTree = dbSchemaQ.data?.tables || {}

  const structureSummary = structSumQ.data
  const structureDetail = structDetailQ.data

  useEffect(() => {
    if (!selectedTable && dbTables.length > 0) {
      const first = dbTables[0]
      setSelectedTable(first)
      setQueryText(`SELECT * FROM ${first}`)
    }
  }, [dbTables, selectedTable])

  useEffect(() => {
    if (selectedTable) {
      setTablePage(1)
      setQueryPage(1)
      setQueryResult(null)
      setLastSubmittedQuery(null)
      setQueryText((prev) => {
        if (!prev.trim()) return `SELECT * FROM ${selectedTable}`
        return prev
      })
    }
  }, [selectedTable])

  const previousAssessment = useMemo(() => {
    const idx = assessments.findIndex((x: any) => x.assessment_id === assessmentId)
    return idx >= 0 ? assessments[idx + 1] : null
  }, [assessments, assessmentId])

  const previousRawQ = useQuery({
    queryKey: ['raw-extracts-prev', previousAssessment?.assessment_id],
    queryFn: () => fetchRawExtracts(previousAssessment!.assessment_id),
    enabled: !!previousAssessment?.assessment_id && enabled,
  })

  const previousGroupedQ = useQuery({
    queryKey: ['grouped-wsdl-prev', previousAssessment?.assessment_id],
    queryFn: () => fetchGroupedWSDLExtracts(previousAssessment!.assessment_id),
    enabled: !!previousAssessment?.assessment_id && enabled,
  })

  const prev = previousRawQ.data || {}
  const previousGroupedItems = safeArray<any>(previousGroupedQ.data?.items)
  const previousExcel = safeArray<any>(prev.excel_items)
  const previousMerged = safeArray<any>(prev.merged_items)

  const diffs = useMemo(() => {
    if (!previousAssessment) {
      return [
        { label: 'WSDL extract rows', current: groupedItems.length, previous: 0, delta: 0 },
        { label: 'Excel extract rows', current: excelItems.length, previous: 0, delta: 0 },
        { label: 'Merged rows', current: mergedItems.length, previous: 0, delta: 0 },
        {
          label: 'Service count',
          current: new Set(summaryItems.map((x: any) => x.service_name)).size,
          previous: 0,
          delta: 0,
        },
      ]
    }

    return [
      {
        label: 'WSDL extract rows',
        current: groupedItems.length,
        previous: previousGroupedItems.length,
        delta: groupedItems.length - previousGroupedItems.length,
      },
      {
        label: 'Excel extract rows',
        current: excelItems.length,
        previous: previousExcel.length,
        delta: excelItems.length - previousExcel.length,
      },
      {
        label: 'Merged rows',
        current: mergedItems.length,
        previous: previousMerged.length,
        delta: mergedItems.length - previousMerged.length,
      },
      {
        label: 'Service count',
        current: new Set(summaryItems.map((x: any) => x.service_name)).size,
        previous: new Set(previousMerged.map((x: any) => x.service_name)).size,
        delta:
          new Set(summaryItems.map((x: any) => x.service_name)).size -
          new Set(previousMerged.map((x: any) => x.service_name)).size,
      },
    ]
  }, [
    previousAssessment,
    groupedItems,
    previousGroupedItems,
    excelItems,
    previousExcel,
    mergedItems,
    previousMerged,
    summaryItems,
  ])

  const filterAny = (rows: any[]) =>
    rows.filter((r: any) =>
      JSON.stringify(r ?? {})
        .toLowerCase()
        .includes(globalSearch.toLowerCase()),
    )

  const filteredSummary = useMemo(() => filterAny(summaryItems), [summaryItems, globalSearch])
  const filteredGrouped = useMemo(() => filterAny(groupedItems), [groupedItems, globalSearch])
  const filteredExcel = useMemo(() => filterAny(excelItems), [excelItems, globalSearch])
  const filteredMerged = useMemo(() => filterAny(mergedItems), [mergedItems, globalSearch])
  const filteredDep = useMemo(() => filterAny(depItems), [depItems, globalSearch])
  const filteredDs = useMemo(() => filterAny(dsItems), [dsItems, globalSearch])

  const serviceGroupedPanels = useMemo(() => {
    const serviceOpsMap: Record<string, any[]> = {};
    filteredGrouped.forEach(op => {
      const sname = op.service_name;
      if (!serviceOpsMap[sname]) serviceOpsMap[sname] = [];
      serviceOpsMap[sname].push(op);
    });

    const list = summaryItems.filter(s => !!serviceOpsMap[s.service_name]);
    return list.map(s => ({
      service: s,
      operations: serviceOpsMap[s.service_name]
    }));
  }, [summaryItems, filteredGrouped]);

  const wsdlPageSize = 5;
  const paginatedServicePanels = useMemo(() => {
    const start = (wsdlPage - 1) * wsdlPageSize;
    return serviceGroupedPanels.slice(start, start + wsdlPageSize);
  }, [serviceGroupedPanels, wsdlPage]);

  const allDataSourceNames = useMemo(() => {
    const dsSet = new Set<string>()
    dsItems.forEach(r => {
      if (r.source) dsSet.add(r.source)
    })
    return dsSet
  }, [dsItems])

  const uniqueComponentDependencies = useMemo(() => {
    const list: any[] = []
    
    // 1. Get all unique services
    summaryItems.forEach((svc, idx) => {
      const sname = svc.service_name
      
      const upstream = new Set<string>()
      const downstream = new Set<string>()
      const databases = new Set<string>()

      depItems.forEach(d => {
        if (d.target === sname) upstream.add(d.source)
        if (d.source === sname) downstream.add(d.target)
      })

      dsItems.forEach(d => {
        if (d.target === sname) databases.add(d.source)
      })

      const totalDeps = downstream.size + databases.size

      const svcGrouped = groupedItems.filter((g: any) => g.service_name === sname)
      const operationsList = svcGrouped.map((op: any, oIdx: number) => {
        const opMerged = mergedItems.find((m: any) => m.service_name === sname && m.operation_name === op.operation_name)
        return {
          key: `op-${sname}-${op.operation_name}-${oIdx}`,
          name: op.operation_name,
          upstream: opMerged?.upstream_apps_json?.join(', ') || 'none',
          downstream: opMerged?.downstream_apps_json?.join(', ') || 'none',
          databases: opMerged?.data_sources_json?.join(', ') || 'none',
        }
      })

      list.push({
        key: `comp-service-${sname}-${idx}`,
        calling_service: sname,
        dependent_service: `${totalDeps}`,
        service_to_service_count: `${downstream.size}`,
        data_source_count: `${databases.size}`,
        component_type: 'Service',
        relationship: 'Service Portfolio Component',
        operations_count: safeArray(svc.operations).length,
        raw_ops: operationsList
      })
    })

    // 2. Get all unique data sources
    Array.from(allDataSourceNames).forEach((ds, idx) => {
      const downstream = new Set<string>()
      dsItems.forEach(d => {
        if (d.source === ds) downstream.add(d.target)
      })

      list.push({
        key: `comp-ds-${ds}-${idx}`,
        calling_service: ds,
        dependent_service: `${downstream.size}`,
        service_to_service_count: `${downstream.size}`,
        data_source_count: '0',
        component_type: 'Data Source',
        relationship: 'Data Source Component',
        operations_count: 0,
        raw_ops: []
      })
    })

    return list
  }, [summaryItems, depItems, dsItems, groupedItems, mergedItems, allDataSourceNames])

  const filteredComponentDependencies = useMemo(() => {
    return uniqueComponentDependencies.filter(item => {
      if (depCategory === 'service' && item.component_type !== 'Service') return false
      if (depCategory === 'datasource' && item.component_type !== 'Data Source') return false
      if (globalSearch.trim()) {
        const query = globalSearch.toLowerCase()
        return item.calling_service.toLowerCase().includes(query) ||
               item.dependent_service.toLowerCase().includes(query) ||
               item.component_type.toLowerCase().includes(query)
      }
      return true
    })
  }, [uniqueComponentDependencies, depCategory, globalSearch])

  const filteredDbTables = useMemo(() => {
    if (!dbTableSearch.trim()) return dbTables
    return dbTables.filter((t) => t.toLowerCase().includes(dbTableSearch.toLowerCase()))
  }, [dbTables, dbTableSearch])

  const tableViewerColumns = useMemo(
    () => buildDynamicColumns((tableDataQ.data?.columns ?? []).filter((c: string) => c.toLowerCase() !== 'id'), openJsonModal),
    [tableDataQ.data?.columns],
  )

  const queryResultColumns = useMemo(
    () => buildDynamicColumns((queryResult?.columns ?? []).filter((c: string) => c.toLowerCase() !== 'id'), openJsonModal),
    [queryResult?.columns],
  )

  const jsonModalTableModel = useMemo(
    () => buildJsonTableModel(jsonModal.data, openJsonModal),
    [jsonModal.data],
  )

  const handleRunSql = async (nextPage = 1, nextPageSize = queryPageSize) => {
    let params: Record<string, any> = {}
    try {
      const raw = queryParamsText.trim()
      params = raw ? JSON.parse(raw) : {}
      if (params === null || typeof params !== 'object' || Array.isArray(params)) {
        message.error('Params must be a JSON object')
        return
      }
    } catch {
      message.error('Params must be valid JSON')
      return
    }

    const finalQuery = queryText.trim() || (selectedTable ? `SELECT * FROM ${selectedTable}` : 'SELECT * FROM assessments')

    setQueryPage(nextPage)
    setQueryPageSize(nextPageSize)
    setLastSubmittedQuery({ query: finalQuery, params })

    await rawQueryMutation.mutateAsync({
      query: finalQuery,
      params,
      page: nextPage,
      page_size: nextPageSize,
    })
  }

  const rerunLastQuery = async (nextPage: number, nextPageSize: number) => {
    if (!lastSubmittedQuery) return
    setQueryPage(nextPage)
    setQueryPageSize(nextPageSize)

    await rawQueryMutation.mutateAsync({
      query: lastSubmittedQuery.query,
      params: lastSubmittedQuery.params,
      page: nextPage,
      page_size: nextPageSize,
    })
  }

  if (!assessmentId) {
    return <Empty description="Open an assessment from the Records section to view details." />
  }

  if (status !== 'completed') {
    return (
      <Card className="glass-card" bordered={false}>
        <Empty description={`Assessment is currently in state: ${status ?? 'n/a'}. Reports will load when completed.`} />
      </Card>
    )
  }

  return (
    <>
      <Flex vertical gap={16}>
        


        {/* SECTION 4: WSDL Extracts */}
        {activeSection === 'wsdl' && (
          <Card className="glass-card" title="Grouped WSDL Extracts" bordered={false}>
            <Typography.Paragraph type="secondary">
              Contracts grouped by Service & Operation. Expand a service panel to browse its metadata summary, and expand individual operations to inspect schema definitions.
            </Typography.Paragraph>
            <div style={{ marginBottom: 16 }}>
              <Input.Search
                placeholder="Filter extracts"
                allowClear
                value={globalSearch}
                onChange={(e) => setGlobalSearch(e.target.value)}
                style={{ maxWidth: 360 }}
              />
            </div>
            
            {paginatedServicePanels.map((panel) => (
              <Card 
                key={panel.service.service_name}
                className="glass-card" 
                style={{ marginBottom: 16, border: '1px solid rgba(88, 104, 184, 0.15)', borderRadius: 12 }}
                title={
                  <Flex justify="space-between" align="center" wrap gap={8}>
                    <Typography.Text strong style={{ fontSize: 15 }}>
                      Service: <span style={{ color: '#4b5dff' }}>{panel.service.service_name}</span>
                    </Typography.Text>
                    <Space size={16} style={{ fontSize: 11, color: 'var(--text-soft)' }} wrap>
                      <span>Endpoint: <code>{panel.service.endpoint_url || 'n/a'}</code></span>
                      <span>Bindings: <Tag>{safeArray(panel.service.bindings).length}</Tag></span>
                      <span>Ports: <Tag>{safeArray(panel.service.ports).length}</Tag></span>
                      <span>Operations: <Tag>{safeArray(panel.service.operations).length}</Tag></span>
                    </Space>
                  </Flex>
                }
              >
                <Collapse 
                  size="small"
                  style={{ background: 'transparent', border: 'none', marginBottom: 12 }}
                  items={[
                    {
                      key: 'summary-meta',
                      label: <Typography.Text strong style={{ color: '#8b5cf6', fontSize: 12 }}>View Service Metadata & Summary</Typography.Text>,
                      children: (
                        <div style={{ background: 'rgba(0,0,0,0.01)', padding: 12, borderRadius: 8, border: '1px solid var(--stroke)' }}>
                          <Space direction="vertical" size="small" style={{ width: '100%' }}>
                            <Typography.Text><strong>Documentation:</strong> {panel.service.documentation || 'n/a'}</Typography.Text>
                            <Typography.Text><strong>Namespace:</strong> {panel.service.namespace || 'n/a'}</Typography.Text>
                            <Typography.Text><strong>Endpoint URL:</strong> <code>{panel.service.endpoint_url || 'n/a'}</code></Typography.Text>
                            <Typography.Text><strong>Ports:</strong> {safeArray<any>(panel.service.ports).map((x: any) => x.port_name).join(', ') || 'n/a'}</Typography.Text>
                            <Typography.Text><strong>Bindings:</strong> {safeArray<any>(panel.service.bindings).map((x: any) => x.binding_name).join(', ') || 'n/a'}</Typography.Text>
                            <Typography.Text><strong>Operations:</strong> {safeArray<any>(panel.service.operations).map((x: any) => x.operation_name).join(', ') || 'n/a'}</Typography.Text>
                          </Space>
                        </div>
                      )
                    }
                  ]}
                />

                <div style={{ marginTop: 12 }}>
                  <Typography.Text type="secondary" strong style={{ display: 'block', marginBottom: 6, fontSize: 12 }}>Discovered Operations & Schema Payload Trees</Typography.Text>
                  <Table
                    rowKey={(r: any, idx?: number) => `${r?.service_name}-${r?.operation_name}-${idx}`}
                    dataSource={panel.operations}
                    pagination={false}
                    onRow={(record: any) => ({
                      onClick: () =>
                        setSelectedGroup({
                          service_name: record.service_name,
                          operation_name: record.operation_name,
                        }),
                    })}
                    expandable={{
                      expandedRowRender: (record: any) => {
                        const sections = [
                          { key: 'request', label: 'Request', color: 'blue', desc: 'Input payload structure' },
                          { key: 'response', label: 'Response', color: 'green', desc: 'Output payload structure' },
                          { key: 'meta', label: 'Meta', color: 'purple', desc: 'WSDL Binding, endpoint, port, and diagnostics' },
                          { key: 'error', label: 'Error', color: 'red', desc: 'Fault / error payload structure' }
                        ];
                        return (
                          <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                            {sections.map(({ key, label, color, desc }) => {
                              const data = record?.directions?.[key];
                              const isNotAvailable = !data || (data && typeof data === 'object' && 'empty' in data);
                              
                              return (
                                <Card
                                  key={key}
                                  size="small"
                                  title={
                                    <Space>
                                      <Tag color={color}>{label}</Tag>
                                      <Typography.Text type="secondary">{desc}</Typography.Text>
                                    </Space>
                                  }
                                >
                                  {isNotAvailable ? (
                                    <Typography.Text type="secondary" italic>No Data available</Typography.Text>
                                  ) : key === 'meta' ? (
                                    <JsonViewer data={data} />
                                  ) : (
                                    <CollapsibleFieldTree fields={data} />
                                  )}
                                </Card>
                              );
                            })}
                          </Space>
                        );
                      }
                    }}
                    columns={[
                      { title: 'Operation Name', dataIndex: 'operation_name', key: 'operation_name', sorter: (a, b) => (a.operation_name || '').localeCompare(b.operation_name || '') },
                      {
                        title: 'Validation Status Check',
                        render: (_: any, r: any) => {
                          const reqDiag = r?.diagnostics?.request || {};
                          const respDiag = r?.diagnostics?.response || {};
                          const errDiag = r?.diagnostics?.error || {};

                          const getStatusTag = (diag: any, name: string) => {
                            if (diag.missing) return <Tag color="error">✗ {name} Missing</Tag>;
                            if (diag.malformed) return <Tag color="warning">⚠ {name} Malformed</Tag>;
                            if (diag.child_elements_missing || diag.empty_node) return <Tag color="warning">⚠ {name} Empty</Tag>;
                            if (diag.present || diag.type_expanded) return <Tag color="success">✓ {name} Present</Tag>;
                            return <Tag color="default">? {name} No Schema</Tag>;
                          };

                          return (
                            <Space wrap>
                              {getStatusTag(reqDiag, 'Request')}
                              {getStatusTag(respDiag, 'Response')}
                              {getStatusTag(errDiag, 'Fault')}
                            </Space>
                          );
                        }
                      },
                    ]}
                  />
                </div>
              </Card>
            ))}

            {serviceGroupedPanels.length > wsdlPageSize && (
              <Flex justify="end" style={{ marginTop: 16 }}>
                <Pagination
                  current={wsdlPage}
                  pageSize={wsdlPageSize}
                  total={serviceGroupedPanels.length}
                  onChange={(p) => setWsdlPage(p)}
                />
              </Flex>
            )}
          </Card>
        )}

        {/* SECTION 5: Excel Extracts */}
        {activeSection === 'excel' && (
          <Card className="glass-card" title="Excel Metadata Extracts" bordered={false}>
            <div style={{ marginBottom: 16 }}>
              <Input.Search
                placeholder="Filter excel mappings"
                allowClear
                value={globalSearch}
                onChange={(e) => setGlobalSearch(e.target.value)}
                style={{ maxWidth: 360 }}
              />
            </div>
            
            <Table
              rowKey={(r: any, idx?: number) => `${r?.service_name}-${r?.operation_name}-${idx}`}
              dataSource={filteredExcel}
              pagination={{ pageSize: 10 }}
              onRow={(record: any) => ({
                onClick: () =>
                  setSelectedGroup({
                    service_name: record.service_name,
                    operation_name: record.operation_name,
                  }),
              })}
              columns={[
                { title: 'Excel Service Name', dataIndex: 'service_name', key: 'service_name' },
                { title: 'Excel Operation Name', dataIndex: 'operation_name', key: 'operation_name' },
                {
                  title: 'Upstream Apps',
                  render: (_: any, r: any) => safeArray<string>(r?.upstream_apps).map(app => <Tag key={app}>{app}</Tag>) || 'n/a',
                },
                {
                  title: 'Downstream Apps',
                  render: (_: any, r: any) => safeArray<string>(r?.downstream_apps).map(app => <Tag key={app}>{app}</Tag>) || 'n/a',
                },
                {
                  title: 'Data Sources',
                  render: (_: any, r: any) => safeArray<string>(r?.data_sources).map(ds => <Tag color="cyan" key={ds}>{ds}</Tag>) || 'n/a',
                },
              ]}
            />
          </Card>
        )}

        {/* SECTION 6: Merged Output */}
        {activeSection === 'merged' && (
          <Card className="glass-card" title="Consolidated Merged Output" bordered={false}>
            <Typography.Paragraph type="secondary">
              Merged spreadsheet metadata + active WSDL contracts. Expand rows to compare Excel metadata side-by-side with WSDL endpoint definitions and payload structures.
            </Typography.Paragraph>
            <div style={{ marginBottom: 16 }}>
              <Input.Search
                placeholder="Filter merged records"
                allowClear
                value={globalSearch}
                onChange={(e) => setGlobalSearch(e.target.value)}
                style={{ maxWidth: 360 }}
              />
            </div>
            
            <Table
              rowKey={(r: any, idx?: number) => `${r?.service_name}-${r?.operation_name}-${idx}`}
              dataSource={filteredMerged}
              pagination={{ pageSize: 10 }}
              onRow={(record: any) => ({
                onClick: () =>
                  setSelectedGroup({
                    service_name: record.service_name,
                    operation_name: record.operation_name,
                  }),
              })}
              expandable={{
                expandedRowRender: (record: any) => (
                  <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                    <Row gutter={[16, 16]}>
                      <Col span={12}>
                        <Card size="small" title="Excel Side Details" style={{ height: '100%' }}>
                          <Space direction="vertical" size="small">
                            <Typography.Text><strong>Excel Service Name:</strong> {record.excel_service_name || 'n/a'}</Typography.Text>
                            <Typography.Text><strong>Excel Operation Name:</strong> {record.excel_operation_name || 'n/a'}</Typography.Text>
                            <Typography.Text><strong>Upstream Systems:</strong> {record.upstream_apps_json?.join(', ') || 'none'}</Typography.Text>
                            <Typography.Text><strong>Downstream Systems:</strong> {record.downstream_apps_json?.join(', ') || 'none'}</Typography.Text>
                            <Typography.Text><strong>Data Sources:</strong> {record.data_sources_json?.join(', ') || 'none'}</Typography.Text>
                          </Space>
                        </Card>
                      </Col>
                      <Col span={12}>
                        <Card size="small" title="WSDL Side & Match details" style={{ height: '100%' }}>
                          <Space direction="vertical" size="small">
                            <Typography.Text>
                              <strong>Matching Confidence:</strong>{' '}
                              <Tag color={record.matching_confidence === 1.0 ? 'green' : record.matching_confidence === 0.5 ? 'orange' : 'red'}>
                                {Number(record.matching_confidence || 0) * 100}%
                              </Tag>
                            </Typography.Text>
                            <Typography.Text><strong>Matching Logic:</strong> {record.matching_logic_used || 'n/a'}</Typography.Text>
                            <Typography.Text><strong>Endpoint URL:</strong> <code>{record.endpoint_url || 'n/a'}</code></Typography.Text>
                            <Typography.Text><strong>Port:</strong> {record.port || 'n/a'}</Typography.Text>
                            <Typography.Text><strong>Binding:</strong> {record.binding || 'n/a'}</Typography.Text>
                          </Space>
                        </Card>
                      </Col>
                    </Row>
                    
                    <Collapse
                      size="small"
                      items={[
                        {
                          key: 'req',
                          label: 'Request Payload Field',
                          children: <CollapsibleFieldTree fields={record.request_structure_json} />
                        },
                        {
                          key: 'resp',
                          label: 'Response Payload Field',
                          children: <CollapsibleFieldTree fields={record.response_structure_json} />
                        },
                        {
                          key: 'err',
                          label: 'Error Payload Field',
                          children: <CollapsibleFieldTree fields={record.error_structure_json} />
                        }
                      ]}
                    />
                  </Space>
                )
              }}
              columns={[
                
                { title: 'Service Name', dataIndex: 'wsdl_service_name', key: 'wsdl_service_name' },
                { title: 'Operation Name', dataIndex: 'wsdl_operation_name', key: 'wsdl_operation_name' },
                { title: 'Endpoint URL', render: (_: any, r: any) => r?.endpoint_url ?? 'n/a', ellipsis: true },
                { title: 'Binding', dataIndex: 'binding', key: 'binding' },
                {
                  title: 'Upstream / Downstream',
                  render: (_: any, r: any) => (
                    <Space size={2} direction="vertical">
                      <Typography.Text style={{ fontSize: 11 }} type="secondary">U/s: {r.upstream_apps_json?.length || 0}</Typography.Text>
                      <Typography.Text style={{ fontSize: 11 }} type="secondary">D/s: {r.downstream_apps_json?.length || 0}</Typography.Text>
                    </Space>
                  )
                },
                {
                  title: 'Confidence',
                  render: (_: any, r: any) => (
                    <Tag color={r.matching_confidence === 1.0 ? 'green' : r.matching_confidence === 0.5 ? 'orange' : 'red'}>
                      {Number(r.matching_confidence || 0) * 100}%
                    </Tag>
                  )
                }
              ]}
            />
          </Card>
        )}

        {/* SECTION 7: Dependencies */}
        {(activeSection === 'dependencies') && (
          <Flex vertical gap={16}>
            <Card className="glass-card" title="Dependency Visualizations" bordered={false}>
              <Typography.Paragraph type="secondary">
                Inspect system flows. Select view modes below to render adjacency matrices, tabular node summaries, or interactive flowcharts.
              </Typography.Paragraph>
              <Flex vertical gap={12}>
                <Row justify="space-between" align="middle" gutter={[16, 16]}>
                  <Col>
                    <Segmented
                      options={['Table', 'Matrix', 'Flow']}
                      value={depView}
                      onChange={(v) => setDepView(v as typeof depView)}
                    />
                  </Col>
                  <Col>
                    <Space size={8} wrap>
                      <span style={{ fontSize: 13, color: 'var(--text-soft)' }}>Filter Relationship:</span>
                      <Segmented
                        options={[
                          { label: 'Combined View', value: 'combined' },
                          { label: 'Service to Service Only', value: 'service' },
                          { label: 'Data Source Dependencies Only', value: 'datasource' }
                        ]}
                        value={depCategory}
                        onChange={(v) => setDepCategory(v as any)}
                        size="small"
                      />
                    </Space>
                  </Col>
                </Row>
              </Flex>
            </Card>

            {depView === 'Table' && (
              <Card className="glass-card" title="Dependency" bordered={false}>
                <div style={{ marginBottom: 16 }}>
                  <Input.Search
                    placeholder="Search dependency component..."
                    allowClear
                    value={globalSearch}
                    onChange={(e) => setGlobalSearch(e.target.value)}
                    style={{ maxWidth: 360 }}
                  />
                </div>
                <Table
                  rowKey="key"
                  dataSource={filteredComponentDependencies}
                  pagination={{ pageSize: 10 }}
                  onRow={(record) => ({
                    onClick: () => {
                      setSelectedDepNode(record.calling_service)
                    }
                  })}
                  expandable={{
                    rowExpandable: (record) => record.component_type === 'Service' && !!record.raw_ops && record.raw_ops.length > 0,
                    expandedRowRender: (record) => (
                      <Card size="small" title={`Operations defined in ${record.calling_service}`} style={{ margin: 4 }}>
                        <Table
                          size="small"
                          rowKey="key"
                          dataSource={record.raw_ops}
                          pagination={false}
                          columns={[
                            { title: 'Operation Name', dataIndex: 'name', key: 'name', render: (v) => <strong>{v}</strong> },
                            { title: 'Upstream Systems (Incoming)', dataIndex: 'upstream', key: 'upstream' },
                            { title: 'Downstream Systems (Outgoing)', dataIndex: 'downstream', key: 'downstream' },
                            { title: 'Connected Data Sources', dataIndex: 'databases', key: 'databases', render: (v) => <Typography.Text type="warning">{v}</Typography.Text> }
                          ]}
                        />
                      </Card>
                    )
                  }}
                  columns={[
                    { 
                      title: 'Calling service', 
                      dataIndex: 'calling_service', 
                      key: 'calling_service',
                      render: (v) => <Typography.Text strong style={v === selectedDepNode ? { color: '#4b5dff' } : {}}>{v}</Typography.Text>
                    },
                    { 
                      title: 'Total Service Count', 
                      dataIndex: 'dependent_service', 
                      key: 'dependent_service',
                      render: (v) => <Typography.Text type="secondary" style={v === selectedDepNode ? { color: '#4b5dff' } : {}}>{v}</Typography.Text>
                    },
                    { 
                      title: 'Service to Service Count', 
                      dataIndex: 'service_to_service_count', 
                      key: 'service_to_service_count',
                    },
                    { 
                      title: 'Data Source Count', 
                      dataIndex: 'data_source_count', 
                      key: 'data_source_count',
                    },
                    { title: 'Operations Count', dataIndex: 'operations_count', key: 'operations_count' },
                    { 
                      title: 'Dependency Type', 
                      dataIndex: 'component_type', 
                      key: 'component_type',
                      render: (type: string) => <Tag color={type === 'Service' ? 'blue' : 'cyan'}>{type}</Tag>
                    }
                  ]}
                />
                {selectedDepNode && (
                  <Alert
                    style={{ marginTop: 16 }}
                    message={
                      <Flex justify="space-between" align="center">
                        <span>Selected Node Drill-down: <strong>{selectedDepNode}</strong></span>
                        <Button size="small" onClick={() => setSelectedDepNode(null)}>Clear Selection</Button>
                      </Flex>
                    }
                    description={`This component has been selected. You can switch to the Flow or Matrix view to inspect its neighborhood/paths, or use the AI Assistant to investigate its specific operations.`}
                    type="info"
                    showIcon
                  />
                )}
              </Card>
            )}

            {depView === 'Matrix' && (
              <MatrixView
                title="Dependency Matrix"
                rows={activeDeps}
              />
            )}

            {depView === 'Flow' && (
              activeDeps.length === 0 ? (
                <Card className="glass-card" bordered={false}>
                  <Empty description="No edges parsed" />
                </Card>
              ) : (
                <ColorfulFlowGraph 
                  rows={activeDeps} 
                  serviceSummary={summaryItems}
                  wsdlExtracts={groupedItems}
                  selectedNode={selectedDepNode}
                  setSelectedNode={setSelectedDepNode}
                />
              )
            )}
          </Flex>
        )}

        {/* SECTION 8: Storage & Schema */}
        {activeSection === 'storage' && (
          <Flex vertical gap={16}>
            <Card className="glass-card" title="Assessment Storage Summary" bordered={false}>
              {!structureSummary ? (
                <Empty description="Loading summary counts..." />
              ) : (
                <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                  <div>
                    <Typography.Text strong>{`Assessment: ${structureSummary.assessment.assessment_code}`}</Typography.Text>
                    <Typography.Paragraph type="secondary" style={{ marginBottom: 0 }}>
                      Status: {structureSummary.assessment.status} | SQLite: {structureSummary.assessment.wsdl_path}
                    </Typography.Paragraph>
                  </div>
                  <Space wrap>
                    {Object.entries(structureSummary.counts || {}).map(([k, v]) => (
                      <Card key={k} size="small" style={{ minWidth: 170 }}>
                        <Statistic title={k} value={Number(v)} />
                      </Card>
                    ))}
                  </Space>
                </Space>
              )}
            </Card>

            <Card className="glass-card" title="Schema Explorer & DB Query Runner" bordered={false}>
              <Flex justify="space-between" gap={12} wrap style={{ marginBottom: 16 }}>
                <Segmented
                  options={['Overview', 'Schema Explorer', 'SQL Runner']}
                  value={schemaMode}
                  onChange={(v) => setSchemaMode(v as SchemaMode)}
                />
                <Space wrap>
                  <Tag color="blue">SQLite DB: service_analyzer.db</Tag>
                  <Tag color="cyan">Read-only SQL Engine</Tag>
                </Space>
              </Flex>

              <Flex gap={16} align="start" wrap>
                <Card
                  size="small"
                  title={`Tables Database (${filteredDbTables.length})`}
                  style={{ minWidth: 280, flex: '0 0 280px' }}
                >
                  <Input.Search
                    placeholder="Search tables"
                    allowClear
                    value={dbTableSearch}
                    onChange={(e) => setDbTableSearch(e.target.value)}
                    style={{ marginBottom: 12 }}
                  />

                  <Table
                    size="small"
                    rowKey={(r: any) => r.table_name}
                    dataSource={filteredDbTables.map((name) => ({ table_name: name }))}
                    pagination={false}
                    onRow={(record: any) => ({
                      onClick: () => {
                        setSelectedTable(record.table_name)
                        setQueryText(`SELECT * FROM ${record.table_name}`)
                      },
                    })}
                    rowClassName={(record: any) =>
                      record.table_name === selectedTable ? 'ant-table-row-selected' : ''
                    }
                    columns={[
                      {
                        title: 'Table name',
                        dataIndex: 'table_name',
                        render: (value: string) => (
                          <Typography.Text strong={value === selectedTable}>{value}</Typography.Text>
                        ),
                      },
                    ]}
                  />
                </Card>

                <div style={{ flex: 1, minWidth: 400 }}>
                  {schemaMode === 'Overview' && (
                    <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                      <Table
                        rowKey="table_name"
                        dataSource={safeArray<any>(structureSummary?.tables)}
                        pagination={false}
                        columns={[
                          { title: 'Table', dataIndex: 'table_name' },
                          { title: 'Purpose Description', dataIndex: 'purpose' },
                          {
                            title: 'Assessment scoped',
                            render: (_: any, r: any) => (r.assessment_scoped ? 'Yes' : 'No'),
                          },
                          { title: 'Row count', dataIndex: 'row_count' },
                        ]}
                      />
                    </Space>
                  )}

                  {schemaMode === 'Schema Explorer' && (
                    <div style={{ background: 'rgba(0,0,0,0.01)', border: '1px solid var(--stroke)', borderRadius: 12, padding: 16 }}>
                      <Typography.Title level={4}>Table Schema: {selectedTable || 'None selected'}</Typography.Title>
                      
                      {selectedTable && schemaTree[selectedTable] ? (
                        <Space direction="vertical" size="large" style={{ width: '100%' }}>
                          <div>
                            <Typography.Text strong>Columns definition list:</Typography.Text>
                            <Table
                              size="small"
                              rowKey="name"
                              dataSource={schemaTree[selectedTable].columns}
                              pagination={false}
                              columns={[
                                { title: 'Column Name', dataIndex: 'name', render: (v: any, r: any) => <span>{v} {r.primary_key && <Tag color="gold">PK</Tag>}</span> },
                                { title: 'Type', dataIndex: 'type' },
                                { title: 'Nullable', dataIndex: 'nullable', render: (v: any) => (v ? 'Yes' : 'No') },
                                { title: 'Default', dataIndex: 'default', render: (v: any) => (v !== 'None' ? v : 'None') }
                              ]}
                            />
                          </div>

                          {schemaTree[selectedTable].foreign_keys?.length > 0 && (
                            <div>
                              <Typography.Text strong>Foreign key relationships:</Typography.Text>
                              <Table
                                size="small"
                                rowKey={(r: any, idx?: number) => `${r.referred_table}-${idx}`}
                                dataSource={schemaTree[selectedTable].foreign_keys}
                                pagination={false}
                                columns={[
                                  { title: 'Constrained Column', dataIndex: 'constrained_columns', render: (v: any) => v.join(', ') },
                                  { title: 'Referred Table', dataIndex: 'referred_table', render: (v: any) => <Tag color="blue">{v}</Tag> },
                                  { title: 'Referred Column', dataIndex: 'referred_columns', render: (v: any) => v.join(', ') }
                                ]}
                              />
                            </div>
                          )}
                        </Space>
                      ) : (
                        <Empty description="Select a database table on the left sidebar to analyze schemas" />
                      )}
                    </div>
                  )}

                  {schemaMode === 'SQL Runner' && (
                    <Space direction="vertical" size="large" style={{ width: '100%' }}>
                      <Card size="small" title="SQL Query editor">
                        <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                          <Alert
                            type="info"
                            showIcon
                            message="Run general queries"
                            description="Supports any read-only SQL statements. The database schema uses assessments, assessment_logs, available_services, service_properties, wsdl_extracts, excel_extracts, and merged_reports."
                          />

                          <div>
                            <Typography.Text strong>SQL Query</Typography.Text>
                            <Input.TextArea
                              value={queryText}
                              onChange={(e) => setQueryText(e.target.value)}
                              rows={6}
                              placeholder="SELECT * FROM wsdl_extracts LIMIT 10;"
                              style={{ marginTop: 8, fontFamily: 'monospace' }}
                            />
                          </div>

                          <Flex gap={8} wrap>
                            <Button
                              type="primary"
                              loading={rawQueryMutation.isPending}
                              onClick={() => handleRunSql(1, queryPageSize)}
                            >
                              Run raw SQL
                            </Button>

                            <Button onClick={() => setQueryText(`SELECT * FROM ${selectedTable || 'assessments'}`)}>
                              Select all rows
                            </Button>
                          </Flex>
                        </Space>
                      </Card>

                      <Card
                        size="small"
                        title="SQL Query execution results"
                        extra={
                          queryResult ? (
                            <Tag color="purple">{Number(queryResult.total || 0)} total rows found</Tag>
                          ) : null
                        }
                      >
                        {!queryResult ? (
                          <Empty description="Execute SELECT query to view output logs" />
                        ) : safeArray<any>(queryResult.rows).length === 0 ? (
                          <Empty description="No records returned" />
                        ) : (
                          <Table
                            rowKey={(row, idx) =>
                              String((row as Record<string, unknown>)?.id ?? `query-row-${idx}`)
                            }
                            dataSource={queryResult?.rows ?? []}
                            columns={queryResultColumns}
                            scroll={{ x: 'max-content' }}
                            pagination={{
                              current: queryPage,
                              pageSize: queryPageSize,
                              total: queryResult?.total ?? 0,
                              showSizeChanger: true,
                              onChange: (page, pageSize) => {
                                rerunLastQuery(page, pageSize)
                              },
                            }}
                          />
                        )}
                      </Card>
                    </Space>
                  )}
                </div>
              </Flex>
            </Card>

            <Card
              className="glass-card"
              title="Contract payload detail viewer"
              bordered={false}
            >
              <Typography.Paragraph type="secondary">
                Inspect detail definitions. Click a row in Service Summary, WSDL Extracts, Excel Extracts, or Merged Output to load payload contracts in this drawer.
              </Typography.Paragraph>

              {!structureDetail ? (
                <Empty description="Click on a row to map detailed structures" />
              ) : (
                <Collapse
                  size="large"
                  defaultActiveKey={['service-properties']}
                  items={[
                    {
                      key: 'service-properties',
                      label: `Service Contract Metadata`,
                      children: <JsonViewer data={structureDetail.service_properties} />,
                    },
                    {
                      key: 'wsdl-structure',
                      label: `Parsed WSDL outputs`,
                      children: <JsonViewer data={structureDetail.wsdl} />,
                    },
                    {
                      key: 'excel-structure',
                      label: `Excel mappings`,
                      children: <JsonViewer data={structureDetail.excel} />,
                    },
                    {
                      key: 'merged-structure',
                      label: `Consolidated merge fields`,
                      children: <JsonViewer data={structureDetail.merged} />,
                    },
                  ]}
                />
              )}
            </Card>
          </Flex>
        )}

        {/* SECTION 9: Logs */}
        {activeSection === 'logs' && (
          <Card className="glass-card" title="Assessment Run Logs" bordered={false}>
            <Typography.Paragraph type="secondary">
              Logs generated during the execution of this assessment.
            </Typography.Paragraph>
            
            <Table
              rowKey="id"
              dataSource={logItems}
              pagination={{ pageSize: 12 }}
              columns={[
                { title: 'Created Time', dataIndex: 'created_at', width: 220 },
                { 
                  title: 'Level', 
                  dataIndex: 'level', 
                  width: 120,
                  render: (v) => <Tag color={v === 'ERROR' ? 'red' : v === 'WARNING' ? 'gold' : 'blue'}>{v}</Tag> 
                },
                { title: 'Step', dataIndex: 'step', width: 180 },
                { 
                  title: 'Message Log', 
                  dataIndex: 'message',
                  render: (msg: string, record: any) => {
                    const step = record.step;
                    if (step === 'similarity' && msg.includes('skipped')) {
                      return 'Analyzing request/response similarity across service contracts.';
                    }
                    if (step === 'recommendation' && msg.includes('skipped')) {
                      return 'Generating service consolidation and architectural recommendations.';
                    }
                    return msg;
                  }
                }
              ]}
            />
          </Card>
        )}

        {/* SECTION 10: Exports */}
        {activeSection === 'exports' && (
          <Card className="glass-card" title="Export Assessment" bordered={false}>
            <Typography.Paragraph type="secondary">
              Download structural catalogs, dependencies, and baseline assessment summaries in Excel, CSV, or PDF format.
            </Typography.Paragraph>
            
            <Row gutter={[16, 16]}>
              {sortedExportItems.map((item, idx) => (
                <Col span={8} key={idx}>
                  <Card size="small" hoverable style={{ border: '1px solid var(--stroke)', borderRadius: 12 }}>
                    <Flex vertical gap={12}>
                      <Typography.Title level={5} style={{ margin: 0 }}>
                        {item.artifact_kind.replaceAll('_', ' ')}
                      </Typography.Title>
                      
                      <Space>
                        <Tag color={item.file_type === 'xlsx' ? 'green' : item.file_type === 'pdf' ? 'red' : 'blue'}>
                          {item.file_type.toUpperCase()}
                        </Tag>
                      </Space>
                      
                      <Button 
                        type="primary" 
                        href={`http://localhost:8000${item.download_url}`}
                        target="_blank" 
                        rel="noopener noreferrer"
                        style={{ marginTop: 8 }}
                      >
                        Download File
                      </Button>
                    </Flex>
                  </Card>
                </Col>
              ))}
              
              {sortedExportItems.length === 0 && (
                <Col span={24}>
                  <Empty description="No export artifacts found for this assessment." />
                </Col>
              )}
            </Row>
          </Card>
        )}

      </Flex>
      <Modal
        open={jsonModal.open}
        title={jsonModal.title || 'JSON Details'}
        onCancel={closeJsonModal}
        footer={null}
        width={1100}
        destroyOnHidden
      >
        <Space direction="vertical" size="large" style={{ width: '100%' }}>
          {isJsonRenderable(jsonModal.data) ? (
            <Card size="small" title="JSON as sub-table">
              <Table
                rowKey={(row: any, idx?: number) => String(row?.__rowKey ?? idx)}
                dataSource={safeArray<any>(jsonModalTableModel.rows)}
                columns={jsonModalTableModel.columns}
                scroll={{ x: 'max-content' }}
                pagination={{ pageSize: 8 }}
              />
            </Card>
          ) : (
            <Card size="small" title="Value">
              <Typography.Text>{stringifyCell(jsonModal.data)}</Typography.Text>
            </Card>
          )}

          <Card size="small" title="Raw JSON">
            <JsonViewer data={jsonModal.data} />
          </Card>
        </Space>
      </Modal>
    </>
  )
}