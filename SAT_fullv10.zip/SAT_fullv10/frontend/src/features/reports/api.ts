import { api } from "@/api/client";

import axios from 'axios'
const apix = axios.create({
  baseURL: 'http://localhost:8000/api/v1',
})

export async function fetchDbTables() {
  const { data } = await apix.get('/db/tables')
  return data
}

export async function fetchDbTableData(
  tableName: string,
  payload: { page?: number; page_size?: number } = {},
) {
  const { data } = await apix.get(`/db/tables/${tableName}`, {
    params: {
      page: payload.page ?? 1,
      page_size: payload.page_size ?? 50,
    },
  })
  return data
}

export async function runDbTableQuery(
  tableName: string,
  body: {
    query: string
    params?: Record<string, any>
    page?: number
    page_size?: number
  },
) {
  const { data } = await apix.post(`/db/tables/${tableName}/query`, {
    query: body.query,
    params: body.params ?? {},
    page: body.page ?? 1,
    page_size: body.page_size ?? 50,
  })
  return data
}

export async function fetchDbSchema() {
  const { data } = await apix.get('/db/schema')
  return data
}

export async function runDbQuery(
  body: {
    query: string
    params?: Record<string, any>
    page?: number
    page_size?: number
  },
) {
  const { data } = await apix.post('/db/query', {
    query: body.query,
    params: body.params ?? {},
    page: body.page ?? 1,
    page_size: body.page_size ?? 50,
  })
  return data
}

export async function fetchServiceSummary(assessmentId?:number|null)

{ 
    const {data}=await api.get('/reports/service-summary',{params:{assessment_id:assessmentId ?? undefined}});
 return data;

} export async function fetchRawExtracts(assessmentId:number){ const {data}=await api.get('/reports/raw-extracts',{params:{assessment_id:assessmentId}});

 return data;

} export async function fetchGroupedWSDLExtracts(assessmentId:number){ const {data}=await api.get('/reports/wsdl-extract-grouped',{params:{assessment_id:assessmentId}});

 return data;

} export async function fetchServiceDependency(assessmentId?:number|null){ const {data}=await api.get('/reports/service-dependency',{params:{assessment_id:assessmentId ?? undefined}});

 return data;

} export async function fetchDataSourceDependency(assessmentId?:number|null){ const {data}=await api.get('/reports/data-source-dependency',{params:{assessment_id:assessmentId ?? undefined}});

 return data;

} export async function fetchExports(assessmentId:number){ const {data}=await api.get('/reports/exports',{params:{assessment_id:assessmentId}});

 return data;

} export async function fetchStructureSummary(assessmentId:number){ const {data}=await api.get('/reports/structure-summary',{params:{assessment_id:assessmentId}});

 return data;

} export async function fetchStructureDetail(assessmentId:number, serviceName?:string|null, operationName?:string|null){ const {data}=await api.get('/reports/structure-detail',{params:{assessment_id:assessmentId, service_name:serviceName ?? undefined, operation_name:operationName ?? undefined}});

 return data;

}
