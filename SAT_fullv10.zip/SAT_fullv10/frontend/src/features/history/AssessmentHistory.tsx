import { useMemo } from 'react'
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query'
import { Button, Card, Popconfirm, Table, Tag, message } from 'antd'
import { fetchAssessments, deleteAssessment } from './api'
import { useAssessmentStore } from '@/store/useAssessmentStore'
export default function AssessmentHistory() {
  const qc = useQueryClient()
  const { data } = useQuery({ queryKey: ['assessment-history'], queryFn: fetchAssessments, refetchInterval: 5000 })
  const setAssessment = useAssessmentStore((s) => s.setAssessment)
  const currentId = useAssessmentStore((s) => s.assessmentId)
  const rows = Array.isArray(data?.items) ? data.items : []
  const rowsWithHints = useMemo(() => rows.map((row: any, idx: number) => ({ ...row, previous_assessment_id: rows[idx + 1]?.assessment_id ?? null, is_open: currentId === row.assessment_id })), [rows, currentId])
  const del = useMutation({ mutationFn: (id: number) => deleteAssessment(id), onSuccess: () => { message.success('Assessment deleted'); qc.invalidateQueries({ queryKey: ['assessment-history'] }) }, onError: (error: any) => message.error(error?.response?.data?.detail ?? 'Delete failed') })
  return <Card className='glass-card' title='Assessments' bordered={false}><Table rowKey='assessment_id' dataSource={rowsWithHints} pagination={{ pageSize: 6 }} columns={[{ title: 'Assessment', dataIndex: 'assessment_code' }, { title: 'Status', dataIndex: 'status', render: (v: string) => <Tag color={v === 'completed' ? 'green' : v === 'failed' ? 'red' : v === 'running' ? 'blue' : 'gold'}>{v}</Tag> }, { title: 'Started', dataIndex: 'started_at' }, { title: 'Finished', dataIndex: 'finished_at' }, { title: 'Action', render: (_, r: any) => <div style={{display:'flex', gap:8}}><Button type={r.is_open ? 'primary' : 'default'} onClick={() => { setAssessment(r.assessment_id, r.assessment_code, r.status); useAssessmentStore.getState().setActiveSection('wsdl'); }}>{r.is_open ? 'Opened' : 'Open'}</Button><Popconfirm title='Delete this assessment?' description='This deletes stored rows and exports for the selected assessment.' onConfirm={() => del.mutate(r.assessment_id)}><Button danger loading={del.isPending}>Delete</Button></Popconfirm></div> }]} /></Card>
}
