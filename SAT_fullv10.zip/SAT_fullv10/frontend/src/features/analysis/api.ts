import { api } from "@/api/client";
import type { AssessmentStatus } from "@/types";

type BrowserFile = File & {
  webkitRelativePath?: string;
};

export async function startAnalysis(
  wsdlFolderPath: string,
  excelFilePath: string,
): Promise<AssessmentStatus> {
  const { data } = await api.post<AssessmentStatus>('/analysis', {
    wsdl_folder_path: wsdlFolderPath,
    excel_file_path: excelFilePath,
  });
  return data;
}

export async function startUploadAnalysis(
  wsdlFiles: File[],
  excelFile: File,
): Promise<AssessmentStatus> {
  const form = new FormData();

  wsdlFiles.forEach((file) => {
    form.append('wsdl_files', file, file.name);
  });

  form.append('excel_file', excelFile, excelFile.name);

  // keep folder structure when folder upload is used
  form.append(
    'wsdl_relative_paths',
    JSON.stringify(
      wsdlFiles.map((file) => {
        const browserFile = file as BrowserFile;
        return browserFile.webkitRelativePath || file.name;
      }),
    ),
  );

  const { data } = await api.post<AssessmentStatus>('/analysis/upload', form, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });

  return data;
}

export async function getAssessmentStatus(
  assessmentId: number,
): Promise<AssessmentStatus> {
  const { data } = await api.get<AssessmentStatus>(`/analysis/${assessmentId}`);
  return data;
}

export async function cancelAssessment(assessmentId: number) {
  const { data } = await api.post(`/analysis/${assessmentId}/cancel`);
  return data;
}

export async function fetchAssessmentLogs(assessmentId: number) {
  const { data } = await api.get(`/history/assessments/${assessmentId}/logs`);
  return data;
}