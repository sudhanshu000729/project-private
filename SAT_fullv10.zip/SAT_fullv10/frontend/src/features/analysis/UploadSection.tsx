import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Button,
  Card,
  Divider,
  Flex,
  Form,
  Input,
  Radio,
  Space,
  Tag,
  Tooltip,
  Typography,
  Upload,
  message,
  Collapse,
} from 'antd'
import type { UploadFile } from 'antd/es/upload/interface'
import {
  FileSearchOutlined,
  FolderOpenOutlined,
  PauseCircleOutlined,
  PlayCircleOutlined,
  RobotOutlined,
  UploadOutlined,
} from '@ant-design/icons'
import {
  cancelAssessment,
  fetchAssessmentLogs,
  startAnalysis,
  startUploadAnalysis,
  getAssessmentStatus,
} from './api'
import { useAssessmentStore } from '@/store/useAssessmentStore'
import StepProgressPanel from '@/components/StepProgressPanel'

type BrowserFile = File & {
  webkitRelativePath?: string
}

function isWsdlOrXsd(file: File) {
  return /\.(wsdl|xsd)$/i.test(file.name)
}

function getFileKey(file: File) {
  const browserFile = file as BrowserFile
  return browserFile.webkitRelativePath || file.name
}

function mergeUniqueFiles(existing: File[], incoming: File[]) {
  const map = new Map<string, File>()

  existing.forEach((file) => {
    map.set(getFileKey(file), file)
  })

  incoming.forEach((file) => {
    map.set(getFileKey(file), file)
  })

  return Array.from(map.values())
}

export default function UploadSection({ onOpenAI }: { onOpenAI: () => void }) {
  const [form] = Form.useForm()
  const [submitting, setSubmitting] = useState(false)
  const [mode, setMode] = useState<'path' | 'upload'>('path')
  const [wsdlFiles, setWSDLFiles] = useState<File[]>([])
  const [excelFile, setExcelFile] = useState<File | null>(null)

  const assessmentId = useAssessmentStore((s) => s.assessmentId)
  const status = useAssessmentStore((s) => s.status)
  const setAssessment = useAssessmentStore((s) => s.setAssessment)
  const setStatus = useAssessmentStore((s) => s.setStatus)
  const setActiveSection = useAssessmentStore((s) => s.setActiveSection)
  const clear = useAssessmentStore((s) => s.clear)

  const canCancel = !!assessmentId && status === 'running'
  const hasCompletedAssessment = status === 'completed'

  const logsQuery = useQuery({
    queryKey: ['assessment-logs', assessmentId],
    queryFn: () => fetchAssessmentLogs(assessmentId as number),
    enabled: !!assessmentId,
    refetchInterval: status === 'queued' || status === 'running' ? 1200 : false,
  })

  useQuery({
    queryKey: ['assessment-status-poll', assessmentId, status],
    queryFn: async () => {
      if (!assessmentId) return null
      const res = await getAssessmentStatus(assessmentId)
      if (res && res.status !== status) {
        setStatus(res.status as any)
        if (res.status === 'completed') {
          message.success('Assessment completed!')
          useAssessmentStore.getState().setActiveSection('wsdl')
        }
      }
      return res
    },
    enabled: !!assessmentId && (status === 'running' || status === 'queued'),
    refetchInterval: 2000
  })

  const logs = useMemo(
    () => (Array.isArray(logsQuery.data?.items) ? logsQuery.data.items : []),
    [logsQuery.data],
  )

  const addWsdlFiles = (incoming: File[]) => {
    const filtered = incoming.filter(isWsdlOrXsd)
    if (filtered.length === 0) {
      message.warning('Only .wsdl and .xsd files are allowed')
      return
    }
    setWSDLFiles((prev) => mergeUniqueFiles(prev, filtered))
  }

  const removeWsdlFile = (fileToRemove: File) => {
    const keyToRemove = getFileKey(fileToRemove)
    setWSDLFiles((prev) => prev.filter((file) => getFileKey(file) !== keyToRemove))
  }

  const onRunPath = async (values: { wsdlFolderPath: string; excelFilePath: string }) => {
    setSubmitting(true)
    try {
      clear()
      const row = await startAnalysis(values.wsdlFolderPath, values.excelFilePath)
      setAssessment(row.assessment_id, row.assessment_code, row.status as any)
      message.success(`Assessment ${row.assessment_code} created`)
      setTimeout(() => {
        document.getElementById('progress-panel')?.scrollIntoView({ behavior: 'smooth' })
      }, 100)
      if (row.status === 'completed') {
        setActiveSection('wsdl')
      }
    } catch (error: any) {
      message.error(error?.response?.data?.detail ?? 'Could not start assessment')
    } finally {
      setSubmitting(false)
    }
  }

  const onRunUpload = async () => {
    if (!excelFile || wsdlFiles.length === 0) {
      message.warning('Select WSDL/XSD files or folder, and one Excel file')
      return
    }

    setSubmitting(true)
    try {
      clear()
      const row = await startUploadAnalysis(wsdlFiles, excelFile)
      setAssessment(row.assessment_id, row.assessment_code, row.status as any)
      message.success(`Assessment ${row.assessment_code} created`)
      setTimeout(() => {
        document.getElementById('progress-panel')?.scrollIntoView({ behavior: 'smooth' })
      }, 100)
      if (row.status === 'completed') {
        setActiveSection('wsdl')
      }
    } catch (error: any) {
      message.error(error?.response?.data?.detail ?? 'Could not upload and start assessment')
    } finally {
      setSubmitting(false)
    }
  }

  const onCancel = async () => {
    if (!canCancel || !assessmentId) return
    setSubmitting(true)
    try {
      await cancelAssessment(assessmentId)
      setStatus('cancelled')
      message.warning('Cancellation requested')
    } catch (error: any) {
      message.error(error?.response?.data?.detail ?? 'Could not cancel assessment')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div id="upload-section">
      <Card className="glass-card" bordered={false}>
        <Flex vertical gap={8}>
          <Typography.Title level={3} style={{ margin: 0 }}>
            Upload section
          </Typography.Title>

          <Typography.Text type="secondary">
            Choose either path mode or upload mode. Path mode accepts a WSDL repository
            folder path or a single WSDL file path. Upload mode accepts WSDL/XSD files,
            a WSDL/XSD folder, and one Excel file.
          </Typography.Text>

          <Radio.Group value={mode} onChange={(e) => setMode(e.target.value)}>
            <Radio.Button value="path">Path mode</Radio.Button>
            <Radio.Button value="upload">Upload mode</Radio.Button>
          </Radio.Group>

          {mode === 'path' ? (
            <Form form={form} layout="vertical" onFinish={onRunPath} style={{ marginTop: 12 }}>
              <Form.Item
                name="wsdlFolderPath"
                label="WSDL repository or single WSDL file path"
                rules={[{ required: true, message: 'Enter the WSDL repository or file path' }]}
              >
                <Input
                  prefix={<FileSearchOutlined />}
                  placeholder="C:\repo\WSDLRepo or C:\repo\Service.wsdl"
                  size="large"
                />
              </Form.Item>

              <Form.Item
                name="excelFilePath"
                label="Excel file path"
                rules={[{ required: true, message: 'Enter the Excel file path' }]}
              >
                <Input
                  prefix={<FileSearchOutlined />}
                  placeholder="C:\repo\analysis.xlsx"
                  size="large"
                />
              </Form.Item>

              <Space>
                <Button
                  type="primary"
                  htmlType="submit"
                  icon={<PlayCircleOutlined />}
                  loading={submitting}
                  size="large"
                >
                  Analyze Services
                </Button>

                <Button
                  danger
                  icon={<PauseCircleOutlined />}
                  disabled={!canCancel}
                  onClick={onCancel}
                  loading={submitting}
                  size="large"
                >
                  Cancel
                </Button>

                <Tooltip title={!hasCompletedAssessment ? "Please open and analyze an assessment first." : undefined}>
                  <span style={!hasCompletedAssessment ? { cursor: 'not-allowed' } : undefined}>
                    <Button 
                      icon={<RobotOutlined />} 
                      onClick={onOpenAI} 
                      size="large"
                      disabled={!hasCompletedAssessment}
                      style={!hasCompletedAssessment ? { pointerEvents: 'none' } : undefined}
                    >
                      AI Analysis
                    </Button>
                  </span>
                </Tooltip>
              </Space>
            </Form>
          ) : (
            <div style={{ marginTop: 12 }}>
              <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                <div>
                  <Typography.Text strong>WSDL repo or single WSDL upload</Typography.Text>

                  <div style={{ marginTop: 8 }}>
                    <Space wrap>
                      <Upload
                        multiple
                        showUploadList={false}
                        accept=".wsdl,.xsd"
                        beforeUpload={(file) => {
                          addWsdlFiles([file as unknown as File])
                          return false
                        }}
                      >
                        <Button icon={<UploadOutlined />}>
                          Select WSDL/XSD files
                        </Button>
                      </Upload>

                      <Upload
                        directory
                        showUploadList={false}
                        accept=".wsdl,.xsd"
                        beforeUpload={(file) => {
                          addWsdlFiles([file as unknown as File])
                          return false
                        }}
                      >
                        <Button icon={<FolderOpenOutlined />}>
                          Select WSDL/XSD folder
                        </Button>
                      </Upload>

                      {wsdlFiles.length > 0 && (
                        <Button onClick={() => setWSDLFiles([])}>
                          Clear WSDL/XSD selection
                        </Button>
                      )}
                    </Space>
                  </div>

                  <Typography.Text type="secondary" style={{ display: 'block', marginTop: 8 }}>
                    Tip: choose one or more .wsdl/.xsd files, or choose a whole folder.
                    File and folder selections are merged into one list.
                  </Typography.Text>

                  {wsdlFiles.length > 0 && (
                    <div style={{ marginTop: 12 }}>
                      <Collapse
                        size="small"
                        ghost
                        items={[
                          {
                            key: 'uploaded-wsdl-list',
                            label: (
                              <Typography.Text strong style={{ color: '#4b5dff' }}>
                                View Discovered WSDL/XSD Files ({wsdlFiles.length})
                              </Typography.Text>
                            ),
                            children: (
                              <div
                                style={{
                                  marginTop: 8,
                                  display: 'flex',
                                  flexWrap: 'wrap',
                                  gap: 8,
                                  maxHeight: '200px',
                                  overflowY: 'auto',
                                  border: '1px solid var(--stroke)',
                                  borderRadius: '8px',
                                  padding: '12px'
                                }}
                              >
                                {wsdlFiles.map((file, idx) => (
                                  <Tag
                                    key={`${getFileKey(file)}-${idx}`}
                                    color="blue"
                                    closable
                                    onClose={(e) => {
                                      e.preventDefault()
                                      removeWsdlFile(file)
                                    }}
                                  >
                                    {getFileKey(file)}
                                  </Tag>
                                ))}
                              </div>
                            )
                          }
                        ]}
                      />
                    </div>
                  )}
                </div>

                <div>
                  <Typography.Text strong>Excel upload</Typography.Text>

                  <div style={{ marginTop: 8 }}>
                    <Upload
                      multiple={false}
                      maxCount={1}
                      showUploadList={false}
                      accept=".xlsx,.xls,.csv"
                      beforeUpload={(file) => {
                        setExcelFile(file as unknown as File)
                        return false
                      }}
                    >
                      <Button icon={<UploadOutlined />}>Select Excel file</Button>
                    </Upload>
                  </div>

                  {excelFile && (
                    <div style={{ marginTop: 12 }}>
                      <Tag
                        color="green"
                        closable
                        onClose={(e) => {
                          e.preventDefault()
                          setExcelFile(null)
                        }}
                      >
                        {excelFile.name}
                      </Tag>
                    </div>
                  )}
                </div>

                <Space>
                  <Button
                    type="primary"
                    icon={<PlayCircleOutlined />}
                    loading={submitting}
                    onClick={onRunUpload}
                    size="large"
                  >
                    Analyze Services
                  </Button>

                  <Button
                    danger
                    icon={<PauseCircleOutlined />}
                    disabled={!canCancel}
                    onClick={onCancel}
                    loading={submitting}
                    size="large"
                  >
                    Cancel
                  </Button>

                  <Tooltip title={!hasCompletedAssessment ? "Please open and analyze an assessment first." : undefined}>
                    <span style={!hasCompletedAssessment ? { cursor: 'not-allowed' } : undefined}>
                      <Button 
                        icon={<RobotOutlined />} 
                        onClick={onOpenAI} 
                        size="large"
                        disabled={!hasCompletedAssessment}
                        style={!hasCompletedAssessment ? { pointerEvents: 'none' } : undefined}
                      >
                        AI Analysis
                      </Button>
                    </span>
                  </Tooltip>
                </Space>
              </Space>
            </div>
          )}

          <Divider />
          <div id="progress-panel" style={{ scrollMarginTop: 24 }}>
            <StepProgressPanel status={status} logs={logs} />
          </div>
        </Flex>
      </Card>
    </div>
  )
}