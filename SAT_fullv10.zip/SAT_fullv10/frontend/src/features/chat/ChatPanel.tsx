import { useState, useMemo, useEffect } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { Button, Card, Flex, Input, List, Space, Spin, Tag, Typography, Collapse, Table, message, Select, Row, Col, Statistic, Popconfirm, Alert } from 'antd'
import { DownloadOutlined, RobotOutlined } from '@ant-design/icons'
import { askQuestion, getChatHistory, deleteChatHistory, exportChatHistoryPdf, compareAssessments } from './api'
import { useAssessmentStore } from '@/store/useAssessmentStore'
import { fetchAssessments } from '../history/api'

const starterQuestions = [
  'Compare this assessment service contracts and find duplicate services.',
  'Detect similar request/response schemas and recommend standard patterns.',
  'Analyze pattern reuse across services and list consolidation recommendations.'
]

export default function ChatPanel() {
  const assessmentId = useAssessmentStore((s) => s.assessmentId)
  const assessmentCode = useAssessmentStore((s) => s.assessmentCode)
  const status = useAssessmentStore((s) => s.status)
  const chatHistories = useAssessmentStore((s) => s.chatHistories)
  const addChatMessage = useAssessmentStore((s) => s.addChatMessage)
  const clearChatHistory = useAssessmentStore((s) => s.clearChatHistory)

  const [question, setQuestion] = useState(starterQuestions[0])
  const [downloadingHistoryPdf, setDownloadingHistoryPdf] = useState(false)
  const [compareIdA, setCompareIdA] = useState<number | null>(null)
  const [compareIdB, setCompareIdB] = useState<number | null>(null)
  const [comparing, setComparing] = useState(false)
  const [compareResult, setCompareResult] = useState<{
    answer: string;
    similarity_score: number;
    confidence_score: number;
    pdf_compare_url?: string;
    assessment_code_a?: string;
    assessment_code_b?: string;
  } | null>(null)

  const { data: assessmentsData } = useQuery({
    queryKey: ['assessments-list'],
    queryFn: fetchAssessments
  })

  const completedAssessmentsOptions = useMemo(() => {
    const list = assessmentsData?.items || []
    return list
      .filter((a: any) => a.status === 'completed')
      .map((a: any) => ({
        label: a.assessment_code,
        value: a.assessment_id
      }))
  }, [assessmentsData])

  const handleCompare = async () => {
    if (!compareIdA || !compareIdB) return
    setComparing(true)
    setCompareResult(null)
    try {
      const data = await compareAssessments(compareIdA, compareIdB)
      setCompareResult(data)
      message.success('Assessments compared successfully')
      
      if (data.pdf_compare_url) {
        const a = document.createElement('a')
        a.href = `http://localhost:8000${data.pdf_compare_url}`
        a.download = `Compare_${data.assessment_code_a}_vs_${data.assessment_code_b}.pdf`
        document.body.appendChild(a)
        a.click()
        a.remove()
      }
    } catch (e: any) {
      console.error(e)
      message.error(e?.response?.data?.detail ?? e.message ?? 'Comparison failed')
    } finally {
      setComparing(false)
    }
  }

  const history = assessmentId ? (chatHistories[assessmentId] || []) : []
  const reversedHistory = useMemo(() => [...history].reverse(), [history])

  useEffect(() => {
    if (!assessmentId) return
    let active = true
    const fetchHistory = async () => {
      try {
        const data = await getChatHistory(assessmentId)
        if (active) {
          useAssessmentStore.setState((state) => {
            const updated = {
              ...state.chatHistories,
              [assessmentId]: data
            }
            try { sessionStorage.setItem("sat_chat_histories", JSON.stringify(updated)) } catch {}
            return { chatHistories: updated }
          })
        }
      } catch (e) {
        console.error("Failed to load chat history", e)
      }
    }
    fetchHistory()
    return () => {
      active = false
    }
  }, [assessmentId])

  useEffect(() => {
    if (assessmentId) {
      setCompareIdA(assessmentId)
    }
  }, [assessmentId])

  const canAsk = !!assessmentId && status === 'completed' && !!question.trim()

  const handleDownloadHistoryPdf = async () => {
    if (!assessmentCode || history.length === 0) return
    setDownloadingHistoryPdf(true)
    try {
      const historyPayload = history.map(item => ({
        question: item.question,
        answer: item.answer,
        duplicates: item.duplicates || [],
        similar_schemas: item.similar_schemas || [],
        pattern_reuse: item.pattern_reuse || [],
        recommendations: item.recommendations || []
      }))
      const blob = await exportChatHistoryPdf(assessmentCode, historyPayload)
      const url = window.URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }))
      const a = document.createElement('a')
      a.href = url
      a.download = `${assessmentCode}_Ai_Q_A.pdf`
      document.body.appendChild(a)
      a.click()
      a.remove()
      window.URL.revokeObjectURL(url)
      message.success('Consolidated AI PDF report downloaded successfully')
    } catch (err: any) {
      console.error(err)
      message.error(err.message || 'Failed to download consolidated PDF report')
    } finally {
      setDownloadingHistoryPdf(false)
    }
  }

  const mutation = useMutation({
    mutationFn: (q: string) => askQuestion(q, assessmentId),
    onSuccess: (data) => {
      if (assessmentId) {
        addChatMessage(assessmentId, {
          question,
          answer: data.answer,
          duplicates: data.duplicates || [],
          similar_schemas: data.similar_schemas || [],
          pattern_reuse: data.pattern_reuse || [],
          recommendations: data.recommendations || [],
          excel_download_url: data.excel_download_url,
          pdf_download_url: data.pdf_download_url,
          grounded: data.grounded_services ?? [],
          stats: data.stats
        })
      }
      setQuestion('')
    },
    onError: (error: any) => {
      message.error(error?.response?.data?.detail ?? 'AI request failed')
    }
  })


  return (
    <Card 
      className='glass-card' 
      title={
        <Space>
          <RobotOutlined style={{ color: '#4b5dff' }} />
          <span>AI Assistant & Assessment Consolidation</span>
        </Space>
      }
      extra={
        assessmentId && history.length > 0 && (
          <Space>
            <Button
              type="primary"
              icon={<DownloadOutlined />}
              onClick={handleDownloadHistoryPdf}
              loading={downloadingHistoryPdf}
              style={{ borderRadius: 8 }}
            >
              AI Report
            </Button>
            <Popconfirm
              title="Clear Chat History"
              description="Are you sure you want to clear the chat history for this assessment? This action cannot be undone."
              onConfirm={async () => {
                try {
                  await deleteChatHistory(assessmentId)
                  clearChatHistory(assessmentId)
                  message.success("Chat history cleared")
                } catch (e: any) {
                  message.error(e.message || "Failed to clear chat history")
                }
              }}
              okText="Yes, Clear"
              cancelText="Cancel"
            >
              <Button type="text" danger>
                Clear History
              </Button>
            </Popconfirm>
          </Space>
        )
      }
      bordered={false}
    >
      <Typography.Paragraph type='secondary'>
        Ask questions comparing multiple assessments, detecting duplicate endpoints, similar request/response formats, or standard consolidation strategies. The Ask Button becomes active after assessment completes.
      </Typography.Paragraph>

      <Collapse
        style={{ marginBottom: 20, borderRadius: 12, overflow: 'hidden', border: '1px solid rgba(88, 104, 184, 0.15)' }}
        items={[
          {
            key: 'compare-assessments-section',
            label: <Typography.Text strong style={{ color: '#4b5dff' }}><RobotOutlined style={{ marginRight: 6 }} /> Cross-Assessment Comparison Tool (Deterministic Diff)</Typography.Text>,
            children: (
              <Space direction="vertical" style={{ width: '100%' }} size="middle">
                <Typography.Paragraph type="secondary" style={{ marginBottom: 8 }}>
                  Compare two completed assessment runs to generate an exact, hallucination-free comparison PDF using schema diffing, optimized for zero memory overhead.
                </Typography.Paragraph>
                <Flex gap={16} align="center" wrap>
                  <Space>
                    <span>Assessment A:</span>
                    <Select
                      style={{ width: 220 }}
                      value={assessmentId}
                      options={completedAssessmentsOptions}
                      disabled
                    />
                  </Space>
                  <Space>
                    <span>Assessment B:</span>
                    <Select
                      placeholder="Select Assessment B"
                      style={{ width: 220 }}
                      value={compareIdB}
                      onChange={setCompareIdB}
                      options={completedAssessmentsOptions?.filter((o: any) => o.value !== assessmentId)}
                      allowClear
                    />
                  </Space>
                  <Button
                    type="primary"
                    onClick={handleCompare}
                    loading={comparing}
                    disabled={!compareIdA || !compareIdB || compareIdA === compareIdB}
                  >
                    Compare Assessments
                  </Button>
                </Flex>
                
                {compareResult && (
                  <Card size="small" style={{ marginTop: 12, borderRadius: 8 }}>
                    <Alert
                      message="Comparison Report Ready"
                      description={
                        <Space direction="vertical" size="small" style={{ width: '100%' }}>
                          <div>The cross-assessment comparison has been compiled. You can download the report as a PDF.</div>
                          {compareResult.stats && (
                            <div style={{ marginTop: 4, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                              <Tag color="blue">Memory Used: {compareResult.stats.process_memory_mb} MB</Tag>
                              <Tag color="green">System RAM: {compareResult.stats.system_memory_percent}%</Tag>
                            </div>
                          )}
                        </Space>
                      }
                      type="success"
                      showIcon
                      action={
                        compareResult.pdf_compare_url && (
                          <Button
                            type="primary"
                            icon={<DownloadOutlined />}
                            onClick={() => {
                              const a = document.createElement('a')
                              a.href = `http://localhost:8000${compareResult.pdf_compare_url}`
                              a.download = `Compare_${compareResult.assessment_code_a}_vs_${compareResult.assessment_code_b}.pdf`
                              document.body.appendChild(a)
                              a.click()
                              a.remove()
                            }}
                            style={{ borderRadius: 8 }}
                          >
                            Download PDF
                          </Button>
                        )
                      }
                    />
                  </Card>
                )}
              </Space>
            )
          }
        ]}
      />

      <Space wrap style={{ marginBottom: 16 }}>
        {starterQuestions.map((q) => (
          <Tag 
            key={q} 
            color="blue"
            style={{ cursor: 'pointer', padding: '6px 12px', borderRadius: '8px' }} 
            onClick={() => setQuestion(q)}
          >
            {q}
          </Tag>
        ))}
      </Space>

      <Flex gap={12} align="start" vertical style={{ width: '100%' }}>
        <Input.TextArea 
          value={question} 
          onChange={(e) => setQuestion(e.target.value)} 
          rows={4} 
          placeholder="Ask a question or request a comparison..."
          style={{ width: '100%', borderRadius: 12 }}
        />
        <Button 
          type='primary' 
          disabled={!canAsk} 
          loading={mutation.isPending}
          onClick={() => mutation.mutate(question)}
          size="large"
          style={{ borderRadius: 8 }}
        >
          Ask Assistant
        </Button>
      </Flex>

      {mutation.isPending && (
        <Flex justify="center" style={{ marginTop: 24, marginBottom: 24 }}>
          <Spin tip="AI is analyzing schemas and preparing sheets..." size="large" />
        </Flex>
      )}

      <List 
        dataSource={reversedHistory} 
        style={{ marginTop: 24 }} 
        locale={{ 
          emptyText: status !== 'completed' 
            ? 'Complete the assessment to enable AI analysis' 
            : 'No AI questions asked yet' 
        }} 
        renderItem={(item) => (
          <List.Item style={{ display: 'block', borderBottom: '1px solid var(--stroke)', paddingBottom: 24 }}>
            <Flex vertical gap={12} style={{ width: '100%' }}>
              <Typography.Text strong style={{ fontSize: 16 }}>
                User Question: {item.question}
              </Typography.Text>

              {item.stats && (
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 4 }}>
                  <Tag color="blue">RAM: {item.stats.process_memory_mb} MB</Tag>
                  <Tag color="cyan">System RAM: {item.stats.system_memory_percent}%</Tag>
                  {item.stats.ai_tokens_used > 0 && (
                    <Tag color="purple">Gemini Tokens: {item.stats.ai_tokens_used}</Tag>
                  )}
                </div>
              )}
              
              <div style={{ background: 'rgba(0,0,0,0.01)', border: '1px solid var(--stroke)', borderRadius: 12, padding: 16 }}>
                <Typography.Paragraph style={{ whiteSpace: 'pre-wrap', marginBottom: 0, lineHeight: 1.6 }}>
                  {item.answer}
                </Typography.Paragraph>
              </div>

              {(item.excel_download_url || item.pdf_download_url) && (
                <Space wrap style={{ marginTop: 8 }}>
                  {item.excel_download_url && (
                    <Button 
                      type="primary" 
                      icon={<DownloadOutlined />} 
                      href={`http://localhost:8000${item.excel_download_url}`}
                      target="_blank"
                      style={{ borderRadius: 8 }}
                    >
                      Download Excel Report
                    </Button>
                  )}
                  {item.pdf_download_url && (
                    <Button 
                      type="primary" 
                      icon={<DownloadOutlined />} 
                      href={`http://localhost:8000${item.pdf_download_url}`}
                      target="_blank"
                      style={{ borderRadius: 8, backgroundColor: '#dc2626', borderColor: '#dc2626' }}
                    >
                      Download PDF Report
                    </Button>
                  )}
                </Space>
              )}

              {/* Collapsible Tables for Structured JSON Outputs */}
              <Collapse 
                size="small" 
                style={{ marginTop: 12 }}
                items={([
                  // 1. Recommendations Table
                  item.recommendations?.length > 0 ? {
                    key: 'recs',
                    label: `Consolidation Recommendations (${item.recommendations.length})`,
                    children: (
                      <Table 
                        size="small"
                        rowKey={(r: any, idx?: number) => `${r.title}-${idx}`}
                        dataSource={item.recommendations}
                        pagination={false}
                        columns={[
                          { title: 'Category', dataIndex: 'category', render: (v: any) => <Tag color="blue">{v}</Tag> },
                          { title: 'Recommendation Title', dataIndex: 'title', render: (v: any) => <strong>{v}</strong> },
                          { title: 'Details', dataIndex: 'details' },
                          { title: 'Impact', dataIndex: 'impact' },
                          { title: 'Effort', dataIndex: 'effort', render: (v: any) => <Tag color={v === 'Low' ? 'green' : v === 'Medium' ? 'orange' : 'red'}>{v}</Tag> }
                        ]}
                      />
                    )
                  } : null,
                  // 2. Duplicates Table
                  item.duplicates?.length > 0 ? {
                    key: 'dups',
                    label: `Duplicate Services Detected (${item.duplicates.length})`,
                    children: (
                      <Table 
                        size="small"
                        rowKey={(r: any, idx?: number) => `${r.service_a}-${r.service_b}-${idx}`}
                        dataSource={item.duplicates}
                        pagination={false}
                        columns={[
                          { title: 'Service A', dataIndex: 'service_a' },
                          { title: 'Service B', dataIndex: 'service_b' },
                          { title: 'Similarity', dataIndex: 'similarity_score', render: (v: any) => <Tag color="purple">{Number(v) * 100}%</Tag> },
                          { title: 'Confidence', dataIndex: 'confidence_score', render: (v: any) => <Tag color="green">{Number(v) * 100}%</Tag> },
                          { title: 'Reason / Details', dataIndex: 'details' },
                          { title: 'Consolidation Recommendation', dataIndex: 'recommendations' }
                        ]}
                      />
                    )
                  } : null,
                  // 3. Similar Schemas Table
                  item.similar_schemas?.length > 0 ? {
                    key: 'schemas',
                    label: `Similar Operation Schemas Detected (${item.similar_schemas.length})`,
                    children: (
                      <Table 
                        size="small"
                        rowKey={(r: any, idx?: number) => `${r.service_a}-${r.operation_a}-${idx}`}
                        dataSource={item.similar_schemas}
                        pagination={false}
                        columns={[
                          { title: 'Schema A', render: (_: any, r: any) => <span>{r.service_a}.{r.operation_a} <Tag>{r.direction_a}</Tag></span> },
                          { title: 'Schema B', render: (_: any, r: any) => <span>{r.service_b}.{r.operation_b} <Tag>{r.direction_b}</Tag></span> },
                          { title: 'Similarity', dataIndex: 'similarity_score', render: (v: any) => <Tag color="purple">{Number(v) * 100}%</Tag> },
                          { title: 'Confidence', dataIndex: 'confidence_score', render: (v: any) => <Tag color="green">{Number(v) * 100}%</Tag> },
                          { title: 'Overlaps', dataIndex: 'details' },
                          { title: 'Recommendations', dataIndex: 'recommendations' }
                        ]}
                      />
                    )
                  } : null,
                  // 4. Pattern Reuse Table
                  item.pattern_reuse?.length > 0 ? {
                    key: 'patterns',
                    label: `Pattern Reuse Detected (${item.pattern_reuse.length})`,
                    children: (
                      <Table 
                        size="small"
                        rowKey={(r: any, idx?: number) => `${r.pattern_name}-${idx}`}
                        dataSource={item.pattern_reuse}
                        pagination={false}
                        columns={[
                          { title: 'Pattern Name', dataIndex: 'pattern_name', render: (v: any) => <strong>{v}</strong> },
                          { title: 'Description', dataIndex: 'description' },
                          { title: 'Reused By Services', dataIndex: 'reused_by', render: (v: string[]) => v.map(svc => <Tag key={svc}>{svc}</Tag>) },
                          { title: 'Similarity', dataIndex: 'similarity_score', render: (v: any) => <Tag color="purple">{Number(v) * 100}%</Tag> },
                          { title: 'Recommendations', dataIndex: 'recommendations' }
                        ]}
                      />
                    )
                  } : null
                ].filter(Boolean) as any[])}
              />

              <Space wrap style={{ marginTop: 8 }}>
                {(item.grounded || []).map((svc: string) => (
                  <Tag color="cyan" key={svc}>{svc}</Tag>
                ))}
              </Space>
            </Flex>
          </List.Item>
        )} 
      />
    </Card>
  )
}
