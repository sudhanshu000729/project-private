import { api } from "@/api/client"; 

export async function askQuestion(question:string, assessmentId?:number|null){ 
  const {data}=await api.post('/chat/query',{question, assessment_id:assessmentId ?? undefined}); 
  return data;
}

export async function getChatHistory(assessmentId: number) {
  const { data } = await api.get<any[]>(`/chat/history?assessment_id=${assessmentId}`);
  return data;
}

export async function deleteChatHistory(assessmentId: number) {
  const { data } = await api.delete(`/chat/history?assessment_id=${assessmentId}`);
  return data;
}

export async function exportChatHistoryPdf(assessmentCode: string, history: any[]) {
  const { data } = await api.post('/chat/export-history-pdf', {
    assessment_code: assessmentCode,
    history
  }, { responseType: 'blob' });
  return data;
}

export async function compareAssessments(assessmentIdA: number, assessmentIdB: number) {
  const { data } = await api.post('/chat/compare', {
    assessment_id_a: assessmentIdA,
    assessment_id_b: assessmentIdB
  });
  return data;
}
