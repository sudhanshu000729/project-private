import { useState } from 'react'
import { Layout, Menu, Button, Space, Typography, Flex, Tooltip } from 'antd'
import {
  HomeOutlined,
  HistoryOutlined,
  OrderedListOutlined,
  CodeOutlined,
  FileExcelOutlined,
  MergeCellsOutlined,
  BranchesOutlined,
  DatabaseOutlined,
  FileTextOutlined,
  DownloadOutlined,
  RobotOutlined
} from '@ant-design/icons'
import HeaderBar from '@/components/HeaderBar'
import FooterBar from '@/components/FooterBar'
import StatusBanner from '@/components/StatusBanner'
import SATLogo from '@/components/SATLogo'
import { appContent } from '@/config/content'
import UploadSection from '@/features/analysis/UploadSection'
import AssessmentHistory from '@/features/history/AssessmentHistory'
import ReportsPanel from '@/features/reports/ReportsPanel'
import ChatPanel from '@/features/chat/ChatPanel'
import HeroImage from '@/assets/hero_custom.png'
import { useAssessmentStore } from '@/store/useAssessmentStore'
import DashboardModal from '@/components/DashboardModal'

export default function DashboardPage() {
  const activeSection = useAssessmentStore((s) => s.activeSection)
  const setActiveSection = useAssessmentStore((s) => s.setActiveSection)
  const dashboardOpen = useAssessmentStore((s) => s.dashboardOpen)
  const setDashboardOpen = useAssessmentStore((s) => s.setDashboardOpen)
  const status = useAssessmentStore((s) => s.status)
  const [collapsed, setCollapsed] = useState(false)

  const hasCompletedAssessment = status === 'completed'

  const menuItems = [
    { key: 'home', icon: <HomeOutlined />, label: 'Home' },
    { key: 'records', icon: <HistoryOutlined />, label: 'Assessments' },
    { key: 'wsdl', icon: <CodeOutlined />, label: 'WSDL Extracts' },
    { key: 'excel', icon: <FileExcelOutlined />, label: 'Excel Extracts' },
    { key: 'merged', icon: <MergeCellsOutlined />, label: 'Merged Output' },
    { key: 'dependencies', icon: <BranchesOutlined />, label: 'Dependencies' },
    { key: 'exports', icon: <DownloadOutlined />, label: 'Export Assessment' },
    { key: 'ai', icon: <RobotOutlined />, label: 'AI Assistant' },
    { key: 'storage', icon: <DatabaseOutlined />, label: 'Storage & Schema' },
    { key: 'logs', icon: <FileTextOutlined />, label: 'Logs' }
  ]

  return (
    <Layout className='app-shell' style={{ minHeight: '100vh' }}>
      <Layout.Sider 
        collapsible 
        collapsed={collapsed} 
        onCollapse={(value) => setCollapsed(value)}
        width={255}
        theme="dark"
        style={{
          overflow: 'auto',
          height: '100vh',
          position: 'fixed',
          left: 0,
          top: 0,
          bottom: 0,
          zIndex: 1000,
          background: '#0a0e19',
          borderRight: '1px solid var(--stroke)'
        }}
      >
        <div style={{ 
          padding: '24px 16px', 
          display: 'flex', 
          alignItems: 'center', 
          gap: 12, 
          justifyContent: collapsed ? 'center' : 'flex-start',
          borderBottom: '1px solid rgba(255, 255, 255, 0.05)'
        }}>
          <SATLogo />
          {!collapsed && (
            <span style={{ 
              color: '#fff', 
              fontSize: 16, 
              fontWeight: 800, 
              letterSpacing: 0.6,
              background: 'linear-gradient(135deg, #4b5dff 0%, #7a41ff 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              SAT SYSTEM
            </span>
          )}
        </div>
        <Menu 
          theme="dark" 
          mode="inline" 
          selectedKeys={[activeSection]} 
          onClick={({ key }) => setActiveSection(key)}
          items={menuItems}
          style={{ background: 'transparent', marginTop: 16 }}
        />
      </Layout.Sider>
      
      <Layout style={{ marginLeft: collapsed ? 80 : 255, transition: 'margin-left 0.2s ease', background: 'transparent' }}>
        <HeaderBar />
        
        <Layout.Content className='content-wrap' style={{ padding: '24px', minHeight: 'calc(100vh - 120px)' }}>
          <div style={{ marginBottom: 18 }}>
            <StatusBanner />
          </div>

          {activeSection === 'home' && (
            <Flex vertical gap={24}>
              <section id='hero-section' className='glass-card hero-card hero-section-xl fade-in' style={{ minHeight: 'auto', padding: 24 }}>
                <div className='hero-grid'>
                  <div className='hero-copy hero-copy-centered'>
                    <Space align='center'>
                      <SATLogo />
                      <Typography.Title level={2} style={{ margin: 0, color: 'var(--page-text)' }}>
                        {appContent.title}
                      </Typography.Title>
                    </Space>
                    <h1 className='hero-title'>{appContent.heroTitle}</h1>
                    <div className='hero-meta'>
                      <div className='hero-pill'>Repo path or single WSDL file</div>
                      <div className='hero-pill'>Upload WSDL/XSD folder</div>
                      <div className='hero-pill'>Hierarchical contract tree maps</div>
                      <div className='hero-pill'>Consolidated assessment comparison</div>
                    </div>
                    <Space style={{ marginTop: 22 }} wrap>
                      <Button type='primary' size='large' onClick={() => {
                        const target = document.getElementById('upload-card-anchor');
                        target?.scrollIntoView({ behavior: 'smooth' });
                      }}>
                        Get Started
                      </Button>
                      <Tooltip title={!hasCompletedAssessment ? "Please open and analyze an assessment first." : undefined}>
                        <span style={!hasCompletedAssessment ? { cursor: 'not-allowed' } : undefined}>
                          <Button 
                            size='large' 
                            onClick={() => setActiveSection('ai')}
                            disabled={!hasCompletedAssessment}
                            style={!hasCompletedAssessment ? { pointerEvents: 'none' } : undefined}
                          >
                            AI assistant
                          </Button>
                        </span>
                      </Tooltip>
                    </Space>
                  </div>
                  <div className='hero-visual hero-visual-centered'>
                    <img 
                      src={HeroImage} 
                      alt='Service Analyzer Tool illustration' 
                      style={{ width: '100%', maxWidth: 420, borderRadius: 24, objectFit: 'cover', boxShadow: '0 12px 40px rgba(0,0,0,0.15)' }} 
                    />
                  </div>
                </div>
              </section>
              
              <div id="upload-card-anchor">
                <UploadSection onOpenAI={() => setActiveSection('ai')} />
              </div>
            </Flex>
          )}

          {activeSection === 'records' && (
            <AssessmentHistory />
          )}

          {activeSection === 'ai' && (
            <ChatPanel />
          )}

          {!['home', 'records', 'ai'].includes(activeSection) && (
            <ReportsPanel />
          )}
        </Layout.Content>
        
        <FooterBar />
      </Layout>
      <DashboardModal open={dashboardOpen} onClose={() => setDashboardOpen(false)} />
    </Layout>
  )
}
