import { useEffect } from 'react'
import { ConfigProvider, theme } from 'antd'
import DashboardPage from '@/pages/DashboardPage'
import { darkTheme, lightTheme } from '@/config/content'
import { useAssessmentStore } from '@/store/useAssessmentStore'
import { useAssessmentPolling } from '@/hooks/useAssessmentPolling'
export default function App() {
  useAssessmentPolling(); const themeMode = useAssessmentStore((s) => s.themeMode); const isDark = themeMode === 'dark'
  useEffect(() => { document.documentElement.dataset.theme = themeMode; document.body.dataset.theme = themeMode }, [themeMode])
  return <ConfigProvider theme={{ algorithm: isDark ? theme.darkAlgorithm : theme.defaultAlgorithm, token: isDark ? darkTheme : lightTheme }}><DashboardPage /></ConfigProvider>
}
