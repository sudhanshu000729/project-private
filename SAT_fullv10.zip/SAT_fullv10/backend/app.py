from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from service_analyzer.config.settings import get_settings
from service_analyzer.db.database import Base, engine
from service_analyzer.api.routes import health, analysis, reports, history, chat
from service_analyzer.api.routes import db_browser
import uvicorn
settings = get_settings()
Base.metadata.create_all(bind=engine)
settings.export_dir_path.mkdir(parents=True, exist_ok=True)
settings.upload_dir_path.mkdir(parents=True, exist_ok=True)

app = FastAPI(title=settings.app_name, version='6.0.0')
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
app.mount('/exports', StaticFiles(directory=str(settings.export_dir_path.resolve())), name='exports')

app.include_router(health.router, prefix='/api/v1', tags=['health'])
app.include_router(analysis.router, prefix='/api/v1', tags=['analysis'])
app.include_router(reports.router, prefix='/api/v1', tags=['reports'])
app.include_router(history.router, prefix='/api/v1', tags=['history'])
app.include_router(chat.router, prefix='/api/v1', tags=['chat'])
app.include_router(db_browser.router, prefix='/api/v1', tags=['database'])


if __name__ == "__main__":
    uvicorn.run('app:app', reload=True)