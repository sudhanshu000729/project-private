import os
import sys
from pathlib import Path

# Add current path to sys.path so we can import service_analyzer
backend_dir = Path(__file__).parent.resolve()
sys.path.insert(0, str(backend_dir))

from service_analyzer.db.database import Base, engine
from service_analyzer.models import entities  # ensure models are imported to register with metadata

def run():
    print("Initializing/Migrating SQLite Database schema...")
    Base.metadata.create_all(bind=engine)
    print("Schema check/creation completed successfully.")

if __name__ == "__main__":
    run()
