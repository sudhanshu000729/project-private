import sys
from pathlib import Path

# Add backend directory to path
backend_path = Path("c:/Users/sudha/Desktop/AIML/SAT_fullv7/backend")
sys.path.insert(0, str(backend_path))

from sqlalchemy import select
from service_analyzer.db.session import SessionLocal
from service_analyzer.models.entities import Assessment, ExcelExtract, WSDLExtract, MergedReport, ExportArtifact
from service_analyzer.services.report_service import ReportService
from service_analyzer.services.export_service import generate_exports

def main():
    db = SessionLocal()
    try:
        assessments = db.scalars(select(Assessment).where(Assessment.status == 'completed')).all()
        if not assessments:
            print("No completed assessments found to regenerate.")
            return
            
        for assessment in assessments:
            assessment_id = assessment.id
            print(f"Regenerating exports for assessment: {assessment.assessment_code} (ID: {assessment_id})")
            
            # 1. service_summary
            report_svc = ReportService(db)
            summary = report_svc.service_summary(assessment_id)['items']
            
            # 2. excel_rows
            excel_extracts = db.scalars(select(ExcelExtract).where(ExcelExtract.assessment_id == assessment_id)).all()
            excel_rows = [{
                'service_name': x.service_name,
                'operation_name': x.operation_name,
                'upstream_apps': x.upstream_apps_json or [],
                'downstream_apps': x.downstream_apps_json or [],
                'data_sources': x.data_sources_json or []
            } for x in excel_extracts]
            
            # 3. wsdl_export_rows
            wsdl_extracts = db.scalars(select(WSDLExtract).where(
                WSDLExtract.assessment_id == assessment_id,
                WSDLExtract.direction == 'meta'
            )).all()
            wsdl_export_rows = []
            for w in wsdl_extracts:
                p = w.payload_json or {}
                req_row = db.scalar(select(WSDLExtract).where(
                    WSDLExtract.assessment_id == assessment_id,
                    WSDLExtract.service_name == w.service_name,
                    WSDLExtract.operation_name == w.operation_name,
                    WSDLExtract.direction == 'request'
                ))
                resp_row = db.scalar(select(WSDLExtract).where(
                    WSDLExtract.assessment_id == assessment_id,
                    WSDLExtract.service_name == w.service_name,
                    WSDLExtract.operation_name == w.operation_name,
                    WSDLExtract.direction == 'response'
                ))
                err_row = db.scalar(select(WSDLExtract).where(
                    WSDLExtract.assessment_id == assessment_id,
                    WSDLExtract.service_name == w.service_name,
                    WSDLExtract.operation_name == w.operation_name,
                    WSDLExtract.direction == 'error'
                ))
                
                from service_analyzer.services.merge_service import flatten_fields
                req_fields = flatten_fields(req_row.payload_json or [], []) if req_row else []
                resp_fields = flatten_fields(resp_row.payload_json or [], []) if resp_row else []
                err_fields = flatten_fields(err_row.payload_json or [], []) if err_row else []
                
                error_type = p.get('error_root_element') or ('Defined in WSDL' if p.get('payload_diagnostics', {}).get('fault_defined') else 'Not defined in WSDL')
                
                wsdl_export_rows.append({
                    'service_name': w.service_name,
                    'operation_name': w.operation_name,
                    'namespace': w.namespace,
                    'endpoint_url': w.endpoint_url,
                    'request_type_object': p.get('request_root_element') or 'Not defined in WSDL',
                    'request_fields_text': "\n".join([f"{x.get('name')} : {x.get('type')}" for x in req_fields]) or 'Not defined in WSDL',
                    'response_type_object': p.get('response_root_element') or 'Not defined in WSDL',
                    'response_fields_text': "\n".join([f"{x.get('name')} : {x.get('type')}" for x in resp_fields]) or 'Not defined in WSDL',
                    'error_type_object': error_type,
                    'error_fields_text': "\n".join([f"{x.get('name')} : {x.get('type')}" for x in err_fields]) or ('No error fields extracted' if error_type != 'Not defined in WSDL' else 'Not defined in WSDL')
                })
                
            # 4. merged_export_rows
            merged_reports = db.scalars(select(MergedReport).where(MergedReport.assessment_id == assessment_id)).all()
            merged_export_rows = []
            for r in merged_reports:
                w = r.wsdl_payload_json or {}
                merged_export_rows.append({
                    'excel_service_name': r.excel_service_name,
                    'excel_operation_name': r.excel_operation_name,
                    'wsdl_service_name': r.wsdl_service_name,
                    'wsdl_operation_name': r.wsdl_operation_name,
                    'upstream_apps': r.upstream_apps_json or [],
                    'downstream_apps': r.downstream_apps_json or [],
                    'data_sources': r.data_sources_json or [],
                    'namespace': r.namespace,
                    'endpoint_url': r.endpoint_url,
                    'port': r.port,
                    'binding': r.binding,
                    'soap_action': r.soap_action,
                    'request_type_object': w.get('request_type_object'),
                    'request_fields_text': w.get('request_fields_text'),
                    'response_type_object': w.get('response_type_object'),
                    'response_fields_text': w.get('response_fields_text'),
                    'error_type_object': w.get('error_type_object'),
                    'error_fields_text': w.get('error_fields_text'),
                    'matching_confidence': r.matching_confidence,
                    'matching_logic_used': r.matching_logic_used
                })
                
            # Delete old ExportArtifacts
            db.query(ExportArtifact).filter(ExportArtifact.assessment_id == assessment_id).delete()
            db.commit()
            
            # Generate exports
            generate_exports(db, assessment_id, assessment.assessment_code, summary, wsdl_export_rows, excel_rows, merged_export_rows)
            print(f"Successfully regenerated exports for {assessment.assessment_code}")
    finally:
        db.close()

if __name__ == "__main__":
    main()
