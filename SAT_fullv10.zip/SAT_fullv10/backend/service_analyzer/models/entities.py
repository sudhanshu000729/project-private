from datetime import datetime
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, Float
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.types import JSON
from service_analyzer.db.database import Base

class Assessment(Base):
    __tablename__ = 'assessments'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    assessment_code: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    status: Mapped[str] = mapped_column(String(30), index=True, default='queued')
    wsdl_path: Mapped[str] = mapped_column(String(700))
    excel_path: Mapped[str] = mapped_column(String(700))
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AssessmentLog(Base):
    __tablename__ = 'assessment_logs'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey('assessments.id', ondelete='CASCADE'), index=True)
    level: Mapped[str] = mapped_column(String(20), default='INFO')
    step: Mapped[str] = mapped_column(String(120))
    message: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AvailableService(Base):
    __tablename__ = 'available_services'
    service_name: Mapped[str] = mapped_column(String(255), primary_key=True)
    normalized_name: Mapped[str] = mapped_column(String(255), index=True)
    operations_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ServiceProperty(Base):
    __tablename__ = 'service_properties'
    __table_args__ = (UniqueConstraint('assessment_id', 'service_name', name='uq_assessment_service_property'),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey('assessments.id', ondelete='CASCADE'), index=True)
    service_name: Mapped[str] = mapped_column(ForeignKey('available_services.service_name', ondelete='CASCADE'), index=True)
    namespace: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    endpoint_url: Mapped[str | None] = mapped_column(String(1500), nullable=True)
    documentation: Mapped[str | None] = mapped_column(Text, nullable=True)
    bindings_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    ports_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    operations_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    request_fields_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    response_fields_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    error_fields_json: Mapped[list | None] = mapped_column(JSON, nullable=True)

class WSDLExtract(Base):
    __tablename__ = 'wsdl_extracts'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey('assessments.id', ondelete='CASCADE'), index=True)
    service_name: Mapped[str] = mapped_column(ForeignKey('available_services.service_name', ondelete='CASCADE'), index=True)
    operation_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    direction: Mapped[str | None] = mapped_column(String(20), nullable=True)
    payload_json: Mapped[dict | list | None] = mapped_column(JSON, nullable=True)
    
    # New visible fields
    root_element_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    namespace: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    binding: Mapped[str | None] = mapped_column(String(255), nullable=True)
    port: Mapped[str | None] = mapped_column(String(255), nullable=True)
    endpoint_url: Mapped[str | None] = mapped_column(String(1500), nullable=True)
    soap_action: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    diagnostics_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    type_hierarchy_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)

class ExcelExtract(Base):
    __tablename__ = 'excel_extracts'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey('assessments.id', ondelete='CASCADE'), index=True)
    service_name: Mapped[str] = mapped_column(String(255), index=True)
    operation_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    data_sources_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    upstream_apps_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    downstream_apps_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    raw_row_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)

class MergedReport(Base):
    __tablename__ = 'merged_reports'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey('assessments.id', ondelete='CASCADE'), index=True)
    service_name: Mapped[str] = mapped_column(ForeignKey('available_services.service_name', ondelete='CASCADE'), index=True)
    operation_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    merge_level: Mapped[str] = mapped_column(String(20), default='operation')
    wsdl_payload_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    excel_payload_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    merged_payload_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    # Excel Side visibility fields
    excel_service_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    excel_operation_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    data_sources_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    upstream_apps_json: Mapped[list | None] = mapped_column(JSON, nullable=True)
    downstream_apps_json: Mapped[list | None] = mapped_column(JSON, nullable=True)

    # WSDL Side visibility fields
    wsdl_service_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    wsdl_operation_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    endpoint_url: Mapped[str | None] = mapped_column(String(1500), nullable=True)
    port: Mapped[str | None] = mapped_column(String(255), nullable=True)
    binding: Mapped[str | None] = mapped_column(String(255), nullable=True)
    namespace: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    soap_action: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    request_structure_json: Mapped[list | dict | None] = mapped_column(JSON, nullable=True)
    response_structure_json: Mapped[list | dict | None] = mapped_column(JSON, nullable=True)
    error_structure_json: Mapped[list | dict | None] = mapped_column(JSON, nullable=True)

    # Matching Info fields
    matching_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    matching_logic_used: Mapped[str | None] = mapped_column(Text, nullable=True)

class ExportArtifact(Base):
    __tablename__ = 'export_artifacts'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey('assessments.id', ondelete='CASCADE'), index=True)
    file_type: Mapped[str] = mapped_column(String(20), index=True)
    artifact_kind: Mapped[str] = mapped_column(String(40), index=True)
    relative_path: Mapped[str] = mapped_column(String(600))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AssessmentChatSession(Base):
    __tablename__ = 'assessment_chat_sessions'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey('assessments.id', ondelete='CASCADE'), index=True, unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AssessmentChatMessage(Base):
    __tablename__ = 'assessment_chat_messages'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(ForeignKey('assessment_chat_sessions.id', ondelete='CASCADE'), index=True)
    role: Mapped[str] = mapped_column(String(50), default='user')
    message: Mapped[str] = mapped_column(Text)
    response: Mapped[str | None] = mapped_column(Text, nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    chat_metadata: Mapped[dict | list | None] = mapped_column("metadata", JSON, nullable=True)
