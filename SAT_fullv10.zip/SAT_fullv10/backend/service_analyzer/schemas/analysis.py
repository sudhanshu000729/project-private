from pydantic import BaseModel, Field

class AnalyzeRequest(BaseModel):
    wsdl_folder_path: str = Field(...)
    excel_file_path: str = Field(...)

class AssessmentStatusResponse(BaseModel):
    assessment_id: int
    assessment_code: str
    status: str
    message: str | None = None
    started_at: str | None = None
    finished_at: str | None = None
