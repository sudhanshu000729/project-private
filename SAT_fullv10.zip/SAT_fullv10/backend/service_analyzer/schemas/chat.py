from pydantic import BaseModel, Field
from typing import Any

class ChatQuestionRequest(BaseModel):
    question: str = Field(..., min_length=3)
    assessment_id: int | None = None
    max_services: int = Field(default=8, ge=1, le=25)

class AIDuplicateService(BaseModel):
    service_a: str = Field(description="Name of first service")
    service_b: str = Field(description="Name of second service")
    similarity_score: float = Field(description="Similarity score between 0.0 and 1.0")
    confidence_score: float = Field(description="Confidence score of duplicate detection between 0.0 and 1.0")
    details: str = Field(description="Details on why they are considered duplicates (e.g. same operations, similar endpoints)")
    recommendations: str = Field(description="Recommendations on how to merge or consolidate them")

class AISimilarSchema(BaseModel):
    service_a: str = Field(description="Service containing schema A")
    operation_a: str = Field(description="Operation containing schema A")
    direction_a: str = Field(description="Direction of schema A (request/response/error)")
    service_b: str = Field(description="Service containing schema B")
    operation_b: str = Field(description="Operation containing schema B")
    direction_b: str = Field(description="Direction of schema B (request/response/error)")
    similarity_score: float = Field(description="Similarity score between 0.0 and 1.0")
    confidence_score: float = Field(description="Confidence score between 0.0 and 1.0")
    details: str = Field(description="Details on schema similarity (e.g., similar field names and types)")
    recommendations: str = Field(description="Recommendations on consolidation or pattern reuse")

class AIPatternReuse(BaseModel):
    pattern_name: str = Field(description="Name or description of the reused pattern")
    description: str = Field(description="How the pattern is reused across services")
    reused_by: list[str] = Field(description="List of services or operations reusing this pattern")
    similarity_score: float = Field(description="Similarity score or uniformity score of the pattern between 0.0 and 1.0")
    confidence_score: float = Field(description="Confidence score of pattern detection")
    recommendations: str = Field(description="Recommendations to standardize or modularize the pattern")

class AIConsolidationRecommendation(BaseModel):
    category: str = Field(description="Category of recommendation (e.g. Duplication, Schema Standard, Endpoint Consolidation)")
    title: str = Field(description="Short title of the recommendation")
    details: str = Field(description="Detailed explanation of the recommendation")
    impact: str = Field(description="Expected impact of implementing the recommendation")
    effort: str = Field(description="Estimated effort (e.g., Low, Medium, High)")

class ChatAnswerResponse(BaseModel):
    answer: str
    used_assessment_id: int
    grounded_services: list[str] = []
    context_preview: list[dict] = []
    
    # New AI Assistant features
    duplicates: list[AIDuplicateService] = Field(default_factory=list)
    similar_schemas: list[AISimilarSchema] = Field(default_factory=list)
    pattern_reuse: list[AIPatternReuse] = Field(default_factory=list)
    recommendations: list[AIConsolidationRecommendation] = Field(default_factory=list)
    excel_download_url: str | None = None
    pdf_download_url: str | None = None
    stats: dict[str, Any] | None = None

class ExportHistoryPdfRequest(BaseModel):
    assessment_code: str
    history: list[dict]

class AssessmentCompareRequest(BaseModel):
    assessment_id_a: int
    assessment_id_b: int

class AssessmentCompareResponse(BaseModel):
    answer: str
    similarity_score: float
    confidence_score: float
    pdf_compare_url: str | None = None
    assessment_code_a: str | None = None
    assessment_code_b: str | None = None
    stats: dict[str, Any] | None = None
