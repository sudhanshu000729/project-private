from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class TableListResponse(BaseModel):
    tables: list[str]


class TableDataResponse(BaseModel):
    table_name: str
    page: int
    page_size: int
    total: int
    columns: list[str]
    rows: list[dict[str, Any]]


class RawQueryRequest(BaseModel):
    query: str = Field(..., description="Only single SELECT/WITH statements are allowed")
    params: dict[str, Any] | None = Field(default_factory=dict)
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=50, ge=1, le=200)


class RawQueryResponse(BaseModel):
    table_name: str
    page: int
    page_size: int
    total: int
    columns: list[str]
    rows: list[dict[str, Any]]