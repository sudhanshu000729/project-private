from __future__ import annotations
from pathlib import Path
from difflib import get_close_matches
from openpyxl import load_workbook

DIRECT_HEADERS = {
    'service name': 'service_name', 'service names': 'service_name', 'service': 'service_name',
    'operation name': 'operation_name', 'operation names': 'operation_name', 'operation': 'operation_name',
    'data source': 'data_sources', 'data sources': 'data_sources', 'datasource': 'data_sources',
    'downstream dependency': 'downstream_apps', 'downstream dependencies': 'downstream_apps', 'downstream dep': 'downstream_apps', 'downstream application': 'downstream_apps', 'downstream applications': 'downstream_apps',
    'upstream dep': 'upstream_apps', 'upstream dependency': 'upstream_apps', 'upstream dependencies': 'upstream_apps', 'upstream application': 'upstream_apps', 'upstream applications': 'upstream_apps',
}

def normalize_header(value: object) -> str:
    if value is None: return ''
    text = str(value).strip().lower()
    for ch in ['_', '-', '/', '\n', '\t']: text = text.replace(ch, ' ')
    return ' '.join(text.split())

def infer_header_key(header: object) -> str | None:
    header = normalize_header(header)
    if not header: return None
    if header in DIRECT_HEADERS: return DIRECT_HEADERS[header]
    close = get_close_matches(header, list(DIRECT_HEADERS.keys()), n=1, cutoff=0.83)
    if close: return DIRECT_HEADERS[close[0]]
    tokens = set(header.split())
    if 'service' in tokens and ('name' in tokens or len(tokens) == 1): return 'service_name'
    if 'operation' in tokens and ('name' in tokens or len(tokens) == 1): return 'operation_name'
    if ('data' in tokens and 'source' in tokens) or 'datasource' in header.replace(' ', ''): return 'data_sources'
    if 'downstream' in header: return 'downstream_apps'
    if 'upstream' in header: return 'upstream_apps'
    return None

def _split_csv(value):
    if value is None: return []
    return [x.strip() for x in str(value).split(',') if str(x).strip()]

def parse_analysis_excel(path: str | Path) -> list[dict]:
    p = Path(path)
    if not p.exists(): raise FileNotFoundError(f'Excel file not found: {p}')
    wb = load_workbook(filename=str(p), read_only=True, data_only=True)
    sheet = wb.active
    rows = sheet.iter_rows(values_only=True)
    header = next(rows, None)
    if not header: raise RuntimeError('Excel sheet has no header row.')
    mapped = [infer_header_key(h) for h in header]
    out = []
    for row in rows:
        payload = {}
        for idx, cell in enumerate(row):
            key = mapped[idx] if idx < len(mapped) else None
            if key: payload[key] = cell
        service_name = str(payload.get('service_name') or '').strip()
        if not service_name: continue
        out.append({'service_name': service_name, 'operation_name': str(payload.get('operation_name')).strip() if payload.get('operation_name') else None, 'data_sources': _split_csv(payload.get('data_sources')), 'upstream_apps': _split_csv(payload.get('upstream_apps')), 'downstream_apps': _split_csv(payload.get('downstream_apps')), 'raw_row': {normalize_header(header[idx]): (str(cell) if cell is not None else None) for idx, cell in enumerate(row) if idx < len(header)}})
    return out
