from __future__ import annotations

from pathlib import Path
import xml.etree.ElementTree as ET
from collections import defaultdict

from service_analyzer.config.settings import get_settings
from service_analyzer.utils.wsdl_rule_loader import load_wsdl_rules

settings = get_settings()
RULES = load_wsdl_rules()

NOT_DEFINED = RULES["not_defined_label"]
XSD_NS = "http://www.w3.org/2001/XMLSchema"

NS = {
    "wsdl": "http://schemas.xmlsoap.org/wsdl/",
    "soap": "http://schemas.xmlsoap.org/wsdl/soap/",
    "soap12": "http://schemas.xmlsoap.org/wsdl/soap12/",
    "xsd": XSD_NS,
    "xs": XSD_NS,
}


def _local(value: str | None) -> str:
    if not value:
        return ""
    if ":" in value:
        return value.split(":", 1)[1]
    if "}" in value:
        return value.split("}", 1)[1]
    return value


def _text(node: ET.Element | None) -> str | None:
    if node is None:
        return None
    text = "".join(node.itertext()).strip()
    return text or None


def _direct_children(parent: ET.Element, local_name: str):
    return [
        child for child in list(parent)
        if child.tag == f"{{{XSD_NS}}}{local_name}"
    ]


def _first_child(parent: ET.Element | None, local_name: str):
    if parent is None:
        return None
    for child in list(parent):
        if child.tag == f"{{{XSD_NS}}}{local_name}":
            return child
    return None


def _schema_nodes(wsdl_path: Path, root: ET.Element):
    schemas = [x for x in root.iter() if x.tag == f"{{{XSD_NS}}}schema"]

    if RULES["schema"]["imports"]:
        seen = set()

        for schema in list(schemas):
            for child in list(schema):
                if child.tag in {
                    f"{{{XSD_NS}}}import",
                    f"{{{XSD_NS}}}include",
                }:
                    loc = child.attrib.get("schemaLocation")
                    if not loc:
                        continue

                    xsd_path = (wsdl_path.parent / loc).resolve()

                    if not xsd_path.exists() or str(xsd_path) in seen:
                        continue

                    try:
                        xroot = ET.parse(xsd_path).getroot()
                        seen.add(str(xsd_path))
                        found = [
                            x for x in xroot.iter()
                            if x.tag == f"{{{XSD_NS}}}schema"
                        ]
                        schemas.extend(found or [xroot])
                    except Exception:
                        continue

    return schemas


def _build_type_maps(wsdl_path: Path, root: ET.Element):
    schemas = _schema_nodes(wsdl_path, root)

    complex_types = {}
    simple_types = {}
    elements = {}

    field_capture = set(RULES["field_capture"])

    def parse_simple(st: ET.Element):
        restriction = _first_child(st, "restriction")
        if restriction is None:
            return [], None

        enums = [
            e.attrib.get("value")
            for e in _direct_children(restriction, "enumeration")
            if e.attrib.get("value")
        ]

        restrictions = {"base": _local(restriction.attrib.get("base"))}

        for child in list(restriction):
            lname = _local(child.tag)
            if lname != "enumeration" and "value" in child.attrib:
                restrictions[lname] = child.attrib.get("value")

        return enums, restrictions

    def parse_element(elem: ET.Element, source_kind="sequence", inherited_name: str | None = None):
        item = {
            "children": [],
            "enumerations": [],
            "restrictions": None,
        }

        if "name" in field_capture:
            item["name"] = elem.attrib.get("name") or inherited_name

        if "type" in field_capture:
            item["type"] = _local(elem.attrib.get("type")) or None

        if "min_occurs" in field_capture:
            item["min_occurs"] = elem.attrib.get("minOccurs")

        if "max_occurs" in field_capture:
            item["max_occurs"] = elem.attrib.get("maxOccurs")

        if "nillable" in field_capture:
            item["nillable"] = elem.attrib.get("nillable")

        if "source_kind" in field_capture:
            item["source_kind"] = source_kind

        if "documentation" in field_capture:
            ann = _first_child(elem, "annotation")
            doc = _first_child(ann, "documentation") if ann is not None else None
            item["documentation"] = _text(doc)

        inline_complex = _first_child(elem, "complexType")
        if inline_complex is not None:
            item["children"] = parse_complex(inline_complex)
            item["type"] = item.get("type") or "anonymousComplexType"

        inline_simple = _first_child(elem, "simpleType")
        if inline_simple is not None:
            enums, restrictions = parse_simple(inline_simple)
            item["enumerations"] = enums
            item["restrictions"] = restrictions
            item["type"] = item.get("type") or "anonymousSimpleType"

        return item

    def parse_complex(ct: ET.Element):
        out = []

        for group_name in ["sequence", "choice", "all"]:
            if not RULES["schema"].get(group_name, True):
                continue

            holder = _first_child(ct, group_name)
            if holder is not None:
                for child in list(holder):
                    if child.tag == f"{{{XSD_NS}}}element":
                        out.append(parse_element(child, source_kind=group_name))

        return out

    for schema in schemas:
        for child in list(schema):
            if child.tag == f"{{{XSD_NS}}}simpleType" and child.attrib.get("name"):
                enums, restrictions = parse_simple(child)
                simple_types[child.attrib["name"]] = {
                    "enumerations": enums,
                    "restrictions": restrictions,
                }

            elif child.tag == f"{{{XSD_NS}}}complexType" and child.attrib.get("name"):
                complex_types[child.attrib["name"]] = parse_complex(child)

            elif child.tag == f"{{{XSD_NS}}}element" and child.attrib.get("name"):
                name = child.attrib["name"]
                info = parse_element(child, inherited_name=name)
                elements[name] = info

                # Inline complexType on the element
                if info["children"]:
                    complex_types[name] = info["children"]

                # Inline simpleType on the element
                if info["enumerations"]:
                    simple_types[name] = {
                        "enumerations": info["enumerations"],
                        "restrictions": info["restrictions"],
                    }

    return complex_types, simple_types, elements


def _expand_type(
    type_name: str,
    complex_types: dict,
    simple_types: dict,
    elements: dict,
    seen=None,
    depth=0,
):
    seen = set(seen or set())

    if not type_name or depth > settings.max_wsdl_depth:
        return []

    type_name = _local(type_name)

    if type_name in seen:
        return []

    seen.add(type_name)

    # Important fix:
    # If the seed is a global element, follow the element's declared type
    # when the element has no inline children.
    if type_name in elements:
        elem_info = elements[type_name]

        # Case 1: inline children exist directly on the element
        if elem_info.get("children"):
            return elem_info["children"]

        # Case 2: the element points to a named type -> expand that type
        declared_type = _local(elem_info.get("type"))
        if declared_type and declared_type != type_name:
            return _expand_type(
                declared_type,
                complex_types,
                simple_types,
                elements,
                seen=seen.copy(),
                depth=depth + 1,
            )

        # Case 3: if the element itself maps to a simple type/enumeration
        if type_name in simple_types:
            return [{
                "name": elem_info.get("name"),
                "type": declared_type or elem_info.get("type"),
                "children": [],
                "enumerations": simple_types[type_name].get("enumerations", []),
                "restrictions": simple_types[type_name].get("restrictions"),
                "min_occurs": elem_info.get("min_occurs"),
                "max_occurs": elem_info.get("max_occurs"),
                "nillable": elem_info.get("nillable"),
                "source_kind": elem_info.get("source_kind"),
                "documentation": elem_info.get("documentation"),
            }]

    out = []

    for field in complex_types.get(type_name, []):
        item = dict(field)
        child_type = item.get("type")

        if child_type in complex_types or child_type in elements:
            item["children"] = _expand_type(
                child_type,
                complex_types,
                simple_types,
                elements,
                seen=seen.copy(),
                depth=depth + 1,
            )

        if child_type in simple_types:
            item["enumerations"] = simple_types[child_type].get("enumerations", [])
            item["restrictions"] = simple_types[child_type].get("restrictions")

        out.append(item)

    return out


def parse_wsdl_file(path: Path) -> list[dict]:
    root = ET.parse(path).getroot()

    complex_types, simple_types, elements = _build_type_maps(path, root)

    message_parts = defaultdict(list)

    for message in root.findall(".//wsdl:message", NS):
        mname = message.attrib.get("name")
        for part in message.findall("wsdl:part", NS):
            message_parts[mname].append({
                "name": part.attrib.get("name"),
                "element": _local(part.attrib.get("element")),
                "type": _local(part.attrib.get("type")),
            })

    bindings = {}

    for binding in root.findall(".//wsdl:binding", NS):
        soap_binding = binding.find("soap:binding", NS)
        if soap_binding is None:
            soap_binding = binding.find("soap12:binding", NS)

        item = {
            "binding_name": binding.attrib.get("name"),
            "port_type": _local(binding.attrib.get("type")),
            "style": soap_binding.attrib.get("style") if soap_binding is not None else None,
            "transport": soap_binding.attrib.get("transport") if soap_binding is not None else None,
            "operations": {},
        }

        for op in binding.findall("wsdl:operation", NS):
            soap_op = op.find("soap:operation", NS)
            if soap_op is None:
                soap_op = op.find("soap12:operation", NS)

            inp = op.find("wsdl:input/soap:body", NS)
            if inp is None:
                inp = op.find("wsdl:input/soap12:body", NS)

            out = op.find("wsdl:output/soap:body", NS)
            if out is None:
                out = op.find("wsdl:output/soap12:body", NS)

            item["operations"][op.attrib.get("name")] = {
                "soap_action": soap_op.attrib.get("soapAction") if soap_op is not None else None,
                "input_use": inp.attrib.get("use") if inp is not None else None,
                "output_use": out.attrib.get("use") if out is not None else None,
            }

        bindings[binding.attrib.get("name")] = item

    port_types = {}

    for pt in root.findall(".//wsdl:portType", NS):
        rows = []

        for op in pt.findall("wsdl:operation", NS):
            input_node = op.find("wsdl:input", NS)
            output_node = op.find("wsdl:output", NS)

            input_message = _local(input_node.attrib.get("message") if input_node is not None else None)
            output_message = _local(output_node.attrib.get("message") if output_node is not None else None)

            request_root = response_root = error_root = None
            request_fields = []
            response_fields = []
            error_fields = []

            request_seen = {
                "message_found": bool(input_message),
                "seed_found": False,
                "type_expanded": False,
            }

            response_seen = {
                "message_found": bool(output_message),
                "seed_found": False,
                "type_expanded": False,
            }

            error_seen = {
                "message_found": False,
                "seed_found": False,
                "type_expanded": False,
            }

            fault_defined = False

            for part in message_parts.get(input_message, []):
                seed = part["element"] or part["type"]
                request_root = request_root or seed

                if seed:
                    request_seen["seed_found"] = True

                expanded = _expand_type(seed, complex_types, simple_types, elements)

                if expanded:
                    request_seen["type_expanded"] = True

                request_fields.extend(expanded)

            for part in message_parts.get(output_message, []):
                seed = part["element"] or part["type"]
                response_root = response_root or seed

                if seed:
                    response_seen["seed_found"] = True

                expanded = _expand_type(seed, complex_types, simple_types, elements)

                if expanded:
                    response_seen["type_expanded"] = True

                response_fields.extend(expanded)

            for fault in op.findall("wsdl:fault", NS):
                fault_defined = True
                fm = _local(fault.attrib.get("message"))
                if fm:
                    error_seen["message_found"] = True

                for part in message_parts.get(fm, []):
                    seed = part["element"] or part["type"]
                    error_root = error_root or seed

                    if seed:
                        error_seen["seed_found"] = True

                    expanded = _expand_type(seed, complex_types, simple_types, elements)

                    if expanded:
                        error_seen["type_expanded"] = True

                    error_fields.extend(expanded)

            # Compute explicit validation flags
            request_seen["present"] = bool(request_fields)
            request_seen["missing"] = not bool(input_message)
            request_seen["child_elements_missing"] = bool(input_message) and not bool(request_fields)
            request_seen["empty_node"] = bool(input_message) and len(request_fields) == 0
            request_seen["malformed"] = bool(input_message) and not request_seen["seed_found"]

            response_seen["present"] = bool(response_fields)
            response_seen["missing"] = not bool(output_message)
            response_seen["child_elements_missing"] = bool(output_message) and not bool(response_fields)
            response_seen["empty_node"] = bool(output_message) and len(response_fields) == 0
            response_seen["malformed"] = bool(output_message) and not response_seen["seed_found"]

            error_seen["present"] = bool(error_fields)
            error_seen["missing"] = not fault_defined
            error_seen["child_elements_missing"] = fault_defined and not bool(error_fields)
            error_seen["empty_node"] = fault_defined and len(error_fields) == 0
            error_seen["malformed"] = fault_defined and not error_seen["seed_found"]

            rows.append({
                "operation_name": op.attrib.get("name"),
                "documentation": _text(op.find("./wsdl:documentation", NS)),
                "input_message": input_message,
                "output_message": output_message,
                "request_root_element": request_root or NOT_DEFINED,
                "response_root_element": response_root or NOT_DEFINED,
                "error_root_element": error_root or ("Defined in WSDL" if fault_defined else NOT_DEFINED),
                "request_fields": request_fields,
                "response_fields": response_fields,
                "error_fields": error_fields,
                "payload_diagnostics": {
                    "request": request_seen,
                    "response": response_seen,
                    "error": error_seen,
                    "fault_defined": fault_defined,
                    "schema_namespace_detected": XSD_NS,
                },
            })

        port_types[pt.attrib.get("name")] = rows

    services = []

    for service in root.findall(".//wsdl:service", NS):
        ports = []
        svc_bindings = []
        operations = []

        endpoint_url = None
        service_doc = _text(service.find("./wsdl:documentation", NS))

        for port in service.findall("wsdl:port", NS):
            bname = _local(port.attrib.get("binding"))

            address = port.find("soap:address", NS)
            if address is None:
                address = port.find("soap12:address", NS)

            location = address.attrib.get("location") if address is not None else None
            endpoint_url = endpoint_url or location

            ports.append({
                "port_name": port.attrib.get("name"),
                "binding_name": bname,
                "location": location,
            })

            binding_info = bindings.get(
                bname,
                {
                    "binding_name": bname,
                    "port_type": None,
                    "operations": {},
                    "style": None,
                    "transport": None,
                },
            )

            svc_bindings.append(binding_info)

            for op in port_types.get(binding_info.get("port_type"), []):
                merged = dict(op)
                merged.update(binding_info["operations"].get(op["operation_name"], {}))
                merged["binding_name"] = bname
                merged["binding_style"] = binding_info.get("style")
                merged["transport"] = binding_info.get("transport")
                merged["service_documentation"] = service_doc
                operations.append(merged)

        service_name = service.attrib.get("name") or path.stem

        services.append({
            "service_name": service_name,
            "normalized_name": "".join(ch for ch in service_name.lower() if ch.isalnum()),
            "namespace": root.attrib.get("targetNamespace"),
            "endpoint_url": endpoint_url,
            "documentation": service_doc,
            "ports": ports,
            "bindings": svc_bindings,
            "operations": operations,
            "complex_types": complex_types,
            "simple_types": simple_types,
        })

    return services


def parse_wsdl_input(path_value: str | Path, cancel_check=None):
    p = Path(path_value)

    if not p.exists():
        raise FileNotFoundError(f"WSDL path not found: {p}")

    if p.is_file():
        if p.suffix.lower() != ".wsdl":
            raise FileNotFoundError(f"Only .wsdl files are supported for single-file input: {p}")

        if cancel_check and cancel_check():
            raise RuntimeError("Analysis cancelled")

        return parse_wsdl_file(p)

    if p.is_dir():
        merged = {}
        warnings = []
        files_seen = 0

        for fp in p.rglob("*.wsdl"):
            files_seen += 1

            if cancel_check and cancel_check():
                raise RuntimeError("Analysis cancelled")

            try:
                services = parse_wsdl_file(fp)
            except Exception as ex:
                warnings.append({"file": fp.name, "error": str(ex)})
                continue

            for svc in services:
                key = svc["normalized_name"]

                if key not in merged:
                    svc["warnings"] = []
                    merged[key] = svc
                else:
                    merged[key]["ports"].extend([x for x in svc["ports"] if x not in merged[key]["ports"]])
                    merged[key]["bindings"].extend([x for x in svc["bindings"] if x not in merged[key]["bindings"]])
                    merged[key]["operations"].extend([x for x in svc["operations"] if x not in merged[key]["operations"]])
                    merged[key]["endpoint_url"] = merged[key].get("endpoint_url") or svc.get("endpoint_url")
                    merged[key]["namespace"] = merged[key].get("namespace") or svc.get("namespace")

        if files_seen == 0:
            raise FileNotFoundError(f"No .wsdl files found under: {p}")

        if not merged:
            raise RuntimeError(f"No valid WSDLs parsed. Warnings: {warnings[:3]}")

        if warnings:
            next(iter(merged.values()))["warnings"].extend(warnings[:20])

        return list(merged.values())

    raise FileNotFoundError(f"Unsupported WSDL path: {p}")
