from functools import lru_cache
from pathlib import Path
import os
from typing import List
from dotenv import find_dotenv, load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

load_dotenv(find_dotenv(usecwd=True), override=False)


def resolve_api_key() -> str | None:
    return os.getenv('GOOGLE_API_KEY') or os.getenv('GEMINI_API_KEY')


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore')

    app_name: str = Field(default='Service Analyzer Tool', alias='APP_NAME')
    app_env: str = Field(default='dev', alias='APP_ENV')
    app_host: str = Field(default='0.0.0.0', alias='APP_HOST')
    app_port: int = Field(default=8000, alias='APP_PORT')
    cors_origins_raw: str = Field(default='http://localhost:5173,http://127.0.0.1:5173', alias='CORS_ORIGINS')
    database_url: str = Field(default='sqlite:///./service_analyzer.db', alias='DATABASE_URL')
    max_wsdl_depth: int = Field(default=8, alias='MAX_WSDL_DEPTH')
    export_dir: str = Field(default='exports', alias='EXPORT_DIR')
    upload_dir: str = Field(default='uploads', alias='UPLOAD_DIR')
    wsdl_rules_file: str = Field(default='service_analyzer/config/rules/wsdl_extraction_rules.xml', alias='WSDL_RULES_FILE')
    prompt_system_file: str = Field(default='service_analyzer/config/prompts/system_prompt.txt', alias='PROMPT_SYSTEM_FILE')
    prompt_assistant_file: str = Field(default='service_analyzer/config/prompts/assistant_guidance.txt', alias='PROMPT_ASSISTANT_FILE')
    llm_enabled: bool = Field(default=True, alias='LLM_ENABLED')
    google_api_key: str | None = Field(default=None, alias='GOOGLE_API_KEY')
    gemini_api_key: str | None = Field(default=None, alias='GEMINI_API_KEY')
    gemini_model: str = Field(default='gemini-3.1-flash-lite', alias='GEMINI_MODEL')
    gemini_temperature: float = Field(default=0.2, alias='GEMINI_TEMPERATURE')

    @property
    def base_dir(self) -> Path:
        return Path(__file__).resolve().parents[3]

    @property
    def cors_origins(self) -> List[str]:
        return [x.strip() for x in self.cors_origins_raw.split(',') if x.strip()]

    @property
    def export_dir_path(self) -> Path:
        p = Path(self.export_dir)
        return p if p.is_absolute() else self.base_dir / 'backend' / p

    @property
    def upload_dir_path(self) -> Path:
        p = Path(self.upload_dir)
        return p if p.is_absolute() else self.base_dir / 'backend' / p

    @property
    def wsdl_rules_path(self) -> Path:
        p = Path(self.wsdl_rules_file)
        return p if p.is_absolute() else self.base_dir / 'backend' / p

    @property
    def system_prompt_path(self) -> Path:
        p = Path(self.prompt_system_file)
        return p if p.is_absolute() else self.base_dir / 'backend' / p

    @property
    def assistant_prompt_path(self) -> Path:
        p = Path(self.prompt_assistant_file)
        return p if p.is_absolute() else self.base_dir / 'backend' / p

    @property
    def resolved_api_key(self) -> str | None:
        return resolve_api_key()


@lru_cache
def get_settings() -> Settings:
    return Settings()
