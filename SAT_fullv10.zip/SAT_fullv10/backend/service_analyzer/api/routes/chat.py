from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from service_analyzer.db.session import get_db
from service_analyzer.schemas.chat import (
    ChatAnswerResponse,
    ChatQuestionRequest,
    ExportHistoryPdfRequest,
    AssessmentCompareRequest,
    AssessmentCompareResponse
)
from service_analyzer.services.chat_service import ChatService, compile_history_pdf
from service_analyzer.config.settings import get_settings

router = APIRouter()

@router.post('/chat/query', response_model=ChatAnswerResponse)
def ask(payload: ChatQuestionRequest, db: Session = Depends(get_db)):
    try: return ChatAnswerResponse(**ChatService(db).ask(payload.question, payload.assessment_id, payload.max_services))
    except ValueError as ex: raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex: raise HTTPException(status_code=500, detail=str(ex))

@router.get('/chat/history')
def get_chat_history(assessment_id: int, db: Session = Depends(get_db)):
    try: return ChatService(db).get_history(assessment_id)
    except Exception as ex: raise HTTPException(status_code=500, detail=str(ex))

@router.delete('/chat/history')
def delete_chat_history(assessment_id: int, db: Session = Depends(get_db)):
    try:
        ChatService(db).clear_history(assessment_id)
        return {"status": "success"}
    except Exception as ex: raise HTTPException(status_code=500, detail=str(ex))

@router.post('/chat/compare', response_model=AssessmentCompareResponse)
def compare_assessments(payload: AssessmentCompareRequest, db: Session = Depends(get_db)):
    try: return AssessmentCompareResponse(**ChatService(db).compare(payload.assessment_id_a, payload.assessment_id_b))
    except ValueError as ex: raise HTTPException(status_code=404, detail=str(ex))
    except Exception as ex: raise HTTPException(status_code=500, detail=str(ex))

@router.post('/chat/export-history-pdf')
def export_history_pdf(payload: ExportHistoryPdfRequest):
    try:
        settings = get_settings()
        export_dir = settings.export_dir_path / f"assessment_{payload.assessment_code}"
        export_dir.mkdir(parents=True, exist_ok=True)
        pdf_path = export_dir / f"{payload.assessment_code}_Ai_Q_A.pdf"
        
        compile_history_pdf(payload.history, pdf_path, payload.assessment_code)
        
        return FileResponse(
            path=str(pdf_path),
            media_type='application/pdf',
            filename=f"{payload.assessment_code}_Ai_Q_A.pdf"
        )
    except Exception as ex:
        raise HTTPException(status_code=500, detail=str(ex))
