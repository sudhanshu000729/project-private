from pathlib import Path, PurePosixPath
import json

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session

from service_analyzer.db.session import get_db
from service_analyzer.jobs.manager import job_manager
from service_analyzer.schemas.analysis import AnalyzeRequest, AssessmentStatusResponse
from service_analyzer.schemas.common import MessageResponse
from service_analyzer.services.assessment_service import AssessmentService
from service_analyzer.config.settings import get_settings

settings = get_settings()
router = APIRouter()


@router.post('/analysis', response_model=AssessmentStatusResponse)
def start_analysis(payload: AnalyzeRequest, db: Session = Depends(get_db)):
    svc = AssessmentService(db)
    assessment = svc.create(payload.wsdl_folder_path, payload.excel_file_path)
    job_manager.start(assessment.id, payload.wsdl_folder_path, payload.excel_file_path)
    assessment = svc.get(assessment.id)
    return AssessmentStatusResponse(
        assessment_id=assessment.id,
        assessment_code=assessment.assessment_code,
        status=assessment.status,
        message=assessment.message,
        started_at=assessment.started_at.isoformat() if assessment.started_at else None,
        finished_at=assessment.finished_at.isoformat() if assessment.finished_at else None,
    )


@router.post('/analysis/upload', response_model=AssessmentStatusResponse)
async def upload_and_start_analysis(
    wsdl_files: list[UploadFile] = File(...),
    excel_file: UploadFile = File(...),
    wsdl_relative_paths: str | None = Form(default=None),
    db: Session = Depends(get_db),
):
    svc = AssessmentService(db)
    assessment = svc.create('uploaded', 'uploaded')
    code = assessment.assessment_code

    upload_dir = settings.upload_dir_path / f'assessment_{code}'
    wsdl_dir = upload_dir / 'wsdl'
    excel_dir = upload_dir / 'excel'

    wsdl_dir.mkdir(parents=True, exist_ok=True)
    excel_dir.mkdir(parents=True, exist_ok=True)

    relative_paths: list[str] = []

    if wsdl_relative_paths:
        try:
            parsed = json.loads(wsdl_relative_paths)
            if not isinstance(parsed, list):
                raise ValueError('wsdl_relative_paths must be a JSON array')
            relative_paths = [str(x) for x in parsed]
        except Exception:
            raise HTTPException(status_code=400, detail='Invalid wsdl_relative_paths payload')

    if relative_paths and len(relative_paths) != len(wsdl_files):
        raise HTTPException(
            status_code=400,
            detail='wsdl_relative_paths count must match wsdl_files count',
        )

    for idx, f in enumerate(wsdl_files):
        original_name = Path(f.filename or '').name.lower()

        if not (original_name.endswith('.wsdl') or original_name.endswith('.xsd')):
            raise HTTPException(
                status_code=400,
                detail=f'Only .wsdl and .xsd files are allowed. Got: {f.filename}',
            )

        rel_path = relative_paths[idx] if idx < len(relative_paths) else Path(f.filename).name

        # normalize path and block parent traversal
        safe_rel = PurePosixPath(rel_path)
        safe_parts = [part for part in safe_rel.parts if part not in ('', '.', '..')]
        safe_path = Path(*safe_parts) if safe_parts else Path(Path(f.filename).name)

        target = wsdl_dir / safe_path
        target.parent.mkdir(parents=True, exist_ok=True)

        data = await f.read()
        target.write_bytes(data)

    excel_name = Path(excel_file.filename or '').name.lower()
    if not (excel_name.endswith('.xlsx') or excel_name.endswith('.xls') or excel_name.endswith('.csv')):
        raise HTTPException(
            status_code=400,
            detail='Excel file must be .xlsx, .xls, or .csv',
        )

    excel_target = excel_dir / Path(excel_file.filename).name
    excel_target.write_bytes(await excel_file.read())

    assessment.wsdl_path = str(wsdl_dir)
    assessment.excel_path = str(excel_target)
    db.commit()
    db.refresh(assessment)

    job_manager.start(assessment.id, str(wsdl_dir), str(excel_target))

    return AssessmentStatusResponse(
        assessment_id=assessment.id,
        assessment_code=assessment.assessment_code,
        status=assessment.status,
        message=assessment.message,
        started_at=assessment.started_at.isoformat() if assessment.started_at else None,
        finished_at=assessment.finished_at.isoformat() if assessment.finished_at else None,
    )


@router.get('/analysis/{assessment_id}', response_model=AssessmentStatusResponse)
def get_status(assessment_id: int, db: Session = Depends(get_db)):
    row = AssessmentService(db).get(assessment_id)
    if not row:
        raise HTTPException(status_code=404, detail='Assessment not found')
    return AssessmentStatusResponse(
        assessment_id=row.id,
        assessment_code=row.assessment_code,
        status=row.status,
        message=row.message,
        started_at=row.started_at.isoformat() if row.started_at else None,
        finished_at=row.finished_at.isoformat() if row.finished_at else None,
    )


@router.post('/analysis/{assessment_id}/cancel', response_model=MessageResponse)
def cancel(assessment_id: int, db: Session = Depends(get_db)):
    svc = AssessmentService(db)
    row = svc.get(assessment_id)

    if not row:
        raise HTTPException(status_code=404, detail='Assessment not found')

    if row.status != 'running':
        raise HTTPException(
            status_code=400,
            detail=f'Cancel is only allowed while running. Current status: {row.status}',
        )

    job_manager.cancel(assessment_id)
    svc.set_status(assessment_id, 'cancelled', 'Cancellation requested by user.')
    return MessageResponse(message='Cancellation requested')
import json

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session

from service_analyzer.db.session import get_db
from service_analyzer.jobs.manager import job_manager
from service_analyzer.schemas.analysis import AnalyzeRequest, AssessmentStatusResponse
from service_analyzer.schemas.common import MessageResponse
from service_analyzer.services.assessment_service import AssessmentService
