from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from service_analyzer.db.session import get_db
from service_analyzer.schemas.common import MessageResponse
from service_analyzer.services.report_service import ReportService
from service_analyzer.services.assessment_service import AssessmentService
router = APIRouter()
@router.get('/history/assessments')
def assessments(db: Session = Depends(get_db)): return ReportService(db).assessments()
@router.get('/history/assessments/{assessment_id}/logs')
def logs(assessment_id: int, db: Session = Depends(get_db)): return ReportService(db).logs(assessment_id)
@router.delete('/history/assessments/{assessment_id}', response_model=MessageResponse)
def delete_assessment(assessment_id: int, db: Session = Depends(get_db)):
    ok = AssessmentService(db).delete(assessment_id)
    if not ok: raise HTTPException(status_code=404, detail='Assessment not found')
    return MessageResponse(message='Assessment deleted')
