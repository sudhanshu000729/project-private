from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from service_analyzer.db.session import get_db
from service_analyzer.services.report_service import ReportService
router = APIRouter()
def _wrap(fn):
    try: return fn()
    except ValueError as ex: raise HTTPException(status_code=404, detail=str(ex))
@router.get('/reports/service-summary')
def service_summary(assessment_id: int | None = Query(default=None), db: Session = Depends(get_db)): return _wrap(lambda: ReportService(db).service_summary(assessment_id))
@router.get('/reports/raw-extracts')
def raw_extracts(assessment_id: int, db: Session = Depends(get_db)): return _wrap(lambda: ReportService(db).raw_extracts(assessment_id))
@router.get('/reports/wsdl-extract-grouped')
def wsdl_extract_grouped(assessment_id: int, db: Session = Depends(get_db)): return _wrap(lambda: ReportService(db).grouped_wsdl_extracts(assessment_id))
@router.get('/reports/service-dependency')
def service_dependency(assessment_id: int | None = Query(default=None), db: Session = Depends(get_db)): return _wrap(lambda: ReportService(db).service_dependency(assessment_id))
@router.get('/reports/data-source-dependency')
def data_source_dependency(assessment_id: int | None = Query(default=None), db: Session = Depends(get_db)): return _wrap(lambda: ReportService(db).data_source_dependency(assessment_id))
@router.get('/reports/structure-summary')
def structure_summary(assessment_id: int, db: Session = Depends(get_db)): return _wrap(lambda: ReportService(db).structure_summary(assessment_id))
@router.get('/reports/structure-detail')
def structure_detail(assessment_id: int, service_name: str | None = Query(default=None), operation_name: str | None = Query(default=None), db: Session = Depends(get_db)): return _wrap(lambda: ReportService(db).structure_detail(assessment_id, service_name, operation_name))
@router.get('/reports/exports')
def exports(assessment_id: int, db: Session = Depends(get_db)): return _wrap(lambda: ReportService(db).exports(assessment_id))
