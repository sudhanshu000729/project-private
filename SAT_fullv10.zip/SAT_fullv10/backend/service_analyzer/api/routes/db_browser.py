from __future__ import annotations

import re
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.encoders import jsonable_encoder
from sqlalchemy import MetaData, Table, func, inspect, select, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from service_analyzer.db.session import get_db
from service_analyzer.schemas.db_browser import (
    RawQueryRequest,
    RawQueryResponse,
    TableDataResponse,
    TableListResponse,
)

router = APIRouter(prefix="/db", tags=["DB Browser"])

# Only allow read-only SQL
READ_ONLY_STARTERS = ("select", "with")
FORBIDDEN_SQL_PATTERN = re.compile(
    r"\b(insert|update|delete|drop|alter|create|replace|truncate|attach|detach|pragma|vacuum|reindex)\b",
    re.IGNORECASE,
)


def _get_table_names(db: Session) -> list[str]:
    engine = db.get_bind()
    inspector = inspect(engine)
    return sorted(inspector.get_table_names())


def _ensure_table_exists(db: Session, table_name: str) -> None:
    tables = _get_table_names(db)
    if table_name not in tables:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not found")


def _reflect_table(db: Session, table_name: str) -> Table:
    engine = db.get_bind()
    metadata = MetaData()
    return Table(table_name, metadata, autoload_with=engine)


def _validate_read_only_query(query: str, table_name: str) -> str:
    q = query.strip().rstrip(";")

    if not q:
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    # Allow only a single statement
    if ";" in q:
        raise HTTPException(status_code=400, detail="Only a single SQL statement is allowed")

    lowered = q.lower().lstrip()
    if not lowered.startswith(READ_ONLY_STARTERS):
        raise HTTPException(
            status_code=400,
            detail="Only SELECT/WITH queries are allowed",
        )

    if FORBIDDEN_SQL_PATTERN.search(q):
        raise HTTPException(
            status_code=400,
            detail="Only read-only queries are allowed",
        )

    # Make sure the query targets the requested table
    # This checks common cases like FROM table_name / JOIN table_name
    # It is intentionally simple and restrictive.
    table_pattern = re.compile(
        rf"\b(from|join)\s+[`\"]?{re.escape(table_name)}[`\"]?\b",
        re.IGNORECASE,
    )
    if not table_pattern.search(q):
        raise HTTPException(
            status_code=400,
            detail=f"Query must reference table '{table_name}'",
        )

    return q


@router.get("/tables", response_model=TableListResponse)
def list_tables(db: Session = Depends(get_db)):
    return TableListResponse(tables=_get_table_names(db))


@router.get("/tables/{table_name}", response_model=TableDataResponse)
def get_table_data(
    table_name: str,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    _ensure_table_exists(db, table_name)

    try:
        table = _reflect_table(db, table_name)

        total_stmt = select(func.count()).select_from(table)
        total = db.execute(total_stmt).scalar_one()

        offset = (page - 1) * page_size
        data_stmt = select(table).limit(page_size).offset(offset)
        result = db.execute(data_stmt)

        rows = [dict(row._mapping) for row in result.fetchall()]
        columns = list(table.columns.keys())

        return TableDataResponse(
            table_name=table_name,
            page=page,
            page_size=page_size,
            total=total,
            columns=columns,
            rows=jsonable_encoder(rows),
        )

    except SQLAlchemyError as e:
        raise HTTPException(status_code=500, detail=f"Failed to read table: {str(e)}")


@router.post("/tables/{table_name}/query", response_model=RawQueryResponse)
def run_raw_query_on_table(
    table_name: str,
    payload: RawQueryRequest,
    db: Session = Depends(get_db),
):
    _ensure_table_exists(db, table_name)

    query = _validate_read_only_query(payload.query, table_name)

    try:
        base_params: dict[str, Any] = payload.params or {}
        offset = (payload.page - 1) * payload.page_size

        # Count total rows from the user's query
        count_sql = text(f"SELECT COUNT(*) AS total FROM ({query}) AS subq")
        total = db.execute(count_sql, base_params).scalar_one()

        # Apply pagination outside the user query
        paged_sql = text(
            f"SELECT * FROM ({query}) AS subq LIMIT :__limit OFFSET :__offset"
        )
        exec_params = {
            **base_params,
            "__limit": payload.page_size,
            "__offset": offset,
        }

        result = db.execute(paged_sql, exec_params)
        columns = list(result.keys())
        rows = [dict(row._mapping) for row in result.fetchall()]

        return RawQueryResponse(
            table_name=table_name,
            page=payload.page,
            page_size=payload.page_size,
            total=total,
            columns=columns,
            rows=jsonable_encoder(rows),
        )

    except SQLAlchemyError as e:
        raise HTTPException(status_code=400, detail=f"Query failed: {str(e)}")


def _validate_generic_read_only_query(query: str) -> str:
    q = query.strip().rstrip(";")

    if not q:
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    if ";" in q:
        raise HTTPException(status_code=400, detail="Only a single SQL statement is allowed")

    lowered = q.lower().lstrip()
    if not lowered.startswith(READ_ONLY_STARTERS):
        raise HTTPException(
            status_code=400,
            detail="Only SELECT/WITH queries are allowed",
        )

    if FORBIDDEN_SQL_PATTERN.search(q):
        raise HTTPException(
            status_code=400,
            detail="Only read-only queries are allowed",
        )

    return q


@router.post("/query", response_model=RawQueryResponse)
def run_generic_query(
    payload: RawQueryRequest,
    db: Session = Depends(get_db),
):
    query = _validate_generic_read_only_query(payload.query)

    try:
        base_params: dict[str, Any] = payload.params or {}
        offset = (payload.page - 1) * payload.page_size

        # Count total rows from the user's query
        count_sql = text(f"SELECT COUNT(*) AS total FROM ({query}) AS subq")
        total = db.execute(count_sql, base_params).scalar_one()

        # Apply pagination outside the user query
        paged_sql = text(
            f"SELECT * FROM ({query}) AS subq LIMIT :__limit OFFSET :__offset"
        )
        exec_params = {
            **base_params,
            "__limit": payload.page_size,
            "__offset": offset,
        }

        result = db.execute(paged_sql, exec_params)
        columns = list(result.keys())
        rows = [dict(row._mapping) for row in result.fetchall()]

        return RawQueryResponse(
            table_name="raw_query",
            page=payload.page,
            page_size=payload.page_size,
            total=total,
            columns=columns,
            rows=jsonable_encoder(rows),
        )

    except SQLAlchemyError as e:
        raise HTTPException(status_code=400, detail=f"Query failed: {str(e)}")


@router.get("/schema")
def get_db_schema(db: Session = Depends(get_db)):
    try:
        engine = db.get_bind()
        inspector = inspect(engine)
        tables = {}
        for table_name in sorted(inspector.get_table_names()):
            columns = []
            for col in inspector.get_columns(table_name):
                columns.append({
                    "name": col["name"],
                    "type": str(col["type"]),
                    "nullable": col["nullable"],
                    "default": str(col["default"]) if col.get("default") is not None else None,
                    "primary_key": bool(col.get("primary_key", False))
                })
            
            fks = []
            for fk in inspector.get_foreign_keys(table_name):
                fks.append({
                    "constrained_columns": fk["constrained_columns"],
                    "referred_table": fk["referred_table"],
                    "referred_columns": fk["referred_columns"]
                })
                
            indexes = []
            for idx in inspector.get_indexes(table_name):
                indexes.append({
                    "name": idx["name"],
                    "column_names": idx["column_names"],
                    "unique": idx["unique"]
                })
                
            tables[table_name] = {
                "columns": columns,
                "foreign_keys": fks,
                "indexes": indexes
            }
        return {"tables": tables}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to extract schema: {str(e)}")
