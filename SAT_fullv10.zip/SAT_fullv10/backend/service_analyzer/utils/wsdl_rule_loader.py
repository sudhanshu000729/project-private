import xml.etree.ElementTree as ET
from service_analyzer.config.settings import get_settings
settings = get_settings()

def load_wsdl_rules() -> dict:
    root = ET.parse(settings.wsdl_rules_path).getroot()
    data = {'service_capture': [], 'binding_capture': [], 'operation_capture': [], 'field_capture': [], 'schema': {'sequence': True, 'choice': True, 'all': True, 'imports': True}, 'not_defined_label': 'Not defined in WSDL'}
    for node in root.findall('./service/capture'): data['service_capture'].append(node.attrib.get('field'))
    for node in root.findall('./binding/capture'): data['binding_capture'].append(node.attrib.get('field'))
    for node in root.findall('./operation/capture'): data['operation_capture'].append(node.attrib.get('field'))
    for node in root.findall('./field/capture'): data['field_capture'].append(node.attrib.get('field'))
    schema = root.find('./schema')
    if schema is not None:
        data['schema'] = {'sequence': schema.attrib.get('sequence', 'true').lower() == 'true', 'choice': schema.attrib.get('choice', 'true').lower() == 'true', 'all': schema.attrib.get('all', 'true').lower() == 'true', 'imports': schema.attrib.get('imports', 'true').lower() == 'true'}
    behavior = root.find('./behavior')
    if behavior is not None: data['not_defined_label'] = behavior.attrib.get('notDefinedLabel', 'Not defined in WSDL')
    return data
