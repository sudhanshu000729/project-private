from collections import defaultdict
from service_analyzer.utils.wsdl_rule_loader import load_wsdl_rules
RULES = load_wsdl_rules(); NOT_DEFINED = RULES['not_defined_label']

def normalize_name(value: str | None) -> str: return ''.join(ch for ch in (value or '').lower() if ch.isalnum())

def flatten_fields(fields, out=None):
    out = out or []
    for field in fields or []:
        out.append({'name': field.get('name'), 'type': field.get('type'), 'min_occurs': field.get('min_occurs'), 'max_occurs': field.get('max_occurs'), 'source_kind': field.get('source_kind'), 'enumerations': field.get('enumerations', []), 'restrictions': field.get('restrictions')})
        flatten_fields(field.get('children', []), out)
    return out

def compact_field_text(fields):
    rows = flatten_fields(fields, [])
    return chr(10).join([f"{x.get('name')} : {x.get('type')}" for x in rows]) or NOT_DEFINED

def merge_service_and_operation(wsdl_services: list[dict], excel_rows: list[dict]) -> list[dict]:
    by_service = defaultdict(list); by_service_op = defaultdict(list)
    for row in excel_rows:
        s = normalize_name(row.get('service_name')); o = normalize_name(row.get('operation_name')); by_service[s].append(row); by_service_op[(s,o)].append(row)
    output = []
    for svc in wsdl_services:
        svc_key = normalize_name(svc.get('service_name')); svc_rows = by_service.get(svc_key, [])
        for op in svc.get('operations', []):
            op_key = normalize_name(op.get('operation_name'))
            matches = by_service_op.get((svc_key, op_key), [])
            
            if matches:
                excel_payload = matches[0]
                matching_confidence = 1.0
                matching_logic_used = "Exact Match (Service Name & Operation Name)"
            elif svc_rows:
                excel_payload = svc_rows[0]
                matching_confidence = 0.5
                matching_logic_used = f"Service-only Match Fallback (Matched service '{svc['service_name']}', fallback to first Excel row)"
            else:
                excel_payload = None
                matching_confidence = 0.0
                matching_logic_used = "No Match (No Excel metadata found)"
                
            error_type = op.get('error_root_element') or ('Defined in WSDL' if op.get('payload_diagnostics', {}).get('fault_defined') else NOT_DEFINED)
            
            # Find associated port
            associated_port = None
            op_binding = op.get('binding_name')
            for p_info in svc.get('ports', []):
                if p_info.get('binding_name') == op_binding:
                    associated_port = p_info.get('port_name')
                    break
            if not associated_port and svc.get('ports'):
                associated_port = svc.get('ports')[0].get('port_name')

            output.append({
                'service_name': svc['service_name'],
                'operation_name': op.get('operation_name'),
                'merge_level': 'operation',
                'wsdl_payload': {
                    'namespace': svc.get('namespace'),
                    'endpoint_url': svc.get('endpoint_url'),
                    'documentation': op.get('documentation'),
                    'ports': svc.get('ports', []),
                    'bindings': svc.get('bindings', []),
                    'binding_name': op.get('binding_name'),
                    'binding_style': op.get('binding_style'),
                    'transport': op.get('transport'),
                    'soap_action': op.get('soap_action'),
                    'input_use': op.get('input_use'),
                    'output_use': op.get('output_use'),
                    'request_type_object': op.get('request_root_element') or NOT_DEFINED,
                    'request_fields_text': compact_field_text(op.get('request_fields', [])),
                    'response_type_object': op.get('response_root_element') or NOT_DEFINED,
                    'response_fields_text': compact_field_text(op.get('response_fields', [])),
                    'error_type_object': error_type,
                    'error_fields_text': compact_field_text(op.get('error_fields', [])),
                    'request_fields': flatten_fields(op.get('request_fields', []), []),
                    'response_fields': flatten_fields(op.get('response_fields', []), []),
                    'error_fields': flatten_fields(op.get('error_fields', []), []),
                    'payload_diagnostics': op.get('payload_diagnostics', {})
                },
                'excel_payload': excel_payload,
                'merged_payload': {
                    'data_sources': excel_payload.get('data_sources', []) if excel_payload else [],
                    'upstream_apps': excel_payload.get('upstream_apps', []) if excel_payload else [],
                    'downstream_apps': excel_payload.get('downstream_apps', []) if excel_payload else []
                },
                # Detailed visible columns
                'excel_service_name': excel_payload.get('service_name') if excel_payload else None,
                'excel_operation_name': excel_payload.get('operation_name') if excel_payload else None,
                'data_sources': excel_payload.get('data_sources', []) if excel_payload else [],
                'upstream_apps': excel_payload.get('upstream_apps', []) if excel_payload else [],
                'downstream_apps': excel_payload.get('downstream_apps', []) if excel_payload else [],
                'wsdl_service_name': svc['service_name'],
                'wsdl_operation_name': op.get('operation_name'),
                'endpoint_url': svc.get('endpoint_url'),
                'port': associated_port,
                'binding': op.get('binding_name'),
                'namespace': svc.get('namespace'),
                'soap_action': op.get('soap_action'),
                'request_structure': op.get('request_fields', []),
                'response_structure': op.get('response_fields', []),
                'error_structure': op.get('error_fields', []),
                'matching_confidence': matching_confidence,
                'matching_logic_used': matching_logic_used
            })
    return output
