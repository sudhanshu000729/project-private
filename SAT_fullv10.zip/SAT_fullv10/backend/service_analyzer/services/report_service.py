from collections import defaultdict
from sqlalchemy import desc, select, func
from sqlalchemy.orm import Session
from service_analyzer.models.entities import Assessment, AssessmentLog, ExportArtifact, ExcelExtract, MergedReport, ServiceProperty, WSDLExtract, AvailableService

class ReportService:
    def __init__(self, db: Session): self.db = db
    def _resolve_id(self, assessment_id: int | None) -> int:
        if assessment_id: return assessment_id
        row = self.db.scalar(select(Assessment).where(Assessment.status == 'completed').order_by(desc(Assessment.finished_at), desc(Assessment.id)).limit(1))
        if not row: raise ValueError('No completed assessments found.')
        return row.id
    def service_summary(self, assessment_id: int | None = None):
        aid = self._resolve_id(assessment_id); rows = list(self.db.scalars(select(ServiceProperty).where(ServiceProperty.assessment_id == aid).order_by(ServiceProperty.service_name)).all())
        return {'assessment_id': aid, 'items': [{'service_name': r.service_name, 'namespace': r.namespace, 'endpoint_url': r.endpoint_url, 'documentation': r.documentation, 'bindings': r.bindings_json or [], 'ports': r.ports_json or [], 'operations': r.operations_json or [], 'request_fields': r.request_fields_json or [], 'response_fields': r.response_fields_json or [], 'error_fields': r.error_fields_json or []} for r in rows]}
    def raw_extracts(self, assessment_id: int):
        wsdl_rows = list(self.db.scalars(select(WSDLExtract).where(WSDLExtract.assessment_id == assessment_id).order_by(WSDLExtract.id)).all())
        excel_rows = list(self.db.scalars(select(ExcelExtract).where(ExcelExtract.assessment_id == assessment_id).order_by(ExcelExtract.id)).all())
        merged_rows = list(self.db.scalars(select(MergedReport).where(MergedReport.assessment_id == assessment_id).order_by(MergedReport.id)).all())
        return {
            'assessment_id': assessment_id,
            'wsdl_items': [{'service_name': x.service_name, 'operation_name': x.operation_name, 'direction': x.direction, 'payload': x.payload_json} for x in wsdl_rows],
            'excel_items': [{'service_name': x.service_name, 'operation_name': x.operation_name, 'data_sources': x.data_sources_json or [], 'upstream_apps': x.upstream_apps_json or [], 'downstream_apps': x.downstream_apps_json or [], 'raw_row': x.raw_row_json} for x in excel_rows],
            'merged_items': [
                {
                    'service_name': x.service_name,
                    'operation_name': x.operation_name,
                    'merge_level': x.merge_level,
                    'wsdl_payload': x.wsdl_payload_json,
                    'excel_payload': x.excel_payload_json,
                    'merged_payload': x.merged_payload_json,
                    'excel_service_name': x.excel_service_name,
                    'excel_operation_name': x.excel_operation_name,
                    'data_sources_json': x.data_sources_json,
                    'upstream_apps_json': x.upstream_apps_json,
                    'downstream_apps_json': x.downstream_apps_json,
                    'wsdl_service_name': x.wsdl_service_name,
                    'wsdl_operation_name': x.wsdl_operation_name,
                    'endpoint_url': x.endpoint_url,
                    'port': x.port,
                    'binding': x.binding,
                    'namespace': x.namespace,
                    'soap_action': x.soap_action,
                    'request_structure_json': x.request_structure_json,
                    'response_structure_json': x.response_structure_json,
                    'error_structure_json': x.error_structure_json,
                    'matching_confidence': x.matching_confidence,
                    'matching_logic_used': x.matching_logic_used,
                } for x in merged_rows
            ]
        }
    def grouped_wsdl_extracts(self, assessment_id: int):
        rows = list(self.db.scalars(select(WSDLExtract).where(WSDLExtract.assessment_id == assessment_id).order_by(WSDLExtract.service_name, WSDLExtract.operation_name, WSDLExtract.id)).all())
        groups = defaultdict(lambda: {'service_name': None, 'operation_name': None, 'directions': {}, 'available': [], 'diagnostics': {}})
        for row in rows:
            key = (row.service_name, row.operation_name or '')
            g = groups[key]; g['service_name'] = row.service_name; g['operation_name'] = row.operation_name
            g['directions'][row.direction or 'unknown'] = row.payload_json if row.payload_json not in (None, [], {}) else {'empty': True, 'message': 'No fields extracted for this direction. That may mean the direction is not defined in WSDL or the schema type could not be expanded.'}
            g['diagnostics'][row.direction or 'unknown'] = row.diagnostics_json or {}
            g['available'] = sorted(list(set(g['available'] + [row.direction or 'unknown'])))
        return {'assessment_id': assessment_id, 'items': list(groups.values())}
    def service_dependency(self, assessment_id: int | None = None):
        aid = self._resolve_id(assessment_id); rows = list(self.db.scalars(select(MergedReport).where(MergedReport.assessment_id == aid)).all()); edges = []
        for row in rows:
            merged = row.merged_payload_json or {}
            for target in merged.get('downstream_apps', []) or []: edges.append({'source': row.service_name, 'target': target, 'type': 'service'})
            for source in merged.get('upstream_apps', []) or []: edges.append({'source': source, 'target': row.service_name, 'type': 'consumer'})
        return {'assessment_id': aid, 'items': edges}
    def data_source_dependency(self, assessment_id: int | None = None):
        aid = self._resolve_id(assessment_id); rows = list(self.db.scalars(select(MergedReport).where(MergedReport.assessment_id == aid)).all()); edges = []
        for row in rows:
            for ds in (row.merged_payload_json or {}).get('data_sources', []) or []: edges.append({'source': ds, 'target': row.service_name, 'type': 'data_source'})
        return {'assessment_id': aid, 'items': edges}
    def structure_summary(self, assessment_id: int):
        assessment = self.db.get(Assessment, assessment_id)
        if not assessment: raise ValueError('Assessment not found')
        counts = {'assessments': self.db.scalar(select(func.count()).select_from(Assessment)) or 0, 'assessment_logs': self.db.scalar(select(func.count()).select_from(AssessmentLog).where(AssessmentLog.assessment_id == assessment_id)) or 0, 'available_services': self.db.scalar(select(func.count()).select_from(AvailableService)) or 0, 'service_properties': self.db.scalar(select(func.count()).select_from(ServiceProperty).where(ServiceProperty.assessment_id == assessment_id)) or 0, 'wsdl_extracts': self.db.scalar(select(func.count()).select_from(WSDLExtract).where(WSDLExtract.assessment_id == assessment_id)) or 0, 'excel_extracts': self.db.scalar(select(func.count()).select_from(ExcelExtract).where(ExcelExtract.assessment_id == assessment_id)) or 0, 'merged_reports': self.db.scalar(select(func.count()).select_from(MergedReport).where(MergedReport.assessment_id == assessment_id)) or 0, 'export_artifacts': self.db.scalar(select(func.count()).select_from(ExportArtifact).where(ExportArtifact.assessment_id == assessment_id)) or 0}
        tables = [
            {'table_name':'assessments','purpose':'One parent row per run','assessment_scoped':False,'row_count':counts['assessments']},
            {'table_name':'assessment_logs','purpose':'Step-by-step execution logs','assessment_scoped':True,'row_count':counts['assessment_logs']},
            {'table_name':'available_services','purpose':'Master service catalogue references','assessment_scoped':False,'row_count':counts['available_services']},
            {'table_name':'service_properties','purpose':'Service-level contract snapshot','assessment_scoped':True,'row_count':counts['service_properties']},
            {'table_name':'wsdl_extracts','purpose':'Raw WSDL request/response/error/meta payload rows','assessment_scoped':True,'row_count':counts['wsdl_extracts']},
            {'table_name':'excel_extracts','purpose':'Raw Excel metadata rows','assessment_scoped':True,'row_count':counts['excel_extracts']},
            {'table_name':'merged_reports','purpose':'Merged WSDL + Excel rows','assessment_scoped':True,'row_count':counts['merged_reports']},
            {'table_name':'export_artifacts','purpose':'Export file references','assessment_scoped':True,'row_count':counts['export_artifacts']},
        ]
        return {'assessment': {'assessment_id': assessment.id, 'assessment_code': assessment.assessment_code, 'status': assessment.status, 'wsdl_path': assessment.wsdl_path, 'excel_path': assessment.excel_path, 'started_at': assessment.started_at.isoformat() if assessment.started_at else None, 'finished_at': assessment.finished_at.isoformat() if assessment.finished_at else None}, 'counts': counts, 'tables': tables}
    def structure_detail(self, assessment_id: int, service_name: str | None = None, operation_name: str | None = None):
        aid = self._resolve_id(assessment_id)
        svc_rows = list(self.db.scalars(select(ServiceProperty).where(ServiceProperty.assessment_id == aid).order_by(ServiceProperty.service_name)).all())
        wsdl_rows = list(self.db.scalars(select(WSDLExtract).where(WSDLExtract.assessment_id == aid).order_by(WSDLExtract.id)).all())
        excel_rows = list(self.db.scalars(select(ExcelExtract).where(ExcelExtract.assessment_id == aid).order_by(ExcelExtract.id)).all())
        merged_rows = list(self.db.scalars(select(MergedReport).where(MergedReport.assessment_id == aid).order_by(MergedReport.id)).all())
        if service_name:
            svc_rows = [x for x in svc_rows if x.service_name == service_name]; wsdl_rows = [x for x in wsdl_rows if x.service_name == service_name]; excel_rows = [x for x in excel_rows if x.service_name == service_name]; merged_rows = [x for x in merged_rows if x.service_name == service_name]
        if operation_name:
            wsdl_rows = [x for x in wsdl_rows if x.operation_name == operation_name]; excel_rows = [x for x in excel_rows if x.operation_name == operation_name]; merged_rows = [x for x in merged_rows if x.operation_name == operation_name]
        return {
            'assessment_id': aid,
            'service_properties': [{'service_name': x.service_name, 'namespace': x.namespace, 'endpoint_url': x.endpoint_url, 'documentation': x.documentation, 'bindings': x.bindings_json or [], 'ports': x.ports_json or [], 'operations': x.operations_json or [], 'request_fields': x.request_fields_json or [], 'response_fields': x.response_fields_json or [], 'error_fields': x.error_fields_json or []} for x in svc_rows],
            'wsdl': [{'service_name': x.service_name, 'operation_name': x.operation_name, 'direction': x.direction, 'payload': x.payload_json} for x in wsdl_rows],
            'excel': [{'service_name': x.service_name, 'operation_name': x.operation_name, 'data_sources': x.data_sources_json or [], 'upstream_apps': x.upstream_apps_json or [], 'downstream_apps': x.downstream_apps_json or [], 'raw_row': x.raw_row_json} for x in excel_rows],
            'merged': [
                {
                    'service_name': x.service_name,
                    'operation_name': x.operation_name,
                    'merge_level': x.merge_level,
                    'wsdl_payload': x.wsdl_payload_json,
                    'excel_payload': x.excel_payload_json,
                    'merged_payload': x.merged_payload_json,
                    'excel_service_name': x.excel_service_name,
                    'excel_operation_name': x.excel_operation_name,
                    'data_sources_json': x.data_sources_json,
                    'upstream_apps_json': x.upstream_apps_json,
                    'downstream_apps_json': x.downstream_apps_json,
                    'wsdl_service_name': x.wsdl_service_name,
                    'wsdl_operation_name': x.wsdl_operation_name,
                    'endpoint_url': x.endpoint_url,
                    'port': x.port,
                    'binding': x.binding,
                    'namespace': x.namespace,
                    'soap_action': x.soap_action,
                    'request_structure_json': x.request_structure_json,
                    'response_structure_json': x.response_structure_json,
                    'error_structure_json': x.error_structure_json,
                    'matching_confidence': x.matching_confidence,
                    'matching_logic_used': x.matching_logic_used,
                } for x in merged_rows
            ]
        }
    def assessments(self):
        rows = list(self.db.scalars(select(Assessment).order_by(desc(Assessment.id))).all())
        return {'items': [{'assessment_id': r.id, 'assessment_code': r.assessment_code, 'status': r.status, 'started_at': r.started_at.isoformat() if r.started_at else None, 'finished_at': r.finished_at.isoformat() if r.finished_at else None, 'message': r.message, 'wsdl_path': r.wsdl_path, 'excel_path': r.excel_path} for r in rows]}
    def logs(self, assessment_id: int):
        rows = list(self.db.scalars(select(AssessmentLog).where(AssessmentLog.assessment_id == assessment_id).order_by(AssessmentLog.id)).all())
        return {'assessment_id': assessment_id, 'items': [{'id': r.id, 'level': r.level, 'step': r.step, 'message': r.message, 'created_at': r.created_at.isoformat()} for r in rows]}
    def exports(self, assessment_id: int):
        rows = list(self.db.scalars(select(ExportArtifact).where(ExportArtifact.assessment_id == assessment_id).order_by(ExportArtifact.id)).all())
        return {'assessment_id': assessment_id, 'items': [{'id': r.id, 'file_type': r.file_type, 'artifact_kind': r.artifact_kind, 'relative_path': r.relative_path, 'download_url': f'/exports/{r.relative_path}'} for r in rows]}
