from datetime import datetime
from pathlib import Path
from sqlalchemy import desc, select, delete
from sqlalchemy.orm import Session
from service_analyzer.models.entities import Assessment, AssessmentLog, ServiceProperty, WSDLExtract, ExcelExtract, MergedReport, ExportArtifact
from service_analyzer.config.settings import get_settings

settings = get_settings()

class AssessmentService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, wsdl_path: str, excel_path: str) -> Assessment:
        last = self.db.scalar(select(Assessment).order_by(desc(Assessment.id)).limit(1))
        next_id = 1 if not last else last.id + 1
        code = f"{next_id:03d}"
        row = Assessment(assessment_code=code, status='queued', wsdl_path=wsdl_path, excel_path=excel_path)
        self.db.add(row)
        self.db.commit()
        self.db.refresh(row)
        return row

    def set_status(self, assessment_id: int, status: str, message: str | None = None):
        row = self.db.get(Assessment, assessment_id)
        if not row:
            return None
        row.status = status
        row.message = message
        if status == 'running' and not row.started_at:
            row.started_at = datetime.utcnow()
        if status in {'completed', 'failed', 'cancelled'}:
            row.finished_at = datetime.utcnow()
        self.db.commit(); self.db.refresh(row)
        return row

    def get(self, assessment_id: int):
        return self.db.get(Assessment, assessment_id)

    def delete(self, assessment_id: int) -> bool:
        row = self.db.get(Assessment, assessment_id)
        if not row:
            return False
        code = row.assessment_code
        for model in [AssessmentLog, ServiceProperty, WSDLExtract, ExcelExtract, MergedReport, ExportArtifact]:
            self.db.execute(delete(model).where(model.assessment_id == assessment_id))
        self.db.execute(delete(Assessment).where(Assessment.id == assessment_id))
        self.db.commit()
        for base in [settings.export_dir_path / f'assessment_{code}', settings.upload_dir_path / f'assessment_{code}']:
            if base.exists():
                import shutil
                shutil.rmtree(base, ignore_errors=True)
        return True
