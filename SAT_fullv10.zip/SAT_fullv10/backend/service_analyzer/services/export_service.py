import csv
from typing import Any
from pathlib import Path
from sqlalchemy.orm import Session
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from datetime import datetime
from collections import defaultdict

from service_analyzer.config.settings import get_settings
from service_analyzer.models.entities import ExportArtifact

settings = get_settings()

def _assessment_dir(code: str) -> Path:
    d = settings.export_dir_path / f'assessment_{code}'
    d.mkdir(parents=True, exist_ok=True)
    return d

def _write_csv(path: Path, headers, rows):
    with path.open('w', newline='', encoding='utf-8') as fh:
        writer = csv.writer(fh)
        writer.writerow(headers)
        writer.writerows(rows)

def _style_xlsx(wb: Workbook, sheet_title: str, headers: list[str], rows: list[list[Any]], assessment_code: str = 'N/A'):
    ws = wb.active if len(wb.worksheets) == 1 and wb.worksheets[0].title == "Sheet" else wb.create_sheet()
    ws.title = sheet_title
    ws.views.sheetView[0].showGridLines = True
    
    # 1. Main Title Block
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
    title_cell = ws.cell(row=1, column=1)
    title_cell.value = f"SERVICE ANALYZER TOOL  |  {sheet_title.upper()}"
    title_cell.font = Font(name="Segoe UI", size=15, bold=True, color="1E3A8A")
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 36

    # 2. Subtitle Block
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=len(headers))
    sub_cell = ws.cell(row=2, column=1)
    sub_cell.value = f"Assessment Run Code: {assessment_code}  |  Generated on: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC  |  Status: Completed"
    sub_cell.font = Font(name="Segoe UI", size=9.5, italic=True, color="4B5563")
    sub_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[2].height = 20

    # 3. Spacing Row
    ws.row_dimensions[3].height = 14

    # 4. Table Headers Row at Row 4
    for col_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=4, column=col_idx)
        cell.value = h
        
    ws.row_dimensions[4].height = 28
    
    brand_blue = "1E3A8A" # Professional Dark Blue
    header_fill = PatternFill(start_color=brand_blue, end_color=brand_blue, fill_type="solid")
    header_font = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
    cell_font = Font(name="Segoe UI", size=9)
    
    align_center = Alignment(horizontal="center", vertical="center")
    align_left_top = Alignment(horizontal="left", vertical="top", wrap_text=True)
    
    thin_border = Border(
        left=Side(style='thin', color='E5E7EB'),
        right=Side(style='thin', color='E5E7EB'),
        top=Side(style='thin', color='E5E7EB'),
        bottom=Side(style='thin', color='E5E7EB')
    )
    
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=4, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = align_center
        cell.border = thin_border
        
    for r_idx, row_data in enumerate(rows, start=5):
        ws.row_dimensions[r_idx].height = 22
        
        # Calculate dynamic height based on text newlines
        max_lines = 1
        for col_idx, val in enumerate(row_data, start=1):
            cell = ws.cell(row=r_idx, column=col_idx)
            cell.value = val
            cell.font = cell_font
            cell.border = thin_border
            
            if col_idx == 1:
                cell.alignment = align_center
            else:
                cell.alignment = align_left_top
                
            if val:
                lines = str(val).count('\n') + 1
                if lines > max_lines:
                    max_lines = lines
                    
        ws.row_dimensions[r_idx].height = max(22, min(max_lines * 14 + 8, 120))
                
    for col in ws.columns:
        max_len = 0
        # Start calculating from headers at row 4
        for cell in col[3:]:
            val = str(cell.value or '')
            lines = val.split('\n')
            for line in lines:
                if len(line) > max_len:
                    max_len = len(line)
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = max(min(max_len + 3, 50), 10)

def _generate_pdf(pdf_path: Path, title: str, headers: list[str], data_rows: list[list[Any]], col_widths: list[float] | None = None):
    # A4 Printable width is roughly 595 - 2*36 = 523 points
    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=A4,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#0A0E19'),
        spaceAfter=12
    )
    
    hdr_style = ParagraphStyle(
        'TableHeader',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8,
        leading=10,
        textColor=colors.white,
        alignment=1 # Center
    )
    
    cell_style = ParagraphStyle(
        'TableCell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=7,
        leading=9,
        textColor=colors.HexColor('#1F2937')
    )
    
    story = [
        Paragraph(title, title_style),
        Spacer(1, 10)
    ]
    
    # Wrap all items in Paragraphs to support text wrapping in reportlab table
    tbl_data = []
    tbl_data.append([Paragraph(h, hdr_style) for h in headers])
    for row in data_rows:
        tbl_data.append([Paragraph(str(x if x is not None else ''), cell_style) for x in row])
        
    t = Table(tbl_data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#4B5DFF')),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
    ]))
    
    story.append(t)
    doc.build(story)

def _generate_detailed_pdf(
    pdf_path: Path, 
    assessment_code: str, 
    service_summary: list[dict], 
    wsdl_rows: list[dict], 
    excel_rows: list[dict], 
    merged_export_rows: list[dict]
):
    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=A4,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )
    
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#1E3A8A'),
        spaceAfter=6
    )
    
    subtitle_style = ParagraphStyle(
        'DocSubTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#4B5563'),
        spaceAfter=4
    )
    
    meta_style = ParagraphStyle(
        'DocMeta',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#6B7280'),
        spaceAfter=15
    )
    
    h1_style = ParagraphStyle(
        'SectionH1',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    )
    
    body_style = ParagraphStyle(
        'Body',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8,
        leading=11,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=6
    )
    
    hdr_style = ParagraphStyle(
        'TableHeader',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=7.5,
        leading=9,
        textColor=colors.white,
        alignment=1
    )
    
    cell_style = ParagraphStyle(
        'TableCell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=6.5,
        leading=8,
        textColor=colors.HexColor('#1F2937')
    )
    
    cell_style_bold = ParagraphStyle(
        'TableCellBold',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=6.5,
        leading=8,
        textColor=colors.HexColor('#1F2937')
    )
    
    story = []
    
    story.append(Paragraph("SAT SYSTEM ASSESSMENT REPORT", title_style))
    story.append(Paragraph(f"Assessment Run: {assessment_code}", subtitle_style))
    story.append(Paragraph(f"Generated on: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC  |  Status: Completed", meta_style))
    story.append(Spacer(1, 10))
    
    story.append(Paragraph("1. Executive Summary & Run Statistics", h1_style))
    
    total_services = len(service_summary)
    total_operations = len(merged_export_rows)
    
    exact_matches = sum(1 for r in merged_export_rows if r.get('matching_confidence') == 1.0)
    partial_matches = sum(1 for r in merged_export_rows if r.get('matching_confidence') == 0.5)
    unmatched = sum(1 for r in merged_export_rows if r.get('matching_confidence') == 0.0)
    
    stats_text = (
        f"This report presents the consolidated analysis results of the Service Analyzer Tool (SAT) for run <b>{assessment_code}</b>. "
        f"A total of <b>{total_services}</b> distinct services and <b>{total_operations}</b> operations were analyzed. "
        f"The matching process achieved <b>{exact_matches}</b> exact matches, <b>{partial_matches}</b> service-only matches, and identified <b>{unmatched}</b> unmatched entries. "
        f"Below are the primary parameters of the assessment workspace:"
    )
    story.append(Paragraph(stats_text, body_style))
    story.append(Spacer(1, 8))
    
    stats_headers = ["Metric / Parameter", "Value"]
    stats_data = [
        [Paragraph(h, hdr_style) for h in stats_headers],
        [Paragraph("Assessment Run Code", cell_style_bold), Paragraph(assessment_code, cell_style)],
        [Paragraph("Total Services Identified", cell_style_bold), Paragraph(str(total_services), cell_style)],
        [Paragraph("Total Operations Analyzed", cell_style_bold), Paragraph(str(total_operations), cell_style)],
        [Paragraph("Exact Matches (100% Confidence)", cell_style_bold), Paragraph(str(exact_matches), cell_style)],
        [Paragraph("Partial Matches (50% Confidence)", cell_style_bold), Paragraph(str(partial_matches), cell_style)],
        [Paragraph("Unmatched Records (0% Confidence)", cell_style_bold), Paragraph(str(unmatched), cell_style)],
    ]
    t_stats = Table(stats_data, colWidths=[200, 323])
    t_stats.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(t_stats)
    story.append(Spacer(1, 15))
    
    story.append(Paragraph("2. Detailed Merged Output Catalog", h1_style))
    story.append(Paragraph("The following table details the side-by-side comparison of Excel discovery mappings against parsed WSDL contracts, including endpoints, namespaces, and matching confidence logs:", body_style))
    story.append(Spacer(1, 8))
    
    catalog_headers = ["No", "Excel Service / Operation", "WSDL Service / Operation", "Endpoint URL & Namespace", "Matching Logic / Confidence"]
    catalog_data = [[Paragraph(h, hdr_style) for h in catalog_headers]]
    
    for idx, row in enumerate(merged_export_rows):
        excel_so = f"<b>Svc:</b> {row.get('excel_service_name') or 'n/a'}<br/><b>Op:</b> {row.get('excel_operation_name') or 'n/a'}"
        wsdl_so = f"<b>Svc:</b> {row.get('wsdl_service_name') or 'n/a'}<br/><b>Op:</b> {row.get('wsdl_operation_name') or 'n/a'}"
        ep_ns = f"<b>EP:</b> {row.get('endpoint_url') or 'n/a'}<br/><b>NS:</b> {row.get('namespace') or 'n/a'}"
        logic_conf = f"<b>Logic:</b> {row.get('matching_logic_used') or 'n/a'}<br/><b>Conf:</b> {float(row.get('matching_confidence') or 0)*100:.0f}%"
        
        catalog_data.append([
            Paragraph(str(idx + 1), cell_style),
            Paragraph(excel_so, cell_style),
            Paragraph(wsdl_so, cell_style),
            Paragraph(ep_ns, cell_style),
            Paragraph(logic_conf, cell_style_bold),
        ])
    
    t_cat = Table(catalog_data, colWidths=[20, 115, 115, 153, 120], repeatRows=1)
    t_cat.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ]))
    story.append(t_cat)
    story.append(Spacer(1, 15))
    
    story.append(Paragraph("3. System Dependencies", h1_style))
    story.append(Paragraph("The following table documents the integration mapping including upstream callers, downstream systems, and connected databases / data sources:", body_style))
    story.append(Spacer(1, 8))
    
    dep_headers = ["Service Name", "Upstream Callers", "Downstream Systems", "Data Sources"]
    dep_data = [[Paragraph(h, hdr_style) for h in dep_headers]]
    for row in merged_export_rows:
        up = row.get('upstream_apps')
        down = row.get('downstream_apps')
        ds = row.get('data_sources')
        
        up_str = ", ".join(up) if isinstance(up, list) else str(up or '')
        down_str = ", ".join(down) if isinstance(down, list) else str(down or '')
        ds_str = ", ".join(ds) if isinstance(ds, list) else str(ds or '')
        
        dep_data.append([
            Paragraph(str(row.get('wsdl_service_name') or row.get('excel_service_name') or 'n/a'), cell_style_bold),
            Paragraph(up_str or 'None mapped', cell_style),
            Paragraph(down_str or 'None mapped', cell_style),
            Paragraph(ds_str or 'None mapped', cell_style),
        ])
    t_dep = Table(dep_data, colWidths=[163, 120, 120, 120], repeatRows=1)
    t_dep.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ]))
    story.append(t_dep)
    
    doc.build(story)

def generate_exports(db: Session, assessment_id: int, assessment_code: str, service_summary: list[dict], wsdl_rows: list[dict], excel_rows: list[dict], merged_rows: list[dict]):
    out_dir = _assessment_dir(assessment_code)
    artifacts = []
    
    # Define file names
    rep_csv = out_dir / 'SAT_Assessment_Report.csv'
    rep_xlsx = out_dir / 'SAT_Assessment_Report.xlsx'
    rep_pdf = out_dir / 'SAT_Assessment_Report.pdf'
    
    wsdl_csv = out_dir / 'Extracted_WSDL_Data.csv'
    wsdl_xlsx = out_dir / 'Extracted_WSDL_Data.xlsx'
    wsdl_pdf = out_dir / 'Extracted_WSDL_Data.pdf'
    
    excel_csv = out_dir / 'Excel_Data.csv'
    excel_xlsx = out_dir / 'Excel_Data.xlsx'
    excel_pdf = out_dir / 'Excel_Data.pdf'

    # Headers and rows preparation
    rep_headers = ['No', 'Excel Service Name', 'Excel Operation Name', 'WSDL Service Name', 'WSDL Operation Name', 'UpStream Systems', 'DownStream Systems', 'Data Sources', 'Namespace', 'Endpoint URL', 'Port', 'Binding', 'SOAP Action', 'Request Type Object', 'Request Fields', 'Response Type Object', 'Response Fields', 'Error Type Object', 'Error Fields', 'Matching Confidence', 'Matching Logic Used']
    rep_rows = [[
        i+1, 
        x.get('excel_service_name'), 
        x.get('excel_operation_name'), 
        x.get('wsdl_service_name'), 
        x.get('wsdl_operation_name'), 
        ', '.join(x.get('upstream_apps', [])), 
        ', '.join(x.get('downstream_apps', [])), 
        ', '.join(x.get('data_sources', [])), 
        x.get('namespace'), 
        x.get('endpoint_url'), 
        x.get('port'), 
        x.get('binding'), 
        x.get('soap_action'), 
        x.get('request_type_object'), 
        x.get('request_fields_text'), 
        x.get('response_type_object'), 
        x.get('response_fields_text'), 
        x.get('error_type_object'), 
        x.get('error_fields_text'), 
        x.get('matching_confidence'), 
        x.get('matching_logic_used')
    ] for i, x in enumerate(merged_rows)]
    
    wsdl_headers = ['No', 'Service Name', 'Operation Name', 'Namespace', 'Endpoint URL', 'Request Type Object', 'Request Fields', 'Response Type Object', 'Response Fields', 'Error Type Object', 'Error Fields']
    wsdl_export_rows = [[
        i+1,
        x['service_name'],
        x.get('operation_name'),
        x.get('namespace'),
        x.get('endpoint_url'),
        x.get('request_type_object'),
        x.get('request_fields_text'),
        x.get('response_type_object'),
        x.get('response_fields_text'),
        x.get('error_type_object'),
        x.get('error_fields_text')
    ] for i, x in enumerate(wsdl_rows)]

    excel_headers = ['No', 'Service Name', 'Operation Name', 'UpStream Systems', 'DownStream Systems', 'Data Sources']
    excel_export_rows = [[
        i+1,
        x['service_name'],
        x.get('operation_name'),
        ', '.join(x.get('upstream_apps', [])),
        ', '.join(x.get('downstream_apps', [])),
        ', '.join(x.get('data_sources', []))
    ] for i, x in enumerate(excel_rows)]

    # === 1. SAT Assessment Report (Merged Output) ===
    _write_csv(rep_csv, rep_headers, rep_rows)
    artifacts.append(('csv', 'SAT_Assessment_Report', rep_csv))
    
    wb1 = Workbook()
    _style_xlsx(wb1, 'SAT Assessment Report', rep_headers, rep_rows, assessment_code)
    wb1.save(rep_xlsx)
    artifacts.append(('xlsx', 'SAT_Assessment_Report', rep_xlsx))
    
    # Detailed PDF generation
    _generate_detailed_pdf(rep_pdf, assessment_code, service_summary, wsdl_rows, excel_rows, merged_rows)
    artifacts.append(('pdf', 'SAT_Assessment_Report', rep_pdf))

    # === 2. WSDL Data ===
    _write_csv(wsdl_csv, wsdl_headers, wsdl_export_rows)
    artifacts.append(('csv', 'Extracted_WSDL_Data', wsdl_csv))
    
    wb2 = Workbook()
    _style_xlsx(wb2, 'Extracted WSDL Data', wsdl_headers, wsdl_export_rows, assessment_code)
    wb2.save(wsdl_xlsx)
    artifacts.append(('xlsx', 'Extracted_WSDL_Data', wsdl_xlsx))
    
    # PDF generation
    pdf_wsdl_headers = ['No', 'Service Name', 'Operation Name', 'Namespace', 'Endpoint URL', 'Request Object', 'Response Object']
    pdf_wsdl_rows = [[
        str(r[0]), str(r[1] or ''), str(r[2] or ''), str(r[3] or ''), str(r[4] or ''), str(r[5] or ''), str(r[7] or '')
    ] for r in wsdl_export_rows]
    _generate_pdf(wsdl_pdf, f'Extracted WSDL Data - Run {assessment_code}', pdf_wsdl_headers, pdf_wsdl_rows, col_widths=[24, 85, 85, 95, 95, 70, 69])
    artifacts.append(('pdf', 'Extracted_WSDL_Data', wsdl_pdf))

    # === 3. Excel Data ===
    _write_csv(excel_csv, excel_headers, excel_export_rows)
    artifacts.append(('csv', 'Excel_Data', excel_csv))
    
    wb3 = Workbook()
    _style_xlsx(wb3, 'Excel Data', excel_headers, excel_export_rows, assessment_code)
    wb3.save(excel_xlsx)
    artifacts.append(('xlsx', 'Excel_Data', excel_xlsx))
    
    # PDF generation
    pdf_excel_headers = ['No', 'Service Name', 'Operation Name', 'UpStream Systems', 'DownStream Systems', 'Data Sources']
    pdf_excel_rows = [[
        str(r[0]), str(r[1] or ''), str(r[2] or ''), str(r[3] or ''), str(r[4] or ''), str(r[5] or '')
    ] for r in excel_export_rows]
    _generate_pdf(excel_pdf, f'Excel Discovery Data - Run {assessment_code}', pdf_excel_headers, pdf_excel_rows, col_widths=[24, 100, 100, 100, 100, 99])
    artifacts.append(('pdf', 'Excel_Data', excel_pdf))

    # Commit export artifact records to database in order
    for file_type, kind, path in artifacts:
        rel = path.relative_to(settings.export_dir_path)
        db.add(ExportArtifact(
            assessment_id=assessment_id,
            file_type=file_type,
            artifact_kind=kind,
            relative_path=str(rel).replace('\\', '/')
        ))
    db.commit()
