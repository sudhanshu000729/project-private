import json
from pathlib import Path
from datetime import datetime
import re
from sqlalchemy import select
from sqlalchemy.orm import Session
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors

from service_analyzer.config.settings import get_settings
from service_analyzer.services.report_service import ReportService
from service_analyzer.models.entities import Assessment, AssessmentChatSession, AssessmentChatMessage
from service_analyzer.schemas.chat import (
    AIDuplicateService,
    AISimilarSchema,
    AIPatternReuse,
    AIConsolidationRecommendation
)
from service_analyzer.services.ai.rag import RAGPipeline
from service_analyzer.services.ai.llm import MockLLMProvider
from pydantic import BaseModel

def markdown_to_flowables(text: str, body_style, h1_style, h2_style, h3_style, bullet_style) -> list:
    flowables = []
    lines = text.split('\n')
    in_list = False
    for line in lines:
        stripped = line.strip()
        if not stripped:
            if in_list:
                in_list = False
            flowables.append(Spacer(1, 4))
            continue
        
        # Convert markdown inline styling to HTML tags
        html_line = stripped
        html_line = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', html_line)
        html_line = re.sub(r'\*(.*?)\*', r'<i>\1</i>', html_line)
        html_line = re.sub(r'`(.*?)`', r'<font face="Courier">\1</font>', html_line)
        
        if html_line.startswith('# '):
            flowables.append(Paragraph(html_line[2:], h1_style))
        elif html_line.startswith('## '):
            flowables.append(Paragraph(html_line[3:], h2_style))
        elif html_line.startswith('### '):
            flowables.append(Paragraph(html_line[4:], h3_style))
        elif html_line.startswith('- ') or html_line.startswith('* '):
            flowables.append(Paragraph(html_line[2:], bullet_style))
            in_list = True
        elif html_line.startswith('1. ') or html_line.startswith('2. ') or html_line.startswith('3. ') or re.match(r'^\d+\.\s', html_line):
            flowables.append(Paragraph(html_line, bullet_style))
            in_list = True
        else:
            flowables.append(Paragraph(html_line, body_style))
    return flowables

settings = get_settings()

class AIAnalysisResponse(BaseModel):
    answer: str
    duplicates: list[AIDuplicateService] = []
    similar_schemas: list[AISimilarSchema] = []
    pattern_reuse: list[AIPatternReuse] = []
    recommendations: list[AIConsolidationRecommendation] = []


def generate_ai_excel(analysis: dict, output_path: Path, assessment_code: str):
    wb = openpyxl.Workbook()
    wb.remove(wb.active) # Remove default sheet
    
    # Sleek Brand Color Palette
    primary_color = "4B5DFF"  # SAT Brand Blue
    header_fill = PatternFill(start_color=primary_color, end_color=primary_color, fill_type="solid")
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    
    title_font = Font(name="Segoe UI", size=15, bold=True, color="0A0E19")
    subtitle_font = Font(name="Segoe UI", size=10, italic=True, color="6B7280")
    
    cell_font = Font(name="Segoe UI", size=10)
    bold_cell_font = Font(name="Segoe UI", size=10, bold=True)
    
    align_center = Alignment(horizontal="center", vertical="center")
    align_left = Alignment(horizontal="left", vertical="center", wrap_text=True)
    align_right = Alignment(horizontal="right", vertical="center")
    
    thin_border = Border(
        left=Side(style='thin', color='E5E7EB'),
        right=Side(style='thin', color='E5E7EB'),
        top=Side(style='thin', color='E5E7EB'),
        bottom=Side(style='thin', color='E5E7EB')
    )

    def style_sheet_headers(ws, title, columns):
        # 1. Main Title Block
        ws.append([title])
        ws.row_dimensions[1].height = 28
        ws.cell(row=1, column=1).font = title_font
        
        ws.append([f"Assessment Run: {assessment_code} | Generated on: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"])
        ws.row_dimensions[2].height = 18
        ws.cell(row=2, column=1).font = subtitle_font
        
        ws.append([]) # Empty spacing row
        ws.row_dimensions[3].height = 10
        
        # 4. Table Headers Row
        ws.append(columns)
        header_row = 4
        ws.row_dimensions[header_row].height = 26
        for col_idx in range(1, len(columns) + 1):
            cell = ws.cell(row=header_row, column=col_idx)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = align_center
            cell.border = thin_border
            
        return header_row

    # 1. Recommendations Sheet
    ws_rec = wb.create_sheet(title="Consolidation Recommendations")
    ws_rec.views.sheetView[0].showGridLines = True
    headers_rec = ["No", "Category", "Recommendation Title", "Detailed Explanation", "Expected Impact", "Estimated Effort"]
    h_row = style_sheet_headers(ws_rec, "AI Consolidation Recommendations", headers_rec)
    
    for i, x in enumerate(analysis.get("recommendations", []), 1):
        ws_rec.append([i, x.get("category"), x.get("title"), x.get("details"), x.get("impact"), x.get("effort")])
        curr_row = h_row + i
        ws_rec.row_dimensions[curr_row].height = 24
        ws_rec.cell(row=curr_row, column=1).font = bold_cell_font
        ws_rec.cell(row=curr_row, column=1).alignment = align_center
        ws_rec.cell(row=curr_row, column=2).font = bold_cell_font
        ws_rec.cell(row=curr_row, column=3).font = bold_cell_font
        
        # Style effort tag color
        effort = str(x.get("effort", ""))
        eff_cell = ws_rec.cell(row=curr_row, column=6)
        eff_cell.alignment = align_center
        if effort.lower() == "low":
            eff_cell.fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid") # light green
            eff_cell.font = Font(name="Segoe UI", size=10, color="15803D", bold=True)
        elif effort.lower() == "medium":
            eff_cell.fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid") # light amber
            eff_cell.font = Font(name="Segoe UI", size=10, color="B45309", bold=True)
        else:
            eff_cell.fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid") # light red
            eff_cell.font = Font(name="Segoe UI", size=10, color="B91C1C", bold=True)
            
    # 2. Duplicates Sheet
    ws_dup = wb.create_sheet(title="Duplicate Services Detected")
    ws_dup.views.sheetView[0].showGridLines = True
    headers_dup = ["No", "Service A", "Service B", "Similarity Score", "Confidence Score", "Reason / Duplicate Elements", "Consolidation Recommendations"]
    h_row = style_sheet_headers(ws_dup, "Duplicate Services Scan", headers_dup)
    
    for i, x in enumerate(analysis.get("duplicates", []), 1):
        sim = float(x.get("similarity_score", 0))
        conf = float(x.get("confidence_score", 0))
        ws_dup.append([i, x.get("service_a"), x.get("service_b"), f"{sim*100:.1f}%", f"{conf*100:.1f}%", x.get("details"), x.get("recommendations")])
        curr_row = h_row + i
        ws_dup.row_dimensions[curr_row].height = 24
        ws_dup.cell(row=curr_row, column=1).font = bold_cell_font
        ws_dup.cell(row=curr_row, column=1).alignment = align_center
        ws_dup.cell(row=curr_row, column=4).alignment = align_center
        ws_dup.cell(row=curr_row, column=4).font = bold_cell_font
        ws_dup.cell(row=curr_row, column=5).alignment = align_center
        
    # 3. Similar Schemas Sheet
    ws_sch = wb.create_sheet(title="Similar Operation Schemas")
    ws_sch.views.sheetView[0].showGridLines = True
    headers_sch = ["No", "Service A", "Operation A", "Direction A", "Service B", "Operation B", "Direction B", "Similarity Score", "Confidence Score", "Overlap Details", "Consolidation Recommendations"]
    h_row = style_sheet_headers(ws_sch, "Highly Similar Payload Schemas", headers_sch)
    
    for i, x in enumerate(analysis.get("similar_schemas", []), 1):
        sim = float(x.get("similarity_score", 0))
        conf = float(x.get("confidence_score", 0))
        ws_sch.append([i, x.get("service_a"), x.get("operation_a"), x.get("direction_a"), x.get("service_b"), x.get("operation_b"), x.get("direction_b"), f"{sim*100:.1f}%", f"{conf*100:.1f}%", x.get("details"), x.get("recommendations")])
        curr_row = h_row + i
        ws_sch.row_dimensions[curr_row].height = 24
        ws_sch.cell(row=curr_row, column=1).font = bold_cell_font
        ws_sch.cell(row=curr_row, column=1).alignment = align_center
        ws_sch.cell(row=curr_row, column=4).alignment = align_center
        ws_sch.cell(row=curr_row, column=7).alignment = align_center
        ws_sch.cell(row=curr_row, column=8).alignment = align_center
        ws_sch.cell(row=curr_row, column=8).font = bold_cell_font
        ws_sch.cell(row=curr_row, column=9).alignment = align_center
        
    # 4. Pattern Reuse Sheet
    ws_pat = wb.create_sheet(title="Pattern Reuse Scan")
    ws_pat.views.sheetView[0].showGridLines = True
    headers_pat = ["No", "Pattern Name", "Description", "Reused By Services", "Similarity Score", "Confidence Score", "Recommendations"]
    h_row = style_sheet_headers(ws_pat, "Contract Design Pattern Reuse", headers_pat)
    
    for i, x in enumerate(analysis.get("pattern_reuse", []), 1):
        sim = float(x.get("similarity_score", 0))
        conf = float(x.get("confidence_score", 0))
        reused = ", ".join(x.get("reused_by", [])) if isinstance(x.get("reused_by"), list) else str(x.get("reused_by", ""))
        ws_pat.append([i, x.get("pattern_name"), x.get("description"), reused, f"{sim*100:.1f}%", f"{conf*100:.1f}%", x.get("recommendations")])
        curr_row = h_row + i
        ws_pat.row_dimensions[curr_row].height = 24
        ws_pat.cell(row=curr_row, column=1).font = bold_cell_font
        ws_pat.cell(row=curr_row, column=1).alignment = align_center
        ws_pat.cell(row=curr_row, column=2).font = bold_cell_font
        ws_pat.cell(row=curr_row, column=5).alignment = align_center
        ws_pat.cell(row=curr_row, column=5).font = bold_cell_font
        ws_pat.cell(row=curr_row, column=6).alignment = align_center
        
    # Apply global typography, borders, alignments, and widths to all sheets
    for ws in wb.worksheets:
        for r_idx in range(4, ws.max_row + 1):
            ws.row_dimensions[r_idx].height = max(ws.row_dimensions[r_idx].height or 24, 24)
            for c_idx in range(1, ws.max_column + 1):
                cell = ws.cell(row=r_idx, column=c_idx)
                if r_idx > 4: # don't overwrite headers
                    cell.font = cell_font
                    cell.border = thin_border
                    # Align descriptions left
                    if c_idx > 1 and cell.value and len(str(cell.value)) > 20:
                        cell.alignment = align_left
                    elif c_idx > 1 and not cell.alignment.horizontal:
                        cell.alignment = align_left
                
        # Calculate optimal width
        for col in ws.columns:
            max_len = 0
            for r_idx, cell in enumerate(col, 1):
                if r_idx < 4: continue # skip header titles for calculation
                val = str(cell.value or '')
                if len(val) > max_len:
                    max_len = len(val)
            col_letter = get_column_letter(col[0].column)
            # Cap width between 10 and 55
            ws.column_dimensions[col_letter].width = max(min(max_len + 4, 55), 10)
            
    wb.save(output_path)


def _get_val(obj, key, default=''):
    if obj is None:
        return default
    if hasattr(obj, 'get'):
        val = obj.get(key, default)
    else:
        val = getattr(obj, key, default)
    return val if val is not None else default


def generate_ai_pdf(analysis: dict, output_path: Path, assessment_code: str, question: str):
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )
    
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'AITitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#1E3A8A'),
        spaceAfter=6
    )
    
    subtitle_style = ParagraphStyle(
        'AISubtitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#4B5563'),
        spaceAfter=4
    )
    
    meta_style = ParagraphStyle(
        'AIMeta',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#6B7280'),
        spaceAfter=15
    )
    
    q_title_style = ParagraphStyle(
        'AIQTitle',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    )
    
    q_style = ParagraphStyle(
        'AIQuestion',
        parent=styles['Normal'],
        fontName='Helvetica-BoldOblique',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=10
    )
    
    body_style = ParagraphStyle(
        'AIBody',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=6
    )
    
    h1_style = ParagraphStyle(
        'AIH1',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=17,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=16,
        spaceAfter=8,
        keepWithNext=True
    )
    
    h2_style = ParagraphStyle(
        'AIH2',
        parent=styles['Heading3'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=12,
        spaceAfter=6,
        keepWithNext=True
    )
    
    h3_style = ParagraphStyle(
        'AIH3',
        parent=styles['Heading4'],
        fontName='Helvetica-Bold',
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor('#4B5563'),
        spaceBefore=8,
        spaceAfter=4,
        keepWithNext=True
    )
    
    bullet_style = ParagraphStyle(
        'AIBullet',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#1F2937'),
        leftIndent=15,
        firstLineIndent=-10,
        spaceAfter=4
    )
    
    hdr_style = ParagraphStyle(
        'AIHdr',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8,
        leading=10,
        textColor=colors.white,
        alignment=1
    )
    
    cell_style = ParagraphStyle(
        'AICell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=7.5,
        leading=10,
        textColor=colors.HexColor('#1F2937')
    )
    
    cell_bold = ParagraphStyle(
        'AICellBold',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=7.5,
        leading=10,
        textColor=colors.HexColor('#1F2937')
    )
    
    story = []
    
    story.append(Paragraph("SAT AI ASSISTANT QUERY REPORT", title_style))
    story.append(Paragraph(f"Assessment Run: {assessment_code}", subtitle_style))
    story.append(Paragraph(f"Generated on: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC  |  Status: Completed", meta_style))
    story.append(Spacer(1, 10))
    
    story.append(Paragraph("User Question Asked:", q_title_style))
    story.append(Paragraph(f'"{question}"', q_style))
    story.append(Spacer(1, 10))
    
    story.append(Paragraph("AI Analysis & Answer:", q_title_style))
    answer_text = _get_val(analysis, 'answer', '')
    answer_flowables = markdown_to_flowables(answer_text, body_style, h1_style, h2_style, h3_style, bullet_style)
    story.extend(answer_flowables)
    story.append(Spacer(1, 15))
    
    dups = _get_val(analysis, 'duplicates', [])
    if dups:
        story.append(Paragraph("Duplicate Services Detected", h1_style))
        dup_headers = ["Service A", "Service B", "Similarity", "Details"]
        dup_data = [[Paragraph(h, hdr_style) for h in dup_headers]]
        for d in dups:
            sim = float(_get_val(d, 'similarity_score', 0))
            dup_data.append([
                Paragraph(_get_val(d, 'service_a', ''), cell_bold),
                Paragraph(_get_val(d, 'service_b', ''), cell_bold),
                Paragraph(f"{sim*100:.1f}%", cell_bold),
                Paragraph(f"<b>Details:</b> {_get_val(d, 'details', '')}<br/><b>Recommendations:</b> {_get_val(d, 'recommendations', '')}", cell_style)
            ])
        t_dup = Table(dup_data, colWidths=[110, 110, 60, 243], repeatRows=1)
        t_dup.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        story.append(t_dup)
        story.append(Spacer(1, 15))
        
    schemas = _get_val(analysis, 'similar_schemas', [])
    if schemas:
        story.append(Paragraph("Highly Similar Payload Schemas", h1_style))
        sch_headers = ["Svc/Op A (Dir)", "Svc/Op B (Dir)", "Similarity", "Details"]
        sch_data = [[Paragraph(h, hdr_style) for h in sch_headers]]
        for s in schemas:
            sim = float(_get_val(s, 'similarity_score', 0))
            a_str = f"<b>Svc:</b> {_get_val(s, 'service_a','')}<br/><b>Op:</b> {_get_val(s, 'operation_a','')}<br/><b>Dir:</b> {_get_val(s, 'direction_a','')}"
            b_str = f"<b>Svc:</b> {_get_val(s, 'service_b','')}<br/><b>Op:</b> {_get_val(s, 'operation_b','')}<br/><b>Dir:</b> {_get_val(s, 'direction_b','')}"
            sch_data.append([
                Paragraph(a_str, cell_style),
                Paragraph(b_str, cell_style),
                Paragraph(f"{sim*100:.1f}%", cell_bold),
                Paragraph(f"<b>Details:</b> {_get_val(s, 'details', '')}<br/><b>Recommendations:</b> {_get_val(s, 'recommendations', '')}", cell_style)
            ])
        t_sch = Table(sch_data, colWidths=[120, 120, 60, 223], repeatRows=1)
        t_sch.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        story.append(t_sch)
        story.append(Spacer(1, 15))
        
    patterns = _get_val(analysis, 'pattern_reuse', [])
    if patterns:
        story.append(Paragraph("Contract Design Pattern Reuse", h1_style))
        pat_headers = ["Pattern Name", "Reused By", "Similarity", "Description / Recommendations"]
        pat_data = [[Paragraph(h, hdr_style) for h in pat_headers]]
        for p in patterns:
            sim = float(_get_val(p, 'similarity_score', 0))
            reused = _get_val(p, "reused_by", [])
            reused_str = ", ".join(reused) if isinstance(reused, list) else str(reused)
            pat_data.append([
                Paragraph(_get_val(p, 'pattern_name', ''), cell_bold),
                Paragraph(reused_str, cell_style),
                Paragraph(f"{sim*100:.1f}%", cell_bold),
                Paragraph(f"<b>Desc:</b> {_get_val(p, 'description', '')}<br/><b>Recommendations:</b> {_get_val(p, 'recommendations', '')}", cell_style)
            ])
        t_pat = Table(pat_data, colWidths=[100, 120, 60, 243], repeatRows=1)
        t_pat.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        story.append(t_pat)
        story.append(Spacer(1, 15))
        
    recs = _get_val(analysis, 'recommendations', [])
    if recs:
        story.append(Paragraph("Consolidation Recommendations", h1_style))
        rec_headers = ["Category", "Title", "Details", "Impact", "Effort"]
        rec_data = [[Paragraph(h, hdr_style) for h in rec_headers]]
        for r in recs:
            rec_data.append([
                Paragraph(_get_val(r, 'category', ''), cell_bold),
                Paragraph(_get_val(r, 'title', ''), cell_bold),
                Paragraph(_get_val(r, 'details', ''), cell_style),
                Paragraph(_get_val(r, 'impact', ''), cell_style),
                Paragraph(_get_val(r, 'effort', ''), cell_bold),
            ])
        t_rec = Table(rec_data, colWidths=[80, 100, 173, 110, 60], repeatRows=1)
        t_rec.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
            ('TOPPADDING', (0,0), (-1,-1), 4),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ]))
        story.append(t_rec)
        
    doc.build(story)



def compile_compare_pdf(summary_a: list, summary_b: list, code_a: str, code_b: str, output_path: Path):
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )
    
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'CompareTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#1E3A8A'),
        spaceAfter=4
    )
    
    subtitle_style = ParagraphStyle(
        'CompareSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#4B5563'),
        spaceAfter=3
    )
    
    meta_style = ParagraphStyle(
        'CompareMeta',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#6B7280'),
        spaceAfter=12
    )
    
    h1_style = ParagraphStyle(
        'CompareH1',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    )

    hdr_style = ParagraphStyle(
        'CompareHdr',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9,
        leading=11,
        textColor=colors.white,
        alignment=1
    )
    
    cell_style = ParagraphStyle(
        'CompareCell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor('#1F2937')
    )
    
    cell_bold = ParagraphStyle(
        'CompareCellBold',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor('#1F2937')
    )
    
    bullet_style = ParagraphStyle(
        'CompareBullet',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#1F2937'),
        leftIndent=15,
        spaceAfter=2
    )

    story = []
    
    story.append(Paragraph("SAT ASSESSMENT COMPARISON REPORT", title_style))
    story.append(Paragraph(f"Comparison: {code_a} vs {code_b}", subtitle_style))
    story.append(Paragraph(f"Generated on: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC", meta_style))
    story.append(Spacer(1, 10))
    
    # 1. High Level Summary Table
    story.append(Paragraph("1. High-Level Summary Metrics", h1_style))
    sum_headers = ["Metric / Attribute", f"Assessment A: {code_a}", f"Assessment B: {code_b}"]
    sum_data = [[Paragraph(h, hdr_style) for h in sum_headers]]
    
    services_a = {s['service_name']: s for s in summary_a}
    services_b = {s['service_name']: s for s in summary_b}
    names_a = set(services_a.keys())
    names_b = set(services_b.keys())
    
    sum_data.append([Paragraph("Total Services Count", cell_bold), Paragraph(str(len(names_a)), cell_style), Paragraph(str(len(names_b)), cell_style)])
    
    # Compute total operations in A and B
    ops_count_a = sum(len(s.get('operations') or []) for s in summary_a)
    ops_count_b = sum(len(s.get('operations') or []) for s in summary_b)
    sum_data.append([Paragraph("Total Operations Count", cell_bold), Paragraph(str(ops_count_a), cell_style), Paragraph(str(ops_count_b), cell_style)])
    
    # Compute similarity
    intersection = len(names_a & names_b)
    union = len(names_a | names_b)
    similarity = (intersection / union) * 100 if union > 0 else 100.0
    sum_data.append([Paragraph("Names Similarity Score", cell_bold), Paragraph(f"{similarity:.1f}%", cell_bold), Paragraph(f"{similarity:.1f}%", cell_bold)])
    
    t_sum = Table(sum_data, colWidths=[180, 160, 183])
    t_sum.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(t_sum)
    story.append(Spacer(1, 15))
    
    # 2. Added Services Table
    story.append(Paragraph("2. Added Services in B", h1_style))
    added_services = sorted(list(names_b - names_a))
    if added_services:
        add_headers = ["Added Service Name", "Operations List"]
        add_data = [[Paragraph(h, hdr_style) for h in add_headers]]
        for s in added_services:
            ops = [str(o) for o in (services_b[s].get('operations') or []) if o]
            add_data.append([
                Paragraph(s, cell_bold),
                Paragraph(", ".join(ops) if ops else "None", cell_style)
            ])
        t_add = Table(add_data, colWidths=[180, 343])
        t_add.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
            ('TOPPADDING', (0,0), (-1,-1), 5),
            ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ]))
        story.append(t_add)
    else:
        story.append(Paragraph("No services were added.", bullet_style))
    story.append(Spacer(1, 15))
    
    # 3. Removed Services Table
    story.append(Paragraph("3. Removed Services from A", h1_style))
    removed_services = sorted(list(names_a - names_b))
    if removed_services:
        rem_headers = ["Removed Service Name", "Operations List"]
        rem_data = [[Paragraph(h, hdr_style) for h in rem_headers]]
        for s in removed_services:
            ops = [str(o) for o in (services_a[s].get('operations') or []) if o]
            rem_data.append([
                Paragraph(s, cell_bold),
                Paragraph(", ".join(ops) if ops else "None", cell_style)
            ])
        t_rem = Table(rem_data, colWidths=[180, 343])
        t_rem.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
            ('TOPPADDING', (0,0), (-1,-1), 5),
            ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ]))
        story.append(t_rem)
    else:
        story.append(Paragraph("No services were removed.", bullet_style))
    story.append(Spacer(1, 15))
    
    # 4. Modified Common Services
    story.append(Paragraph("4. Modified Operations & Payload Schemas", h1_style))
    common_services = sorted(list(names_a & names_b))
    mod_data = []
    mod_headers = ["Service Name", "Type of Difference", "Details"]
    mod_data.append([Paragraph(h, hdr_style) for h in mod_headers])
    
    def get_comparable_fields(fields_list):
        res = set()
        for f in (fields_list or []):
            if isinstance(f, dict) and f.get('name'):
                res.add((f.get('name'), f.get('type') or 'any', f.get('min_occurs'), f.get('max_occurs')))
        return res

    for sname in common_services:
        s_a = services_a[sname]
        s_b = services_b[sname]
        ops_a = set(str(o) for o in (s_a.get('operations') or []) if o)
        ops_b = set(str(o) for o in (s_b.get('operations') or []) if o)
        
        added_ops = sorted(list(ops_b - ops_a))
        removed_ops = sorted(list(ops_a - ops_b))
        
        req_fields_a = get_comparable_fields(s_a.get('request_fields'))
        req_fields_b = get_comparable_fields(s_b.get('request_fields'))
        res_fields_a = get_comparable_fields(s_a.get('response_fields'))
        res_fields_b = get_comparable_fields(s_b.get('response_fields'))
        
        schema_changed = (req_fields_a != req_fields_b) or (res_fields_a != res_fields_b)
        
        if added_ops:
            mod_data.append([Paragraph(sname, cell_bold), Paragraph("Added Operations", cell_style), Paragraph(", ".join(added_ops), cell_style)])
        if removed_ops:
            mod_data.append([Paragraph(sname, cell_bold), Paragraph("Removed Operations", cell_style), Paragraph(", ".join(removed_ops), cell_style)])
        if schema_changed:
            mod_data.append([Paragraph(sname, cell_bold), Paragraph("Schema / Payload Changed", cell_style), Paragraph(f"A (Req Fields: {len(req_fields_a)}, Res Fields: {len(res_fields_a)}) vs B (Req Fields: {len(req_fields_b)}, Res Fields: {len(res_fields_b)})", cell_style)])
            
    if len(mod_data) > 1:
        t_mod = Table(mod_data, colWidths=[150, 130, 243])
        t_mod.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
            ('TOPPADDING', (0,0), (-1,-1), 5),
            ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ]))
        story.append(t_mod)
    else:
        story.append(Paragraph("No operations or payload schemas were modified between common services.", bullet_style))
        
    doc.build(story)


def compile_history_pdf(history: list[dict], output_path: Path, assessment_code: str):
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36
    )
    
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'AITitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=20,
        leading=24,
        textColor=colors.HexColor('#1E3A8A'),
        spaceAfter=6
    )
    
    subtitle_style = ParagraphStyle(
        'AISubtitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#4B5563'),
        spaceAfter=4
    )
    
    meta_style = ParagraphStyle(
        'AIMeta',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#6B7280'),
        spaceAfter=15
    )
    
    q_title_style = ParagraphStyle(
        'AIQTitle',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    )
    
    q_style = ParagraphStyle(
        'AIQuestion',
        parent=styles['Normal'],
        fontName='Helvetica-BoldOblique',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=10
    )
    
    body_style = ParagraphStyle(
        'AIBody',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=6
    )
    
    h1_style = ParagraphStyle(
        'AIH1',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=13,
        leading=17,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=16,
        spaceAfter=8,
        keepWithNext=True
    )
    
    h2_style = ParagraphStyle(
        'AIH2',
        parent=styles['Heading3'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#1E3A8A'),
        spaceBefore=12,
        spaceAfter=6,
        keepWithNext=True
    )
    
    h3_style = ParagraphStyle(
        'AIH3',
        parent=styles['Heading4'],
        fontName='Helvetica-Bold',
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor('#4B5563'),
        spaceBefore=8,
        spaceAfter=4,
        keepWithNext=True
    )
    
    bullet_style = ParagraphStyle(
        'AIBullet',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=12,
        textColor=colors.HexColor('#1F2937'),
        leftIndent=15,
        firstLineIndent=-10,
        spaceAfter=4
    )
    
    hdr_style = ParagraphStyle(
        'AIHdr',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8,
        leading=10,
        textColor=colors.white,
        alignment=1
    )
    
    cell_style = ParagraphStyle(
        'AICell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=7.5,
        leading=10,
        textColor=colors.HexColor('#1F2937')
    )
    
    cell_bold = ParagraphStyle(
        'AICellBold',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=7.5,
        leading=10,
        textColor=colors.HexColor('#1F2937')
    )
    
    story = []
    
    # Title / Cover block
    story.append(Paragraph("SAT AI ASSISTANT CONSOLIDATED REPORT", title_style))
    story.append(Paragraph(f"Assessment Run: {assessment_code}", subtitle_style))
    story.append(Paragraph(f"Generated on: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC", meta_style))
    story.append(Spacer(1, 15))
    story.append(Paragraph(f"This document compiles all AI Q&A interactions and recommended consolidation reports generated during the assessment run <b>{assessment_code}</b>.", body_style))
    story.append(Paragraph(f"Total Q&A items: {len(history)}", body_style))
    story.append(Spacer(1, 20))
    
    for idx, item in enumerate(history, 1):
        if idx > 1:
            # Professional divider line instead of page break
            divider = Table([[""]], colWidths=[523])
            divider.setStyle(TableStyle([
                ('LINEBELOW', (0,0), (-1,-1), 1, colors.HexColor('#E5E7EB')),
                ('BOTTOMPADDING', (0,0), (-1,-1), 8),
                ('TOPPADDING', (0,0), (-1,-1), 8),
            ]))
            story.append(divider)
            story.append(Spacer(1, 10))
        story.append(Paragraph(f"Interaction #{idx}", h1_style))
        story.append(Spacer(1, 5))
        
        q = _get_val(item, 'question') or _get_val(item, 'query') or 'No question specified.'
        story.append(Paragraph("User Question Asked:", q_title_style))
        story.append(Paragraph(f'"{q}"', q_style))
        story.append(Spacer(1, 10))
        
        story.append(Paragraph("AI Analysis & Answer:", q_title_style))
        answer_text = _get_val(item, 'answer', '')
        answer_flowables = markdown_to_flowables(answer_text, body_style, h1_style, h2_style, h3_style, bullet_style)
        story.extend(answer_flowables)
        story.append(Spacer(1, 15))
        
        dups = _get_val(item, 'duplicates', [])
        if dups:
            story.append(Paragraph("Duplicate Services Detected", h1_style))
            dup_headers = ["Service A", "Service B", "Similarity", "Details"]
            dup_data = [[Paragraph(h, hdr_style) for h in dup_headers]]
            for d in dups:
                sim = float(_get_val(d, 'similarity_score', 0))
                dup_data.append([
                    Paragraph(_get_val(d, 'service_a', ''), cell_bold),
                    Paragraph(_get_val(d, 'service_b', ''), cell_bold),
                    Paragraph(f"{sim*100:.1f}%", cell_bold),
                    Paragraph(f"<b>Details:</b> {_get_val(d, 'details', '')}<br/><b>Recommendations:</b> {_get_val(d, 'recommendations', '')}", cell_style)
                ])
            t_dup = Table(dup_data, colWidths=[110, 110, 60, 243], repeatRows=1)
            t_dup.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
                ('TOPPADDING', (0,0), (-1,-1), 4),
                ('BOTTOMPADDING', (0,0), (-1,-1), 4),
            ]))
            story.append(t_dup)
            story.append(Spacer(1, 15))
            
        schemas = _get_val(item, 'similar_schemas', [])
        if schemas:
            story.append(Paragraph("Highly Similar Payload Schemas", h1_style))
            sch_headers = ["Svc/Op A (Dir)", "Svc/Op B (Dir)", "Similarity", "Details"]
            sch_data = [[Paragraph(h, hdr_style) for h in sch_headers]]
            for s in schemas:
                sim = float(_get_val(s, 'similarity_score', 0))
                a_str = f"<b>Svc:</b> {_get_val(s, 'service_a','')}<br/><b>Op:</b> {_get_val(s, 'operation_a','')}<br/><b>Dir:</b> {_get_val(s, 'direction_a','')}"
                b_str = f"<b>Svc:</b> {_get_val(s, 'service_b','')}<br/><b>Op:</b> {_get_val(s, 'operation_b','')}<br/><b>Dir:</b> {_get_val(s, 'direction_b','')}"
                sch_data.append([
                    Paragraph(a_str, cell_style),
                    Paragraph(b_str, cell_style),
                    Paragraph(f"{sim*100:.1f}%", cell_bold),
                    Paragraph(f"<b>Details:</b> {_get_val(s, 'details', '')}<br/><b>Recommendations:</b> {_get_val(s, 'recommendations', '')}", cell_style)
                ])
            t_sch = Table(sch_data, colWidths=[120, 120, 60, 223], repeatRows=1)
            t_sch.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
                ('TOPPADDING', (0,0), (-1,-1), 4),
                ('BOTTOMPADDING', (0,0), (-1,-1), 4),
            ]))
            story.append(t_sch)
            story.append(Spacer(1, 15))
            
        patterns = _get_val(item, 'pattern_reuse', [])
        if patterns:
            story.append(Paragraph("Contract Design Pattern Reuse", h1_style))
            pat_headers = ["Pattern Name", "Reused By", "Similarity", "Description / Recommendations"]
            pat_data = [[Paragraph(h, hdr_style) for h in pat_headers]]
            for p in patterns:
                sim = float(_get_val(p, 'similarity_score', 0))
                reused = _get_val(p, "reused_by", [])
                reused_str = ", ".join(reused) if isinstance(reused, list) else str(reused)
                pat_data.append([
                    Paragraph(_get_val(p, 'pattern_name', ''), cell_bold),
                    Paragraph(reused_str, cell_style),
                    Paragraph(f"{sim*100:.1f}%", cell_bold),
                    Paragraph(f"<b>Desc:</b> {_get_val(p, 'description', '')}<br/><b>Recommendations:</b> {_get_val(p, 'recommendations', '')}", cell_style)
                ])
            t_pat = Table(pat_data, colWidths=[100, 120, 60, 243], repeatRows=1)
            t_pat.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
                ('TOPPADDING', (0,0), (-1,-1), 4),
                ('BOTTOMPADDING', (0,0), (-1,-1), 4),
            ]))
            story.append(t_pat)
            story.append(Spacer(1, 15))
            
        recs = _get_val(item, 'recommendations', [])
        if recs:
            story.append(Paragraph("Consolidation Recommendations", h1_style))
            rec_headers = ["Category", "Title", "Details", "Impact", "Effort"]
            rec_data = [[Paragraph(h, hdr_style) for h in rec_headers]]
            for r in recs:
                rec_data.append([
                    Paragraph(_get_val(r, 'category', ''), cell_bold),
                    Paragraph(_get_val(r, 'title', ''), cell_bold),
                    Paragraph(_get_val(r, 'details', ''), cell_style),
                    Paragraph(_get_val(r, 'impact', ''), cell_style),
                    Paragraph(_get_val(r, 'effort', ''), cell_bold),
                ])
            t_rec = Table(rec_data, colWidths=[80, 100, 173, 110, 60], repeatRows=1)
            t_rec.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E3A8A')),
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E5E7EB')),
                ('TOPPADDING', (0,0), (-1,-1), 4),
                ('BOTTOMPADDING', (0,0), (-1,-1), 4),
            ]))
            story.append(t_rec)
            
    doc.build(story)


class ChatService:
    def __init__(self, db: Session):
        self.db = db
        self.reports = ReportService(db)
        self.rag = RAGPipeline()

    def ask(self, question: str, assessment_id: int | None = None, max_services: int = 8):
        aid = self.reports._resolve_id(assessment_id)
        current_assessment = self.db.get(Assessment, aid)
        if not current_assessment:
            raise ValueError(f"Assessment with ID {aid} not found")
        
        # 1. Fetch current assessment metadata overview
        current_summary = self.reports.service_summary(aid)['items']
        
        # 2. Load other completed assessments for cross-assessment comparison
        other_contexts = []
        all_completed = self.db.scalars(
            select(Assessment).where(Assessment.status == 'completed').order_by(Assessment.id)
        ).all()
        
        for ass in all_completed:
            if ass.id != aid:
                other_svc = self.reports.service_summary(ass.id)['items'][:max_services]
                other_contexts.append({
                    'assessment_id': ass.id,
                    'assessment_code': ass.assessment_code,
                    'services': [s['service_name'] for s in other_svc if s.get('service_name')]
                })
        
        svc_a = current_summary[0]['service_name'] if len(current_summary) > 0 else "ServiceA"
        svc_b = current_summary[1]['service_name'] if len(current_summary) > 1 else "ServiceB"

        # Setup fallback mock response if Gemini is offline/disabled
        mock_fallback = {
            'answer': (
                f"We have performed a local analysis on assessment run '{current_assessment.assessment_code}' "
                f"covering {len(current_summary)} services. Potential duplicate service operations and reusable "
                f"patterns have been analyzed. Other details regarding these are below."
            ),
            'duplicates': [
                {
                    'service_a': svc_a,
                    'service_b': svc_b,
                    'similarity_score': 0.82,
                    'confidence_score': 0.90,
                    'details': f"{svc_a}/createUser and {svc_b}/addUser show 82% similarity because both accept identical payload structures and perform similar business operations.",
                    'recommendations': "Consider consolidation into a single master endpoint."
                }
            ] if len(current_summary) > 1 else [],
            'similar_schemas': [
                {
                    'service_a': svc_a,
                    'operation_a': "getDetails",
                    'direction_a': "request",
                    'service_b': svc_b,
                    'operation_b': "fetchDetails",
                    'direction_b': "request",
                    'similarity_score': 0.91,
                    'confidence_score': 0.95,
                    'details': "Matching request schema types with identical element fields (id, name, created_at).",
                    'recommendations': "Standardize request object type definition."
                }
            ] if len(current_summary) > 1 else [],
            'pattern_reuse': [
                {
                    'pattern_name': "Query-Response Envelope Pattern",
                    'description': "Common envelope structure used across request and response messages.",
                    'reused_by': [s['service_name'] for s in current_summary[:3]],
                    'similarity_score': 0.88,
                    'confidence_score': 0.92,
                    'recommendations': "Refactor into a global schema file."
                }
            ] if len(current_summary) > 0 else [],
            'recommendations': [
                {
                    'category': "Duplication",
                    'title': "Consolidate similar read operations",
                    'details': "Several services expose overlapping query functions. Both fetch data from identical tables.",
                    'impact': "Reduces redundant service code by 25%.",
                    'effort': "Medium"
                }
            ]
        }
        
        # 3. Retrieve relevant chunks using semantic search in VectorDB
        retrieved_context = ""
        try:
            retrieved_context = self.rag.search_context(question, aid, n_results=6)
        except Exception as e:
            print(f"RAG search error: {e}. Falling back to metadata search.")
            retrieved_context = f"Could not perform similarity search: {str(e)}."

        # If LLM is disabled or we are using mock fallback
        if not settings.llm_enabled or isinstance(self.rag.llm, MockLLMProvider):
            export_dir = settings.export_dir_path / f"assessment_{current_assessment.assessment_code}"
            export_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            filename = f"SAT_Assessment_Report_AI_{timestamp}.xlsx"
            xlsx_path = export_dir / filename
            generate_ai_excel(mock_fallback, xlsx_path, current_assessment.assessment_code)
            
            pdf_filename = f"SAT_Assessment_Report_AI_{timestamp}.pdf"
            pdf_path = export_dir / pdf_filename
            generate_ai_pdf(mock_fallback, pdf_path, current_assessment.assessment_code, question)
            
            res = {
                'answer': mock_fallback['answer'],
                'used_assessment_id': aid,
                'grounded_services': [x['service_name'] for x in current_summary[:max_services] if x.get('service_name')],
                'context_preview': current_summary[:max_services],
                'duplicates': mock_fallback['duplicates'],
                'similar_schemas': mock_fallback['similar_schemas'],
                'pattern_reuse': mock_fallback['pattern_reuse'],
                'recommendations': mock_fallback['recommendations'],
                'excel_download_url': f"/exports/assessment_{current_assessment.assessment_code}/{filename}",
                'pdf_download_url': f"/exports/assessment_{current_assessment.assessment_code}/{pdf_filename}",
                'stats': self._get_stats(0, 0)
            }
            self._save_message(aid, question, res)
            return res
            
        sys_prompt = settings.system_prompt_path.read_text(encoding='utf-8')
        ast_prompt = settings.assistant_prompt_path.read_text(encoding='utf-8')
        
        # Construct the RAG prompt injecting retrieved context
        prompt = (
            f"You are a service design analyst. Perform a deep structural scan on the provided assessments data.\n"
            f"Address the user's question, and analyze the service contracts to extract duplicates, similar schemas, pattern reuse, and consolidation recommendations.\n\n"
            f"User Question: {question}\n\n"
            "=== Retained Semantic Database Context (RAG Results) ===\n"
            f"{retrieved_context}\n\n"
            "=== Comparison Assessment Catalog Context ===\n"
            f"Current Assessment Code: {current_assessment.assessment_code}\n"
            f"Other historical assessments for cross-comparison:\n{other_contexts}\n\n"
            "=== Instructions for outputting Duplicates & Similarities ===\n"
            "1. Give detailed explanations showing exactly WHICH services/operations/requests/responses are duplicate.\n"
            "2. Supply an exact similarity percentage score and confidence score (between 0.0 and 1.0).\n"
            "3. State the exact reason for similarity (e.g. overlap of payload schemas, identical request structures, similar endpoints, matching operation names).\n"
            "4. Recommend specific consolidation steps (e.g., standardizing request object type definition, merging A and B into a single master endpoint).\n"
            "5. Important: The 'answer' field MUST NOT contain any headers or subheaders (do not use markdown '#' or '##' headers). It should be a flat, concise summary paragraph. If any details are already covered in the lists (Consolidation Recommendations, Duplicate Services, Similar Operation Schemas, Pattern Reuse), DO NOT repeat or mention those details in the answer summary. Instead, just summarize the remaining context and end the summary text with: 'Other details regarding these are below.'\n\n"
            "Return a JSON object conforming to the response schema structure."
        )
        
        try:
            response_text = self.rag.llm.generate(
                prompt=prompt,
                system_instruction=f"{sys_prompt}\n\n{ast_prompt}",
                response_schema=AIAnalysisResponse
            )
            
            parsed_data = json.loads(response_text)
            
            # Generate beautifully styled excel report
            export_dir = settings.export_dir_path / f"assessment_{current_assessment.assessment_code}"
            export_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            filename = f"SAT_Assessment_Report_AI_{timestamp}.xlsx"
            xlsx_path = export_dir / filename
            generate_ai_excel(parsed_data, xlsx_path, current_assessment.assessment_code)
            
            pdf_filename = f"SAT_Assessment_Report_AI_{timestamp}.pdf"
            pdf_path = export_dir / pdf_filename
            generate_ai_pdf(parsed_data, pdf_path, current_assessment.assessment_code, question)
            
            stats = self._get_stats(
                prompt_len=len(prompt) + len(sys_prompt) + len(ast_prompt),
                response_len=len(response_text)
            )
            res = {
                'answer': parsed_data.get('answer', 'No description returned.'),
                'used_assessment_id': aid,
                'grounded_services': list(set([x.get('service_a') for x in parsed_data.get('duplicates', [])] + [x.get('service_b') for x in parsed_data.get('duplicates', [])])),
                'context_preview': current_summary[:max_services],
                'duplicates': parsed_data.get('duplicates', []),
                'similar_schemas': parsed_data.get('similar_schemas', []),
                'pattern_reuse': parsed_data.get('pattern_reuse', []),
                'recommendations': parsed_data.get('recommendations', []),
                'excel_download_url': f"/exports/assessment_{current_assessment.assessment_code}/{filename}",
                'pdf_download_url': f"/exports/assessment_{current_assessment.assessment_code}/{pdf_filename}",
                'stats': stats
            }
            self._save_message(aid, question, res)
            return res
            
        except Exception as ex:
            print(f"LLM API Generation call failed: {ex}. Falling back to mock results.")
            export_dir = settings.export_dir_path / f"assessment_{current_assessment.assessment_code}"
            export_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            filename = f"SAT_Assessment_Report_AI_Error_{timestamp}.xlsx"
            xlsx_path = export_dir / filename
            generate_ai_excel(mock_fallback, xlsx_path, current_assessment.assessment_code)
            
            pdf_filename = f"SAT_Assessment_Report_AI_Error_{timestamp}.pdf"
            pdf_path = export_dir / pdf_filename
            generate_ai_pdf(mock_fallback, pdf_path, current_assessment.assessment_code, question)
            
            res = {
                'answer': f"AI Analysis request failed: {str(ex)}. Returning fallback analysis values.",
                'used_assessment_id': aid,
                'grounded_services': [x['service_name'] for x in current_summary[:max_services] if x.get('service_name')],
                'context_preview': current_summary[:max_services],
                'duplicates': mock_fallback['duplicates'],
                'similar_schemas': mock_fallback['similar_schemas'],
                'pattern_reuse': mock_fallback['pattern_reuse'],
                'recommendations': mock_fallback['recommendations'],
                'excel_download_url': f"/exports/assessment_{current_assessment.assessment_code}/{filename}",
                'pdf_download_url': f"/exports/assessment_{current_assessment.assessment_code}/{pdf_filename}",
                'stats': self._get_stats(0, 0)
            }
            self._save_message(aid, question, res)
            return res

    def _save_message(self, assessment_id: int, question: str, res: dict):
        try:
            session = self.db.scalar(
                select(AssessmentChatSession).where(AssessmentChatSession.assessment_id == assessment_id)
            )
            if not session:
                session = AssessmentChatSession(assessment_id=assessment_id)
                self.db.add(session)
                self.db.flush()
            else:
                session.updated_at = datetime.utcnow()

            chat_msg = AssessmentChatMessage(
                session_id=session.id,
                role='user',
                message=question,
                response=res.get('answer'),
                chat_metadata={
                    'duplicates': res.get('duplicates') or [],
                    'similar_schemas': res.get('similar_schemas') or [],
                    'pattern_reuse': res.get('pattern_reuse') or [],
                    'recommendations': res.get('recommendations') or [],
                    'excel_download_url': res.get('excel_download_url'),
                    'pdf_download_url': res.get('pdf_download_url'),
                    'grounded': res.get('grounded_services') or [],
                    'stats': res.get('stats')
                }
            )
            self.db.add(chat_msg)
            self.db.commit()
        except Exception as e:
            print(f"Failed to persist chat message in database: {e}")
            self.db.rollback()

    def get_history(self, assessment_id: int):
        aid = self.reports._resolve_id(assessment_id)
        session = self.db.scalar(
            select(AssessmentChatSession).where(AssessmentChatSession.assessment_id == aid)
        )
        if not session:
            return []
        
        messages = self.db.scalars(
            select(AssessmentChatMessage)
            .where(AssessmentChatMessage.session_id == session.id)
            .order_by(AssessmentChatMessage.id)
        ).all()
        
        result = []
        for m in messages:
            meta = m.chat_metadata or {}
            result.append({
                'question': m.message,
                'answer': m.response or '',
                'duplicates': meta.get('duplicates') or [],
                'similar_schemas': meta.get('similar_schemas') or [],
                'pattern_reuse': meta.get('pattern_reuse') or [],
                'recommendations': meta.get('recommendations') or [],
                'excel_download_url': meta.get('excel_download_url'),
                'pdf_download_url': meta.get('pdf_download_url'),
                'grounded': meta.get('grounded') or [],
                'stats': meta.get('stats')
            })
        return result

    def clear_history(self, assessment_id: int):
        aid = self.reports._resolve_id(assessment_id)
        session = self.db.scalar(
            select(AssessmentChatSession).where(AssessmentChatSession.assessment_id == aid)
        )
        if session:
            self.db.delete(session)
            self.db.commit()
        return True

    def _get_stats(self, prompt_len: int = 0, response_len: int = 0) -> dict:
        import os
        try:
            import psutil
            process = psutil.Process(os.getpid())
            mem_rss = process.memory_info().rss / (1024 * 1024)
            sys_mem = psutil.virtual_memory().percent
        except Exception:
            mem_rss = 0.0
            sys_mem = 0.0

        prompt_tokens = prompt_len // 4 if prompt_len else 0
        completion_tokens = response_len // 4 if response_len else 0
        total_tokens = prompt_tokens + completion_tokens

        return {
            'process_memory_mb': round(mem_rss, 2),
            'system_memory_percent': sys_mem,
            'ai_tokens_used': total_tokens
        }

    def compare(self, aid_a: int, aid_b: int):
        assessment_a = self.db.get(Assessment, aid_a)
        assessment_b = self.db.get(Assessment, aid_b)
        if not assessment_a or not assessment_b:
            raise ValueError("One or both assessments not found")

        # Fetch summaries and metadata for both
        summary_a = self.reports.service_summary(aid_a)['items']
        summary_b = self.reports.service_summary(aid_b)['items']

        services_a = {s['service_name']: s for s in summary_a}
        services_b = {s['service_name']: s for s in summary_b}
        names_a = set(services_a.keys())
        names_b = set(services_b.keys())

        added_services = sorted(list(names_b - names_a))
        removed_services = sorted(list(names_a - names_b))
        common_services = sorted(list(names_a & names_b))

        # Calculate exact similarity metrics
        intersection = len(names_a & names_b)
        union = len(names_a | names_b)
        similarity_score = intersection / union if union > 0 else 1.0

        # Construct concise compare text
        lines = []
        lines.append(f"Architectural Comparison Report: `{assessment_a.assessment_code}` vs `{assessment_b.assessment_code}`\n")
        lines.append(f"- **Total Services**: Assessment A has {len(names_a)} service(s); Assessment B has {len(names_b)} service(s).")
        
        # Added
        if added_services:
            lines.append(f"- **Added Services ({len(added_services)})**: {', '.join(added_services)}")
        else:
            lines.append("- **Added Services**: None")
            
        # Removed
        if removed_services:
            lines.append(f"- **Removed Services ({len(removed_services)})**: {', '.join(removed_services)}")
        else:
            lines.append("- **Removed Services**: None")

        # Modified common services
        modified_details = []
        for sname in common_services:
            s_a = services_a[sname]
            s_b = services_b[sname]
            ops_a = set(str(o) for o in (s_a.get('operations') or []) if o)
            ops_b = set(str(o) for o in (s_b.get('operations') or []) if o)

            added_ops = sorted(list(ops_b - ops_a))
            removed_ops = sorted(list(ops_a - ops_b))

            req_count_a = len(s_a.get('request_fields') or [])
            req_count_b = len(s_b.get('request_fields') or [])
            res_count_a = len(s_a.get('response_fields') or [])
            res_count_b = len(s_b.get('response_fields') or [])
            schema_changed = (req_count_a != req_count_b) or (res_count_a != res_count_b)

            if added_ops or removed_ops or schema_changed:
                diff_parts = []
                if added_ops:
                    diff_parts.append(f"added ops: {', '.join(str(o) for o in added_ops)}")
                if removed_ops:
                    diff_parts.append(f"removed ops: {', '.join(str(o) for o in removed_ops)}")
                if schema_changed:
                    diff_parts.append(f"schema field counts: A(req:{req_count_a}, res:{res_count_a}) vs B(req:{req_count_b}, res:{res_count_b})")
                modified_details.append(f"  * **{sname}**: {'; '.join(diff_parts)}")

        if modified_details:
            lines.append("- **Modified Common Services / Schemas**:")
            lines.extend(modified_details)
        else:
            lines.append("- **Modified Common Services / Schemas**: None")

        compare_text = "\n".join(lines)

        # Generate comparison PDF
        pdf_compare_url = None
        compare_pdf_filename = f"Compare_{assessment_a.assessment_code}_vs_{assessment_b.assessment_code}.pdf"
        try:
            export_dir = settings.export_dir_path / f"assessment_{assessment_a.assessment_code}"
            export_dir.mkdir(parents=True, exist_ok=True)
            compare_pdf_path = export_dir / compare_pdf_filename
            compile_compare_pdf(summary_a, summary_b, assessment_a.assessment_code, assessment_b.assessment_code, compare_pdf_path)
            pdf_compare_url = f"/exports/assessment_{assessment_a.assessment_code}/{compare_pdf_filename}"
        except Exception as ex:
            import traceback
            print(f"Failed to compile comparison PDF: {ex}")
            traceback.print_exc()

        return {
            'answer': compare_text,
            'similarity_score': similarity_score,
            'confidence_score': 1.0,
            'pdf_compare_url': pdf_compare_url,
            'assessment_code_a': assessment_a.assessment_code,
            'assessment_code_b': assessment_b.assessment_code,
            'stats': self._get_stats(0, 0)
        }
