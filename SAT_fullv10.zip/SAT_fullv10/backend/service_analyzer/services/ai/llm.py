import os
from typing import Generator, Any

from service_analyzer.config.settings import get_settings
from service_analyzer.services.ai.base import BaseLLMProvider

try:
    from langchain_google_genai import ChatGoogleGenerativeAI
    from langchain_core.messages import HumanMessage, SystemMessage
except ImportError:
    ChatGoogleGenerativeAI = None
    HumanMessage = None
    SystemMessage = None


settings = get_settings()


class GeminiLLMProvider(BaseLLMProvider):
    def __init__(self):
        self.api_key = settings.resolved_api_key

        if not self.api_key:
            raise ValueError(
                "Google/Gemini API key is not configured. "
                "Set GOOGLE_API_KEY or GEMINI_API_KEY in your env."
            )

        if ChatGoogleGenerativeAI is None:
            raise ImportError("langchain-google-genai package is not installed.")

        kwargs = {
            "model": settings.gemini_model,
            "google_api_key": self.api_key,
        }

        if settings.gemini_temperature is not None:
            kwargs["temperature"] = settings.gemini_temperature

        self.llm = ChatGoogleGenerativeAI(**kwargs)

    def _build_messages(
        self,
        prompt: str,
        system_instruction: str | None = None,
    ):
        messages = []

        if system_instruction:
            messages.append(SystemMessage(content=system_instruction))

        messages.append(HumanMessage(content=prompt))
        return messages

    def generate(
        self,
        prompt: str,
        system_instruction: str | None = None,
        response_schema: Any | None = None,
    ) -> str:
        messages = self._build_messages(prompt, system_instruction)

        if response_schema:
            structured_llm = self.llm.with_structured_output(response_schema)
            response = structured_llm.invoke(messages)

            # LangChain may return dict, Pydantic object, or model-specific object
            if isinstance(response, str):
                return response

            if hasattr(response, "model_dump_json"):
                return response.model_dump_json()

            if hasattr(response, "json"):
                return response.json()

            import json
            return json.dumps(response)

        response = self.llm.invoke(messages)
        return response.content or ""

    def stream(
        self,
        prompt: str,
        system_instruction: str | None = None,
    ) -> Generator[str, None, None]:
        messages = self._build_messages(prompt, system_instruction)

        for chunk in self.llm.stream(messages):
            if chunk.content:
                yield chunk.content


class MockLLMProvider(BaseLLMProvider):
    def generate(
        self,
        prompt: str,
        system_instruction: str | None = None,
        response_schema: Any | None = None,
    ) -> str:
        if response_schema:
            import json
            return json.dumps({
                "answer": (
                    "Fallback response: AI Model is offline or API key is missing. "
                    "Context was loaded from DB."
                ),
                "duplicates": [],
                "similar_schemas": [],
                "pattern_reuse": [],
                "recommendations": [],
            })

        return "Mock LLM: API offline."

    def stream(
        self,
        prompt: str,
        system_instruction: str | None = None,
    ) -> Generator[str, None, None]:
        yield "Mock LLM: API offline."


def get_llm_provider(provider_name: str | None = None) -> BaseLLMProvider:
    if provider_name is None:
        provider_name = os.getenv("ACTIVE_LLM_PROVIDER", "gemini")

    provider_name = provider_name.lower().strip()

    if provider_name == "gemini":
        try:
            return GeminiLLMProvider()
        except (ValueError, ImportError) as e:
            print(
                "Skipping Gemini LLM Provider initialization due to "
                f"configuration or dependency error: {e}. "
                "Falling back to MockLLMProvider."
            )
            return MockLLMProvider()

    if provider_name == "mock":
        return MockLLMProvider()

    raise ValueError(
        f"LLM provider '{provider_name}' is not currently implemented. "
        "Supported: gemini, mock."
    )