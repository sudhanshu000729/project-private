import os
import hashlib
from typing import List

from service_analyzer.config.settings import get_settings
from service_analyzer.services.ai.base import BaseEmbeddingProvider

try:
    from langchain_google_genai import GoogleGenerativeAIEmbeddings
except ImportError:
    GoogleGenerativeAIEmbeddings = None

settings = get_settings()


class GeminiEmbeddingProvider(BaseEmbeddingProvider):
    def __init__(self):
        self.api_key = settings.resolved_api_key

        if not self.api_key:
            raise ValueError("Google/Gemini API key is not configured.")

        if GoogleGenerativeAIEmbeddings is None:
            raise ImportError(
                "langchain-google-genai package is not installed."
            )

        self.model = "gemini-embedding-001"
        self.embeddings = GoogleGenerativeAIEmbeddings(
            model=self.model,
            google_api_key=self.api_key,
        )

    def embed(self, text: str) -> List:
        if not text.strip():
            return [0.0] * 768

        return self.embeddings.embed_query(text)

    def embed_many(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []

        cleaned = [t if t.strip() else "empty" for t in texts]

        print(f"Using embedding model: {self.model}")

        return self.embeddings.embed_documents(cleaned)


class MockEmbeddingProvider(BaseEmbeddingProvider):
    def embed(self, text: str) -> List:
        # Deterministically generate a 768-dim vector using hashlib
        h = hashlib.sha256(text.encode("utf-8")).digest()

        vector = []
        for i in range(768):
            val = (
                (h[(i * 3) % len(h)] ^ h[(i * 7) % len(h)]) - 128.0
            ) / 128.0
            vector.append(val)

        return vector

    def embed_many(self, texts: List[str]) -> List[List[float]]:
        return [self.embed(t) for t in texts]


def get_embedding_provider(
    provider_name: str | None = None,
) -> BaseEmbeddingProvider:
    if provider_name is None:
        provider_name = os.getenv(
            "ACTIVE_EMBEDDING_PROVIDER",
            "gemini",
        )

    provider_name = provider_name.lower().strip()

    if provider_name == "gemini":
        try:
            return GeminiEmbeddingProvider()
        except (ValueError, ImportError) as e:
            print(
                "Skipping Gemini Embedding Provider initialization "
                f"due to configuration or dependency error: {e}. "
                "Falling back to MockEmbeddingProvider."
            )
            return MockEmbeddingProvider()

    elif provider_name == "mock":
        return MockEmbeddingProvider()

    raise ValueError(
        f"Embedding provider '{provider_name}' is not currently "
        "implemented. Supported: gemini, mock."
    )