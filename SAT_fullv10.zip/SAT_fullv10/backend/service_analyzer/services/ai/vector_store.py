import os
import math
import json
from typing import List, Dict, Any
from service_analyzer.services.ai.base import BaseVectorStore, BaseEmbeddingProvider

try:
    import chromadb
except ImportError:
    chromadb = None

class ChromaVectorStore(BaseVectorStore):
    def __init__(self, embedding_provider: BaseEmbeddingProvider, persist_dir: str = "chroma_db"):
        if chromadb is None:
            raise ImportError("chromadb library is not installed.")
        self.embedding_provider = embedding_provider
        self.persist_dir = persist_dir
        self.client = chromadb.PersistentClient(path=self.persist_dir)
        self.collection = self.client.get_or_create_collection(name="sat_assessment_collection")

    def add_documents(self, ids: List[str], documents: List[str], metadatas: List[Dict[str, Any]]) -> None:
        if not ids:
            return
        embeddings = self.embedding_provider.embed_many(documents)
        self.collection.upsert(
            ids=ids,
            embeddings=embeddings,
            documents=documents,
            metadatas=metadatas
        )

    def similarity_search(self, query_text: str, n_results: int = 5) -> List[Dict[str, Any]]:
        query_emb = self.embedding_provider.embed(query_text)
        results = self.collection.query(
            query_embeddings=[query_emb],
            n_results=min(n_results, self.collection.count()) if self.collection.count() > 0 else n_results
        )
        out = []
        if results and "ids" in results and results["ids"] and len(results["ids"][0]) > 0:
            ids = results["ids"][0]
            docs = results["documents"][0]
            metas = results["metadatas"][0]
            distances = results.get("distances", [[]])[0]
            for idx in range(len(ids)):
                dist = distances[idx] if idx < len(distances) else 0.0
                score = 1.0 / (1.0 + dist)
                out.append({
                    "id": ids[idx],
                    "document": docs[idx],
                    "metadata": metas[idx],
                    "score": score
                })
        return out

    def clear(self) -> None:
        try:
            self.client.delete_collection("sat_assessment_collection")
            self.collection = self.client.get_or_create_collection(name="sat_assessment_collection")
        except Exception:
            pass


class InMemoryVectorStore(BaseVectorStore):
    def __init__(self, embedding_provider: BaseEmbeddingProvider, db_path: str = "inmemory_vector_db.json"):
        self.embedding_provider = embedding_provider
        self.db_path = db_path
        self.data = []
        self.load()

    def load(self):
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, "r", encoding="utf-8") as f:
                    self.data = json.load(f)
            except Exception:
                self.data = []

    def save(self):
        try:
            with open(self.db_path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False)
        except Exception as e:
            print(f"Failed to save in-memory vector db: {e}")

    def add_documents(self, ids: List[str], documents: List[str], metadatas: List[Dict[str, Any]]) -> None:
        if not ids:
            return
        embeddings = self.embedding_provider.embed_many(documents)
        for i, doc, meta, emb in zip(ids, documents, metadatas, embeddings):
            existing_idx = next((idx for idx, item in enumerate(self.data) if item["id"] == i), None)
            item = {"id": i, "document": doc, "metadata": meta, "embedding": emb}
            if existing_idx is not None:
                self.data[existing_idx] = item
            else:
                self.data.append(item)
        self.save()

    def similarity_search(self, query_text: str, n_results: int = 5) -> List[Dict[str, Any]]:
        query_emb = self.embedding_provider.embed(query_text)
        if not self.data or not query_emb:
            return []

        def cosine_similarity(v1, v2):
            dot_product = sum(x * y for x, y in zip(v1, v2))
            norm_a = math.sqrt(sum(x * x for x in v1))
            norm_b = math.sqrt(sum(y * y for y in v2))
            if norm_a == 0 or norm_b == 0:
                return 0.0
            return dot_product / (norm_a * norm_b)

        scored = []
        for item in self.data:
            score = cosine_similarity(query_emb, item["embedding"])
            scored.append((score, item))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [{"id": item["id"], "document": item["document"], "metadata": item["metadata"], "score": score} for score, item in scored[:n_results]]

    def clear(self) -> None:
        self.data = []
        self.save()


def get_vector_store(embedding_provider: BaseEmbeddingProvider, store_name: str | None = None) -> BaseVectorStore:
    if store_name is None:
        store_name = os.getenv("ACTIVE_VECTOR_STORE", "chromadb")

    store_name = store_name.lower().strip()
    if store_name == "chromadb" and chromadb is not None:
        try:
            persist_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "chroma_db")
            return ChromaVectorStore(embedding_provider, persist_dir=persist_dir)
        except Exception as e:
            print(f"Skipping ChromaVectorStore initialization due to error: {e}. Falling back to InMemoryVectorStore.")
    
    # Fallback/Default
    db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "inmemory_vector_db.json")
    return InMemoryVectorStore(embedding_provider, db_path=db_path)
