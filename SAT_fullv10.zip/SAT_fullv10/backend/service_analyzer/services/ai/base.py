from abc import ABC, abstractmethod
from typing import List, Dict, Any, Generator

class BaseLLMProvider(ABC):
    @abstractmethod
    def generate(self, prompt: str, system_instruction: str | None = None, response_schema: Any | None = None) -> str:
        pass

    @abstractmethod
    def stream(self, prompt: str, system_instruction: str | None = None) -> Generator[str, None, None]:
        pass

class BaseEmbeddingProvider(ABC):
    @abstractmethod
    def embed(self, text: str) -> List[float]:
        pass

    @abstractmethod
    def embed_many(self, texts: List[str]) -> List[List[float]]:
        pass

class BaseVectorStore(ABC):
    @abstractmethod
    def add_documents(self, ids: List[str], documents: List[str], metadatas: List[Dict[str, Any]]) -> None:
        pass

    @abstractmethod
    def similarity_search(self, query_text: str, n_results: int = 5) -> List[Dict[str, Any]]:
        pass

    @abstractmethod
    def clear(self) -> None:
        pass
