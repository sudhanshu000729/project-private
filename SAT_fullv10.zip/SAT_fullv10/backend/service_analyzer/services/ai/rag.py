from sqlalchemy.orm import Session
from sqlalchemy import select
from service_analyzer.models.entities import Assessment, MergedReport, ServiceProperty
from service_analyzer.services.ai.llm import get_llm_provider
from service_analyzer.services.ai.embeddings import get_embedding_provider
from service_analyzer.services.ai.vector_store import get_vector_store

class RAGPipeline:
    def __init__(self):
        self.llm = get_llm_provider()
        self.embedding = get_embedding_provider()
        self.vector_store = get_vector_store(self.embedding)

    def ingest_assessment(self, db: Session, assessment_id: int):
        assessment = db.get(Assessment, assessment_id)
        if not assessment:
            return

        # Fetch merged reports for this assessment
        stmt = select(MergedReport).where(MergedReport.assessment_id == assessment_id)
        merged_rows = list(db.scalars(stmt).all())

        ids = []
        documents = []
        metadatas = []

        for row in merged_rows:
            service_name = row.service_name
            op_name = row.operation_name or "unknown_op"

            # Flatten fields lists into strings for document indexing
            def format_fields(fields):
                if not fields:
                    return "None"
                if isinstance(fields, list):
                    return ", ".join([f"{f.get('name')}:{f.get('type')}" for f in fields if f.get('name')])
                return str(fields)

            req_fields = format_fields(row.request_structure_json)
            resp_fields = format_fields(row.response_structure_json)
            err_fields = format_fields(row.error_structure_json)

            # Build a rich semantic description of this operation
            doc = (
                f"Assessment Run: {assessment.assessment_code}\n"
                f"Service: {service_name}\n"
                f"Namespace: {row.namespace or 'n/a'}\n"
                f"Endpoint URL: {row.endpoint_url or 'n/a'}\n"
                f"Port: {row.port or 'n/a'}\n"
                f"Binding: {row.binding or 'n/a'}\n"
                f"Operation: {op_name}\n"
                f"SOAP Action: {row.soap_action or 'n/a'}\n"
                f"Request payload structure fields: {req_fields}\n"
                f"Response payload structure fields: {resp_fields}\n"
                f"Error/Fault payload structure fields: {err_fields}\n"
                f"Upstream Applications calling this operation: {', '.join(row.upstream_apps_json or []) if row.upstream_apps_json else 'None'}\n"
                f"Downstream Applications called: {', '.join(row.downstream_apps_json or []) if row.downstream_apps_json else 'None'}\n"
                f"Data Sources accessed: {', '.join(row.data_sources_json or []) if row.data_sources_json else 'None'}\n"
                f"Contract Matching Logic: {row.matching_logic_used or 'n/a'}\n"
                f"Contract Matching Confidence: {row.matching_confidence if row.matching_confidence is not None else 0.0}\n"
            )

            # Unique ID for upserting
            doc_id = f"ass_{assessment_id}_svc_{service_name}_op_{op_name}"

            ids.append(doc_id)
            documents.append(doc)
            metadatas.append({
                "assessment_id": assessment_id,
                "assessment_code": assessment.assessment_code,
                "service_name": service_name,
                "operation_name": op_name,
                "matching_confidence": row.matching_confidence if row.matching_confidence is not None else 0.0
            })

        if ids:
            self.vector_store.add_documents(ids, documents, metadatas)
            print(f"RAG Pipeline: Ingested {len(ids)} operations for assessment {assessment.assessment_code}.")

    def search_context(self, query: str, assessment_id: int, n_results: int = 6) -> str:
        results = self.vector_store.similarity_search(query, n_results=20) # get broader list to filter by assessment
        
        # Filter results by assessment_id in metadata
        filtered = [r for r in results if r["metadata"].get("assessment_id") == assessment_id]
        
        # Take top n_results
        top_matches = filtered[:n_results]

        if not top_matches:
            return "No matching service operations found in vector database for this assessment context."

        context_blocks = []
        for i, match in enumerate(top_matches, 1):
            context_blocks.append(
                f"[Chunk {i}] (Similarity Score: {match['score']:.4f})\n"
                f"{match['document']}"
            )
        
        return "\n---\n".join(context_blocks)
