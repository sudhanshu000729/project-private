from sqlalchemy.orm import Session
from service_analyzer.models.entities import AssessmentLog

def log_event(db: Session, assessment_id: int, step: str, message: str, level: str = "INFO"):
    db.add(AssessmentLog(assessment_id=assessment_id, step=step, message=message, level=level)); db.commit()
