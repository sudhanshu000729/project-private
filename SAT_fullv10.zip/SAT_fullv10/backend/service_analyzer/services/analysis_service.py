from pathlib import Path
from sqlalchemy.orm import Session
from service_analyzer.models.entities import AvailableService, ServiceProperty, WSDLExtract, ExcelExtract, MergedReport
from service_analyzer.services.assessment_service import AssessmentService
from service_analyzer.services.export_service import generate_exports
from service_analyzer.services.log_service import log_event
from service_analyzer.services.merge_service import flatten_fields, merge_service_and_operation
from service_analyzer.parsers.wsdl_parser import parse_wsdl_input
from service_analyzer.parsers.excel_parser import parse_analysis_excel
from service_analyzer.services.report_service import ReportService

class AnalysisCancelled(Exception): pass

def run_analysis(db: Session, assessment_id: int, wsdl_input_path: str, excel_file_path: str, cancel_check=None):
    assessment_service = AssessmentService(db)
    assessment = assessment_service.set_status(assessment_id, 'running', 'Assessment started')
    log_event(db, assessment_id, 'start', 'Assessment created and queued for processing.')
    log_event(db, assessment_id, 'wsdl_scan', 'Scanning WSDL repository or single WSDL file and loading schemas.')
    wsdl_services = parse_wsdl_input(wsdl_input_path, cancel_check=cancel_check)
    log_event(db, assessment_id, 'wsdl_scan', f'Parsed {len(wsdl_services)} WSDL services.')
    log_event(db, assessment_id, 'excel_load', 'Loading Excel discovery data.')
    excel_rows = parse_analysis_excel(excel_file_path)
    log_event(db, assessment_id, 'excel_load', f'Loaded {len(excel_rows)} Excel rows.')
    log_event(db, assessment_id, 'merge', 'Merging WSDL and Excel data at service and operation level.')
    merged_rows = merge_service_and_operation(wsdl_services, excel_rows)
    log_event(db, assessment_id, 'merge', f'Created {len(merged_rows)} merged rows.')
    log_event(db, assessment_id, 'store', 'Persisting WSDL extract, Excel extract, service properties, and merged report rows.')
    for svc in wsdl_services:
        avail = db.get(AvailableService, svc['service_name'])
        if not avail: db.add(AvailableService(service_name=svc['service_name'], normalized_name=svc['normalized_name'], operations_json=svc.get('operations', [])))
        else: avail.normalized_name = svc['normalized_name']; avail.operations_json = svc.get('operations', [])
        db.add(ServiceProperty(assessment_id=assessment_id, service_name=svc['service_name'], namespace=svc.get('namespace'), endpoint_url=svc.get('endpoint_url'), documentation=svc.get('documentation'), bindings_json=svc.get('bindings', []), ports_json=svc.get('ports', []), operations_json=svc.get('operations', []), request_fields_json=[f for op in svc.get('operations', []) for f in flatten_fields(op.get('request_fields', []), [])], response_fields_json=[f for op in svc.get('operations', []) for f in flatten_fields(op.get('response_fields', []), [])], error_fields_json=[f for op in svc.get('operations', []) for f in flatten_fields(op.get('error_fields', []), [])]))
        for op in svc.get('operations', []):
            associated_port = None
            op_binding = op.get('binding_name')
            for p_info in svc.get('ports', []):
                if p_info.get('binding_name') == op_binding:
                    associated_port = p_info.get('port_name')
                    break
            if not associated_port and svc.get('ports'):
                associated_port = svc.get('ports')[0].get('port_name')
                
            type_hierarchy = {
                "complex_types": svc.get("complex_types", {}),
                "simple_types": svc.get("simple_types", {})
            }

            db.add(WSDLExtract(
                assessment_id=assessment_id,
                service_name=svc['service_name'],
                operation_name=op.get('operation_name'),
                direction='request',
                payload_json=op.get('request_fields', []) or [],
                root_element_name=op.get('request_root_element'),
                namespace=svc.get('namespace'),
                binding=op.get('binding_name'),
                port=associated_port,
                endpoint_url=svc.get('endpoint_url'),
                soap_action=op.get('soap_action'),
                diagnostics_json=op.get('payload_diagnostics', {}).get('request', {}),
                type_hierarchy_json=type_hierarchy
            ))
            db.add(WSDLExtract(
                assessment_id=assessment_id,
                service_name=svc['service_name'],
                operation_name=op.get('operation_name'),
                direction='response',
                payload_json=op.get('response_fields', []) or [],
                root_element_name=op.get('response_root_element'),
                namespace=svc.get('namespace'),
                binding=op.get('binding_name'),
                port=associated_port,
                endpoint_url=svc.get('endpoint_url'),
                soap_action=op.get('soap_action'),
                diagnostics_json=op.get('payload_diagnostics', {}).get('response', {}),
                type_hierarchy_json=type_hierarchy
            ))
            db.add(WSDLExtract(
                assessment_id=assessment_id,
                service_name=svc['service_name'],
                operation_name=op.get('operation_name'),
                direction='error',
                payload_json=op.get('error_fields', []) or [],
                root_element_name=op.get('error_root_element'),
                namespace=svc.get('namespace'),
                binding=op.get('binding_name'),
                port=associated_port,
                endpoint_url=svc.get('endpoint_url'),
                soap_action=op.get('soap_action'),
                diagnostics_json=op.get('payload_diagnostics', {}).get('error', {}),
                type_hierarchy_json=type_hierarchy
            ))
            db.add(WSDLExtract(
                assessment_id=assessment_id,
                service_name=svc['service_name'],
                operation_name=op.get('operation_name'),
                direction='meta',
                payload_json={'namespace': svc.get('namespace'), 'endpoint_url': svc.get('endpoint_url'), 'documentation': op.get('documentation'), 'service_documentation': svc.get('documentation'), 'ports': svc.get('ports', []), 'binding_name': op.get('binding_name'), 'binding_style': op.get('binding_style'), 'transport': op.get('transport'), 'soap_action': op.get('soap_action'), 'input_use': op.get('input_use'), 'output_use': op.get('output_use'), 'request_root_element': op.get('request_root_element'), 'response_root_element': op.get('response_root_element'), 'error_root_element': op.get('error_root_element'), 'input_message': op.get('input_message'), 'output_message': op.get('output_message'), 'payload_diagnostics': op.get('payload_diagnostics', {})},
                root_element_name=op.get('request_root_element'),
                namespace=svc.get('namespace'),
                binding=op.get('binding_name'),
                port=associated_port,
                endpoint_url=svc.get('endpoint_url'),
                soap_action=op.get('soap_action'),
                diagnostics_json=op.get('payload_diagnostics', {}),
                type_hierarchy_json=type_hierarchy
            ))
    db.commit()
    for row in excel_rows: db.add(ExcelExtract(assessment_id=assessment_id, service_name=row['service_name'], operation_name=row.get('operation_name'), data_sources_json=row.get('data_sources', []), upstream_apps_json=row.get('upstream_apps', []), downstream_apps_json=row.get('downstream_apps', []), raw_row_json=row.get('raw_row')))
    db.commit()
    for row in merged_rows: db.add(MergedReport(
        assessment_id=assessment_id,
        service_name=row['service_name'],
        operation_name=row.get('operation_name'),
        merge_level=row['merge_level'],
        wsdl_payload_json=row.get('wsdl_payload'),
        excel_payload_json=row.get('excel_payload'),
        merged_payload_json=row.get('merged_payload'),
        excel_service_name=row.get('excel_service_name'),
        excel_operation_name=row.get('excel_operation_name'),
        data_sources_json=row.get('data_sources'),
        upstream_apps_json=row.get('upstream_apps'),
        downstream_apps_json=row.get('downstream_apps'),
        wsdl_service_name=row.get('wsdl_service_name'),
        wsdl_operation_name=row.get('wsdl_operation_name'),
        endpoint_url=row.get('endpoint_url'),
        port=row.get('port'),
        binding=row.get('binding'),
        namespace=row.get('namespace'),
        soap_action=row.get('soap_action'),
        request_structure_json=row.get('request_structure'),
        response_structure_json=row.get('response_structure'),
        error_structure_json=row.get('error_structure'),
        matching_confidence=row.get('matching_confidence'),
        matching_logic_used=row.get('matching_logic_used')
    ))
    db.commit()
    log_event(db, assessment_id, 'similarity', 'Analyzing request/response similarity across service contracts.')
    log_event(db, assessment_id, 'recommendation', 'Generating service consolidation and architectural recommendations.')
    log_event(db, assessment_id, 'export', 'Saving exports and logs.')
    summary = ReportService(db).service_summary(assessment_id)['items']
    wsdl_export_rows = []
    merged_export_rows = []
    for svc in wsdl_services:
        for op in svc.get('operations', []):
            error_type = op.get('error_root_element') or ('Defined in WSDL' if op.get('payload_diagnostics', {}).get('fault_defined') else 'Not defined in WSDL')
            wsdl_export_rows.append({'service_name': svc.get('service_name'), 'operation_name': op.get('operation_name'), 'namespace': svc.get('namespace'), 'endpoint_url': svc.get('endpoint_url'), 'request_type_object': op.get('request_root_element') or 'Not defined in WSDL', 'request_fields_text': chr(10).join([f"{x.get('name')} : {x.get('type')}" for x in flatten_fields(op.get('request_fields', []), [])]) or 'Not defined in WSDL', 'response_type_object': op.get('response_root_element') or 'Not defined in WSDL', 'response_fields_text': chr(10).join([f"{x.get('name')} : {x.get('type')}" for x in flatten_fields(op.get('response_fields', []), [])]) or 'Not defined in WSDL', 'error_type_object': error_type, 'error_fields_text': chr(10).join([f"{x.get('name')} : {x.get('type')}" for x in flatten_fields(op.get('error_fields', []), [])]) or ('No error fields extracted' if error_type != 'Not defined in WSDL' else 'Not defined in WSDL')})
    for row in merged_rows:
        exc = row.get('excel_payload') or {}; w = row.get('wsdl_payload') or {}
        merged_export_rows.append({
            'excel_service_name': row.get('excel_service_name'),
            'excel_operation_name': row.get('excel_operation_name'),
            'wsdl_service_name': row.get('wsdl_service_name'),
            'wsdl_operation_name': row.get('wsdl_operation_name'),
            'upstream_apps': row.get('upstream_apps') or [],
            'downstream_apps': row.get('downstream_apps') or [],
            'data_sources': row.get('data_sources') or [],
            'namespace': row.get('namespace'),
            'endpoint_url': row.get('endpoint_url'),
            'port': row.get('port'),
            'binding': row.get('binding'),
            'soap_action': row.get('soap_action'),
            'request_type_object': w.get('request_type_object'),
            'request_fields_text': w.get('request_fields_text'),
            'response_type_object': w.get('response_type_object'),
            'response_fields_text': w.get('response_fields_text'),
            'error_type_object': w.get('error_type_object'),
            'error_fields_text': w.get('error_fields_text'),
            'matching_confidence': row.get('matching_confidence'),
            'matching_logic_used': row.get('matching_logic_used')
        })
    generate_exports(db, assessment_id, assessment.assessment_code, summary, wsdl_export_rows, excel_rows, merged_export_rows)
    try:
        from service_analyzer.services.ai.rag import RAGPipeline
        log_event(db, assessment_id, 'rag_index', 'Generating embeddings and indexing assessment records in vector database.')
        RAGPipeline().ingest_assessment(db, assessment_id)
        log_event(db, assessment_id, 'rag_index', 'RAG indexing completed successfully.')
    except Exception as e:
        log_event(db, assessment_id, 'rag_index', f'RAG indexing warning: {str(e)}', 'WARNING')
    assessment_service.set_status(assessment_id, 'completed', f'Assessment completed for {len(wsdl_services)} services and {len(merged_rows)} merged rows.')
    log_event(db, assessment_id, 'complete', 'Assessment completed successfully.')
