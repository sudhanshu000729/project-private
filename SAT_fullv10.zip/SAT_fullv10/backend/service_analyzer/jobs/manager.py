from dataclasses import dataclass, field
from threading import Event, Lock, Thread
from service_analyzer.db.database import SessionLocal
from service_analyzer.services.analysis_service import AnalysisCancelled, run_analysis
from service_analyzer.services.assessment_service import AssessmentService
from service_analyzer.services.log_service import log_event
@dataclass
class JobState:
    assessment_id: int
    cancel_event: Event = field(default_factory=Event)
    thread: Thread | None = None
class JobManager:
    def __init__(self): self._jobs = {}; self._lock = Lock()
    def start(self, assessment_id: int, wsdl_input_path: str, excel_file_path: str):
        state = JobState(assessment_id=assessment_id)
        def target():
            db = SessionLocal()
            try: run_analysis(db, assessment_id, wsdl_input_path, excel_file_path, cancel_check=state.cancel_event.is_set)
            except AnalysisCancelled: pass
            except Exception as ex: AssessmentService(db).set_status(assessment_id, 'failed', str(ex)); log_event(db, assessment_id, 'failed', str(ex), 'ERROR')
            finally: db.close()
        state.thread = Thread(target=target, daemon=True)
        with self._lock: self._jobs[assessment_id] = state
        state.thread.start(); return assessment_id
    def cancel(self, assessment_id: int) -> bool:
        with self._lock:
            state = self._jobs.get(assessment_id)
            if not state: return False
            state.cancel_event.set(); return True
job_manager = JobManager()
