import sys
from fastapi.testclient import TestClient
from app import app
from service_analyzer.db.database import SessionLocal, Base, engine
from service_analyzer.models.entities import Assessment, AssessmentChatSession, AssessmentChatMessage

def run_tests():
    print("Starting integration and unit verification tests...")
    client = TestClient(app)

    db = SessionLocal()
    try:
        # Create a dummy completed assessment if none exists
        assessment = db.query(Assessment).first()
        if not assessment:
            assessment = Assessment(
                assessment_code="TEST_RUN_99",
                status="completed",
                wsdl_path="dummy.wsdl"
            )
            db.add(assessment)
            db.commit()
            db.refresh(assessment)

        aid = assessment.id
        print(f"Using Assessment ID: {aid} (Code: {assessment.assessment_code})")

        # 1. Test Chat Query & Persistence
        print("Testing Chat Query POST /api/v1/chat/query...")
        payload = {
            "question": "Compare this assessment service contracts and find duplicate services.",
            "assessment_id": aid,
            "max_services": 5
        }
        response = client.post("/api/v1/chat/query", json=payload)
        assert response.status_code == 200, f"Query failed: {response.text}"
        data = response.json()
        assert "Other details regarding these are below" in data["answer"]
        print("Chat Query PASSED. Persistence check...")

        # Verify database has saved the message
        db.close()
        db = SessionLocal()
        chat_session = db.query(AssessmentChatSession).filter_by(assessment_id=aid).first()
        assert chat_session is not None, "Chat session not created in DB"
        chat_msg = db.query(AssessmentChatMessage).filter_by(session_id=chat_session.id).order_by(AssessmentChatMessage.id.desc()).first()
        assert chat_msg is not None, "Chat message not persisted in DB"
        assert chat_msg.message == payload["question"]
        assert chat_msg.response == data["answer"]
        print("Chat Persistence PASSED.")

        # 2. Test Get History
        print("Testing Get Chat History GET /api/v1/chat/history...")
        response = client.get(f"/api/v1/chat/history?assessment_id={aid}")
        assert response.status_code == 200, f"Get history failed: {response.text}"
        history_list = response.json()
        assert len(history_list) > 0
        assert history_list[0]["question"] == payload["question"]
        print("Get Chat History PASSED.")

        # 3. Test Compare Assessments
        # Create a second assessment for comparison
        assessment_b = db.query(Assessment).filter(Assessment.id != aid).first()
        if not assessment_b:
            assessment_b = Assessment(
                assessment_code="TEST_RUN_100",
                status="completed",
                wsdl_path="dummy_b.wsdl",
                excel_path="dummy_b.xlsx"
            )
            db.add(assessment_b)
            db.commit()
            db.refresh(assessment_b)

        bid = assessment_b.id
        print(f"Testing Assessments Comparison POST /api/v1/chat/compare between {aid} and {bid}...")
        compare_payload = {
            "assessment_id_a": aid,
            "assessment_id_b": bid
        }
        response = client.post("/api/v1/chat/compare", json=compare_payload)
        assert response.status_code == 200, f"Compare failed: {response.text}"
        compare_data = response.json()
        assert "answer" in compare_data
        assert "similarity_score" in compare_data
        assert "confidence_score" in compare_data
        print("Assessments Comparison PASSED.")

        # 4. Test Clear History
        print("Testing Clear Chat History DELETE /api/v1/chat/history...")
        response = client.delete(f"/api/v1/chat/history?assessment_id={aid}")
        assert response.status_code == 200, f"Clear history failed: {response.text}"
        
        # Verify cleared from DB
        chat_session_after = db.query(AssessmentChatSession).filter_by(assessment_id=aid).first()
        assert chat_session_after is None, "Chat session not deleted from DB"
        print("Clear Chat History PASSED.")

        print("\nAll integration tests PASSED successfully!")
    finally:
        db.close()

if __name__ == "__main__":
    run_tests()
